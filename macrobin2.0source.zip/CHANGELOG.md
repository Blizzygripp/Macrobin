# Changelog

## 2.0

Full rebuild. Same features, same `macros.json` format — existing macros load
unchanged, and files written by 2.0 are still readable by 1.0.5.

### Fixed

- **"Toggle On/Off" macros never ran.** The hotkey handler only implemented the
  other three loop modes, so selecting Toggle did nothing at all. Press now
  starts the loop and a second press stops it.
- **Recording captured OS key auto-repeat.** Holding a key produced a
  machine-gun stream of presses instead of one press and one release, so held
  keys never replayed correctly.
- **Ctrl+F10 only stopped recording when macrobin had focus.** It was a
  window-level binding rather than a global one, which made it useless while
  recording in another application. The chord is also scrubbed from the
  recording rather than being captured as part of it.
- **Only one macro could run at a time.** Multiple macros can now run
  concurrently, each on its own key.
- Long waits could not be interrupted; stopping a macro now takes effect
  immediately regardless of how long its delays are.

### Changed

- UI rewritten in PySide6 (Qt), replacing Tkinter/customtkinter. Input runs on
  its own threads and reaches the UI through Qt signals, so the window stays
  responsive while macros fire.
- Mouse actions now use a **Button Status** dropdown (Press and Release /
  Press / Hold / Release) matching how keyboard keys already worked, instead of
  separate "Mouse Down" and "Mouse Up" action types. "Press and Release" is
  stored as a down followed by an up, keeping the file format compatible.
- Transparency has been removed; the window is always fully opaque.
- Keyboard navigation is disabled app-wide — the interface is mouse-driven, so
  a stray Space or Enter can't activate a control mid-bind.
- Spin controls use real buttons rather than Qt's native sub-controls, which
  could not be laid out reliably from a stylesheet.
- Icon glyphs replaced with text labels and tooltips: the previous emoji
  rendered as empty boxes in Segoe UI and clipped at small sizes.

### Removed

- `customtkinter`, `pystray` and `Pillow` are no longer needed. Qt provides the
  system tray, theming and dialogs natively, leaving just PySide6 and pynput.

---

## 1.0.5

Original release.
