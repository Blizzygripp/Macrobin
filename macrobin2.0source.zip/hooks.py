"""
macrobin.hooks — the only module that touches OS input (pynput).

Key design points carried over from 1.0.5 (the hard-won ones):
  * ONE keyboard hook and ONE mouse hook, ever. The original's comments explain
    why: two WH_MOUSE_LL hooks fight over events on Windows (dropped clicks /
    freezes). One-shot captures ("Set Key", "Capture Key", "Capture Button") are
    routed through the SAME listeners via start_bind(), never extra listeners.
  * Raw pynput str(key) format is the canonical key identity ("Key.f9", "'a'",
    "Button.middle") — identical to 1.0.5 bind_key strings, so old files work.

Fixes over 1.0.5:
  * Recording filters OS auto-repeat (held keys record as one down + one up).
  * The record-stop chord (Ctrl+F10) is GLOBAL, not window-focused, and is
    scrubbed from the recording.
  * Multiple macros can run concurrently; per-macro clean restart.
"""

from __future__ import annotations

import time
import threading
from typing import Callable, Optional

from engine import (
    Action, Macro, MacroRunner, HotkeyRouter, key_label,
    KD, KU, KPR, MM, MB_D, MB_U, MS, WT, INFINITE,
)

_PYNPUT_ERR: Optional[str] = None
try:
    from pynput import mouse as pmouse, keyboard as pkeyboard
    from pynput.keyboard import Key, KeyCode, Controller as KbCtrl
    from pynput.mouse import Button, Controller as MsCtrl
    PYNPUT = True
except Exception as e:  # pragma: no cover
    PYNPUT = False
    _PYNPUT_ERR = f"{type(e).__name__}: {e}"


def pynput_available() -> bool:
    return PYNPUT


def pynput_error() -> Optional[str]:
    return _PYNPUT_ERR


# -- raw-string <-> pynput object (1.0.5 format) --------------
def parse_key(s: str):
    """'Key.f9' / "'a'" / bare char -> pynput key object (playback)."""
    if not s:
        return None
    try:
        if s.startswith("Key."):
            return getattr(pkeyboard.Key, s[4:], None)
        if s.startswith("'") and s.endswith("'") and len(s) >= 3:
            return s[1:-1]
        if s.startswith("<") and s.endswith(">"):
            try:
                return pkeyboard.KeyCode.from_vk(int(s[1:-1]))
            except ValueError:
                return None
        return pkeyboard.KeyCode.from_char(s)
    except Exception:
        return None


def parse_button(s: str):
    name = s[7:] if s.startswith("Button.") else s
    return getattr(pmouse.Button, name, pmouse.Button.left)


# Chord pieces for the global record-stop (Ctrl+F10, as 1.0.5 advertised)
_CTRLS = {"Key.ctrl_l", "Key.ctrl_r"}
RECORD_STOP_LABEL = "Ctrl+F10"


# -- Executor -------------------------------------------------
class PynputExecutor:
    def __init__(self):
        if not PYNPUT:
            raise RuntimeError(f"pynput unavailable ({_PYNPUT_ERR})")
        self._kb = KbCtrl()
        self._ms = MsCtrl()

    def execute(self, a: Action) -> None:
        try:
            k, d = a.kind, a.data
            if k == KD:
                pk = parse_key(d.get("key", ""))
                if pk is not None:
                    self._kb.press(pk)
            elif k == KU:
                pk = parse_key(d.get("key", ""))
                if pk is not None:
                    self._kb.release(pk)
            elif k == KPR:
                pk = parse_key(d.get("key", ""))
                if pk is not None:
                    self._kb.press(pk)
                    self._kb.release(pk)
            elif k == MM:
                self._ms.position = (int(d.get("x", 0)), int(d.get("y", 0)))
            elif k == MB_D:
                if "x" in d:
                    self._ms.position = (int(d["x"]), int(d["y"]))
                self._ms.press(parse_button(d.get("button", "Button.left")))
            elif k == MB_U:
                if "x" in d:
                    self._ms.position = (int(d["x"]), int(d["y"]))
                self._ms.release(parse_button(d.get("button", "Button.left")))
            elif k == MS:
                self._ms.scroll(int(d.get("dx", 0)), int(d.get("dy", 0)))
            # WT handled by MacroRunner
        except Exception:
            pass  # never let a bad action kill the runner thread


# -- Callbacks the GUI supplies -------------------------------
class RuntimeCallbacks:
    """All optional; may fire on listener/runner threads — the Qt layer
    marshals them onto the GUI thread via signals."""

    def __init__(self,
                 on_status: Optional[Callable] = None,
                 on_active_changed: Optional[Callable] = None,
                 on_armed_changed: Optional[Callable] = None,
                 on_recording_changed: Optional[Callable] = None,
                 on_action_recorded: Optional[Callable] = None,
                 on_captured: Optional[Callable] = None):
        self.on_status = on_status
        self.on_active_changed = on_active_changed
        self.on_armed_changed = on_armed_changed
        self.on_recording_changed = on_recording_changed
        self.on_action_recorded = on_action_recorded
        self.on_captured = on_captured


# -- Runtime --------------------------------------------------
class Runtime:
    """Owns the single keyboard + single mouse listener, the trigger router,
    per-activation runner threads, recording, and one-shot key capture."""

    def __init__(self, callbacks: Optional[RuntimeCallbacks] = None):
        if not PYNPUT:
            raise RuntimeError(f"pynput unavailable ({_PYNPUT_ERR})")
        self.cb = callbacks or RuntimeCallbacks()
        self._executor = PynputExecutor()
        self._router = HotkeyRouter(self._start_macro, self._stop_macro)

        self._lock = threading.RLock()
        self._runners: dict = {}          # id(macro) -> MacroRunner
        self._macros: list = []

        self._bind_cb: Optional[Callable] = None   # one-shot capture

        # recording state
        self._rec_macro: Optional[Macro] = None
        self._rec_t0: float = 0.0
        self._rec_pressed: set = set()
        self._rec_last_move: float = 0.0
        self.recording = False

        self._kbl = None
        self._msl = None
        self._start_listeners()

    # ---- the ONE pair of listeners --------------------------
    def _start_listeners(self):
        self._kbl = pkeyboard.Listener(on_press=self._kp, on_release=self._kr)
        self._msl = pmouse.Listener(on_move=self._mm, on_click=self._mc,
                                    on_scroll=self._msc)
        self._kbl.daemon = True
        self._msl.daemon = True
        self._kbl.start()
        self._msl.start()

    def shutdown(self):
        self.stop_all()
        for l in (self._kbl, self._msl):
            if l:
                try:
                    l.stop()
                except Exception:
                    pass
        self._kbl = self._msl = None

    # ---- keyboard events ------------------------------------
    def _kp(self, key):
        s = str(key)
        # 1) one-shot capture has absolute priority (Set Key / dialogs)
        cb = self._bind_cb
        if cb is not None:
            self._bind_cb = None
            self._fire_captured(cb, s)
            return
        # 2) recording mode
        if self.recording:
            if s == "Key.f10" and (self._rec_pressed & _CTRLS):
                threading.Thread(target=self.stop_record, daemon=True).start()
                return
            if s in self._rec_pressed:
                return                     # auto-repeat: don't record
            self._rec_pressed.add(s)
            m = self._rec_macro
            if m and m.rec_kb:
                self._rec_push(Action(KD, {"key": s}, self._rec_delay()))
            return
        # 3) trigger routing
        with self._lock:
            self._router.on_key(s, True)

    def _kr(self, key):
        s = str(key)
        if self.recording:
            self._rec_pressed.discard(s)
            m = self._rec_macro
            if m and m.rec_kb:
                self._rec_push(Action(KU, {"key": s}, self._rec_delay()))
            return
        with self._lock:
            self._router.on_key(s, False)

    # ---- mouse events ---------------------------------------
    def _mc(self, x, y, button, pressed):
        s = str(button)
        if pressed and self._bind_cb is not None:
            cb = self._bind_cb
            self._bind_cb = None
            self._fire_captured(cb, s)
            return
        if self.recording:
            m = self._rec_macro
            if m and m.rec_btn:
                kind = MB_D if pressed else MB_U
                self._rec_push(Action(kind, {"x": int(x), "y": int(y), "button": s},
                                      self._rec_delay()))
            return
        with self._lock:
            self._router.on_key(s, pressed)

    def _mm(self, x, y):
        if not self.recording:
            return
        m = self._rec_macro
        if not (m and m.rec_move):
            return
        now = time.time()
        if now - self._rec_last_move < 0.05:   # ~20 fps, as 1.0.5
            return
        self._rec_last_move = now
        self._rec_push(Action(MM, {"x": int(x), "y": int(y)}, self._rec_delay()))

    def _msc(self, x, y, dx, dy):
        if not self.recording:
            return
        m = self._rec_macro
        if not (m and m.rec_move):
            return
        self._rec_push(Action(MS, {"x": int(x), "y": int(y),
                                   "dx": int(dx), "dy": int(dy)},
                              self._rec_delay()))

    # ---- one-shot capture -----------------------------------
    def start_bind(self, callback: Callable) -> None:
        """Next key press or mouse button press is delivered to `callback`
        (raw pynput string) instead of being routed/recorded."""
        self._bind_cb = callback

    def cancel_bind(self) -> None:
        self._bind_cb = None

    def _fire_captured(self, cb, s: str):
        threading.Thread(target=lambda: cb(s), daemon=True).start()
        if self.cb.on_captured:
            self.cb.on_captured(s)

    # ---- macros / arming ------------------------------------
    def set_macros(self, macros: list) -> None:
        with self._lock:
            self._macros = list(macros)
            self._router.set_macros(macros)

    def arm(self, armed: bool) -> None:
        with self._lock:
            self._router.set_armed(armed)
        if not armed:
            self.stop_all()
        if self.cb.on_armed_changed:
            self.cb.on_armed_changed(armed)
        self._status("System enabled." if armed else "System disabled — hotkeys paused.",
                     "green" if armed else "yellow")

    @property
    def armed(self) -> bool:
        return self._router.armed

    # ---- runner lifecycle -----------------------------------
    def _start_macro(self, macro: Macro, loops: int) -> None:
        with self._lock:
            old = self._runners.get(id(macro))
            if old:
                old.stop()
            runner = MacroRunner(macro, self._executor, loops=loops,
                                 sleep=time.sleep, on_finished=self._finished)
            self._runners[id(macro)] = runner
            threading.Thread(target=runner.run, name=f"macro-{macro.name}",
                             daemon=True).start()
        self._status(f"\u25b6 {macro.name}", "green")
        self._emit_active()

    def _stop_macro(self, macro: Macro) -> None:
        with self._lock:
            r = self._runners.get(id(macro))
            if r:
                r.stop()
        self._status(f"\u25a0 {macro.name}", None)

    def _finished(self, runner: MacroRunner) -> None:
        with self._lock:
            if self._runners.get(id(runner.macro)) is runner:
                del self._runners[id(runner.macro)]
            self._router.notify_finished(runner.macro)
        self._emit_active()

    def play(self, macro: Macro) -> None:
        """Manual Play button — runs one activation per its loop mode."""
        self._start_macro(macro, macro.loops_for_activation())

    def stop(self, macro: Macro) -> None:
        self._stop_macro(macro)

    def stop_all(self) -> None:
        with self._lock:
            runners = list(self._runners.values())
        for r in runners:
            r.stop()
        self._emit_active()

    def is_playing(self, macro: Macro) -> bool:
        with self._lock:
            return id(macro) in self._runners

    def any_playing(self) -> bool:
        with self._lock:
            return bool(self._runners)

    # ---- recording ------------------------------------------
    def start_record(self, macro: Macro) -> bool:
        with self._lock:
            if self.recording:
                return False
            self.stop_all()
            self._router.set_armed(False)   # triggers off while authoring
            self._rec_macro = macro
            self._rec_pressed = set()
            self._rec_t0 = time.time()
            self._rec_last_move = 0.0
            self.recording = True
        if self.cb.on_armed_changed:
            self.cb.on_armed_changed(False)
        if self.cb.on_recording_changed:
            self.cb.on_recording_changed(True)
        self._status(f"Recording\u2026  stop with {RECORD_STOP_LABEL}", "red")
        return True

    def stop_record(self) -> int:
        with self._lock:
            if not self.recording:
                return 0
            self.recording = False
            m = self._rec_macro
            self._rec_macro = None
            # Scrub the stop chord: drop trailing Ctrl/F10 downs.
            if m:
                while m.actions and m.actions[-1].kind == KD and \
                        m.actions[-1].data.get("key") in (_CTRLS | {"Key.f10"}):
                    m.actions.pop()
            n = len(m.actions) if m else 0
        if self.cb.on_recording_changed:
            self.cb.on_recording_changed(False)
        self._status(f"Stopped — {n} actions captured.", "green")
        return n

    def _rec_delay(self) -> int:
        now = time.time()
        ms = int((now - self._rec_t0) * 1000)
        self._rec_t0 = now
        m = self._rec_macro
        if m and m.rec_wait and ms >= max(0, int(m.min_delay)):
            return ms
        return 0

    def _rec_push(self, a: Action) -> None:
        m = self._rec_macro
        if not m:
            return
        with self._lock:
            m.actions.append(a)
        if self.cb.on_action_recorded:
            self.cb.on_action_recorded(a)

    # ---- misc -----------------------------------------------
    def mouse_position(self):
        try:
            return MsCtrl().position
        except Exception:
            return (0, 0)

    def _status(self, msg: str, level: Optional[str]) -> None:
        if self.cb.on_status:
            self.cb.on_status(msg, level or "")

    def _emit_active(self) -> None:
        if self.cb.on_active_changed:
            with self._lock:
                self.cb.on_active_changed(set(self._runners.keys()))
