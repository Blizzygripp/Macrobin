"""
macrobin.engine — pure core (no GUI, no pynput). Testable headlessly.

v2 rebuilt around the ORIGINAL 1.0.5 data model so existing macros.json files
load unchanged:

  Action: kind in {key_down,key_up,key_press_release,mouse_move,mouse_down,
                   mouse_up,mouse_scroll,wait}, data dict, delay (ms BEFORE it)
  Macro:  name, trigger, loop, bind_key (raw pynput str e.g. "Key.f9", "'a'",
          "Button.middle"), enabled, capture, min_delay, repeat_n,
          rec_move, rec_btn, rec_kb, rec_wait, actions
  File:   macros.json — a JSON list of macro dicts (identical schema to 1.0.5)

Loop modes (original labels, now all actually working):
  "While Holding Key" — runs looping while the bound key is held
  "Toggle On/Off"     — press starts looping, press again stops  (was dead in 1.0.5)
  "Repeat N Times"    — one press plays the macro N times
  "Run Once"          — one press plays it once
"""

from __future__ import annotations

import json
import os
import time
import threading
from typing import Callable, Optional

VER = "2.0"

# -- Action kind tokens (unchanged from 1.0.5) ----------------
KD  = "key_down"
KU  = "key_up"
KPR = "key_press_release"
MM  = "mouse_move"
MB_D = "mouse_down"
MB_U = "mouse_up"
MS  = "mouse_scroll"
WT  = "wait"

ALL_KINDS = (KD, KU, KPR, MM, MB_D, MB_U, MS, WT)

# -- Option label lists (unchanged from 1.0.5) ----------------
TRIGGER_OPTS = ["Keystrokes / Button Inputs", "Gamepad Inputs", "Scheduled"]
LOOP_OPTS    = ["While Holding Key", "Toggle On/Off", "Repeat N Times", "Run Once"]
CAPTURE_OPTS = ["Save Current Position", "Relative to Window", "Don't Capture"]

LOOP_HOLD, LOOP_TOGGLE, LOOP_REPEAT, LOOP_ONCE = LOOP_OPTS

INFINITE = 0  # internal sentinel for "loop until stopped"

# -- Key label helper (ported) --------------------------------
SPECIAL = {
    "Key.space": "Space", "Key.enter": "Enter", "Key.tab": "Tab",
    "Key.backspace": "Backspace", "Key.delete": "Delete",
    "Key.esc": "Escape", "Key.escape": "Escape",
    "Key.shift": "Shift", "Key.shift_r": "Shift(R)", "Key.ctrl_l": "Ctrl",
    "Key.ctrl_r": "Ctrl(R)", "Key.alt_l": "Alt", "Key.alt_r": "Alt(R)",
    "Key.up": "\u2191", "Key.down": "\u2193",
    "Key.left": "\u2190", "Key.right": "\u2192",
    **{f"Key.f{i}": f"F{i}" for i in range(1, 25)},
    "Button.left": "LMB", "Button.right": "RMB", "Button.middle": "MMB",
    "Button.x1": "XButton1", "Button.x2": "XButton2",
}


def key_label(s: Optional[str]) -> str:
    if not s:
        return "\u2014"
    if s in SPECIAL:
        return SPECIAL[s]
    if s.startswith("'") and s.endswith("'") and len(s) >= 3:
        return s[1:-1].upper()
    if s.startswith("Key."):
        return s[4:].capitalize()
    if s.startswith("Button."):
        return s[7:].capitalize()
    return s


# -- Data model -----------------------------------------------
class Action:
    def __init__(self, kind: str, data: Optional[dict] = None, delay: int = 0):
        self.kind = kind
        self.data = dict(data or {})
        self.delay = max(0, int(delay))   # ms before this action

    def to_dict(self) -> dict:
        return {"kind": self.kind, "data": dict(self.data), "delay": self.delay}

    @classmethod
    def from_dict(cls, d: dict) -> "Action":
        return cls(d.get("kind", WT), d.get("data", {}), d.get("delay", 0))

    def label(self) -> str:
        k, d = self.kind, self.data
        if k == KD:
            return f"\u25bc Key    {key_label(d.get('key',''))}"
        if k == KU:
            return f"\u25b2 Key    {key_label(d.get('key',''))}"
        if k == KPR:
            return f"\u25bc\u25b2 Key   {key_label(d.get('key',''))}"
        if k == MM:
            return f"\u2192 Move   ({d.get('x',0)}, {d.get('y',0)})"
        if k == MB_D:
            return f"\u25bc Mouse  {key_label(d.get('button',''))}"
        if k == MB_U:
            return f"\u25b2 Mouse  {key_label(d.get('button',''))}"
        if k == MS:
            return f"\u2261 Scroll dy={d.get('dy',0)}"
        if k == WT:
            return f"\u00b7 Wait   {d.get('ms',0)} ms"
        return f"? {k}"

    def color_key(self) -> str:
        """Palette key for row coloring: tag_kb / tag_ms / tag_wt."""
        if self.kind in (KD, KU, KPR):
            return "tag_kb"
        if self.kind in (MM, MB_D, MB_U, MS):
            return "tag_ms"
        return "tag_wt"


class Macro:
    def __init__(self, name: str = "Macro 1"):
        self.name = name
        self.trigger = TRIGGER_OPTS[0]
        self.loop = LOOP_OPTS[0]
        self.bind_key = ""          # raw pynput string
        self.enabled = True
        self.capture = CAPTURE_OPTS[0]
        self.min_delay = 1          # ms — recording ignores gaps below this
        self.repeat_n = 1
        self.rec_move = True
        self.rec_btn = True
        self.rec_kb = True
        self.rec_wait = True
        self.actions: list = []

    _KEYS = ["name", "trigger", "loop", "bind_key", "enabled", "capture",
             "min_delay", "repeat_n", "rec_move", "rec_btn", "rec_kb", "rec_wait"]

    def to_dict(self) -> dict:
        d = {k: getattr(self, k) for k in self._KEYS}
        d["actions"] = [a.to_dict() for a in self.actions]
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "Macro":
        m = cls(d.get("name", "Macro"))
        for k in cls._KEYS:
            if k in d and k != "name":
                setattr(m, k, d[k])
        try:
            m.min_delay = max(0, int(m.min_delay))
        except Exception:
            m.min_delay = 1
        try:
            m.repeat_n = max(1, int(m.repeat_n))
        except Exception:
            m.repeat_n = 1
        if m.loop not in LOOP_OPTS:
            m.loop = LOOP_OPTS[0]
        m.actions = [Action.from_dict(a) for a in d.get("actions", [])]
        return m

    # -- derived trigger behavior --
    def loops_for_activation(self) -> int:
        if self.loop == LOOP_HOLD:
            return INFINITE
        if self.loop == LOOP_TOGGLE:
            return INFINITE
        if self.loop == LOOP_REPEAT:
            return max(1, int(self.repeat_n))
        return 1  # Run Once

    def stops_on_release(self) -> bool:
        return self.loop == LOOP_HOLD

    def is_toggle(self) -> bool:
        return self.loop == LOOP_TOGGLE


# -- macros.json I/O (list format, identical to 1.0.5) --------
def save_macros(path: str, macros: list) -> None:
    with open(path, "w", encoding="utf-8") as f:
        json.dump([m.to_dict() for m in macros], f, indent=2)


def load_macros(path: str) -> list:
    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)
    if not isinstance(data, list):
        raise ValueError("macros.json should contain a list of macros")
    return [Macro.from_dict(d) for d in data]


# -- Executor protocol ----------------------------------------
class Executor:
    def execute(self, action: Action) -> None:  # pragma: no cover
        raise NotImplementedError


# -- Interruptible sleep --------------------------------------
def interruptible_sleep(total_s: float,
                        should_stop: Callable[[], bool],
                        sleep: Callable[[float], None],
                        chunk_s: float = 0.01) -> None:
    if total_s <= 0:
        return
    remaining = total_s
    while remaining > 0:
        if should_stop():
            return
        step = chunk_s if remaining > chunk_s else remaining
        sleep(step)
        remaining -= step


# -- MacroRunner ----------------------------------------------
class MacroRunner:
    """Executes one activation of a macro. Per-action `delay` sleeps happen
    interruptibly BEFORE each action (1.0.5 semantics); WAIT actions sleep
    their `ms` at execution time. Both stop instantly on request."""

    def __init__(self, macro: Macro, executor, loops: Optional[int] = None,
                 sleep: Callable[[float], None] = time.sleep,
                 on_finished: Optional[Callable] = None):
        self.macro = macro
        self.executor = executor
        self.loops = macro.loops_for_activation() if loops is None else loops
        self._sleep = sleep
        self._on_finished = on_finished
        self._stop = False
        self.completed_loops = 0

    def stop(self) -> None:
        self._stop = True

    def _should_stop(self) -> bool:
        return self._stop

    def run(self) -> None:
        try:
            while not self._stop:
                for a in self.macro.actions:
                    if self._stop:
                        break
                    if a.delay > 0:
                        interruptible_sleep(a.delay / 1000.0, self._should_stop, self._sleep)
                        if self._stop:
                            break
                    if a.kind == WT:
                        ms = max(0, int(a.data.get("ms", 0)))
                        interruptible_sleep(ms / 1000.0, self._should_stop, self._sleep)
                    else:
                        self.executor.execute(a)

                # Yield a hair on zero-time infinite loops so stop/panic edges
                # are never starved and a core isn't pegged.
                if not self._stop and not _has_time(self.macro.actions):
                    interruptible_sleep(0.001, self._should_stop, self._sleep)

                self.completed_loops += 1
                if self.loops != INFINITE and self.completed_loops >= self.loops:
                    break
        finally:
            if self._on_finished:
                self._on_finished(self)


def _has_time(actions: list) -> bool:
    return any(a.kind == WT or a.delay > 0 for a in actions)


# -- HotkeyRouter ---------------------------------------------
class HotkeyRouter:
    """Maps physical key edges to macro start/stop for the four loop modes,
    filtering OS auto-repeat (a held key emits repeated downs). Pure logic."""

    def __init__(self, start: Callable, stop: Callable):
        self._start = start
        self._stop = stop
        self._pressed: set = set()
        self._toggled_on: set = set()     # id(macro) of toggled-running macros
        self._bindings: dict = {}         # bind_key -> Macro
        self.armed = True

    def set_macros(self, macros: list) -> None:
        self._bindings = {m.bind_key: m for m in macros if m.enabled and m.bind_key}
        live = {id(m) for m in self._bindings.values()}
        self._toggled_on &= live

    def bound_keys(self) -> set:
        return set(self._bindings.keys())

    def set_armed(self, armed: bool) -> None:
        self.armed = armed
        if not armed:
            for m in list(self._bindings.values()):
                if id(m) in self._toggled_on:
                    self._stop(m)
            self._toggled_on.clear()
            self._pressed.clear()

    def on_key(self, key: str, is_down: bool) -> bool:
        bound = key in self._bindings
        if is_down:
            already = key in self._pressed
            self._pressed.add(key)
            if already:
                return bound            # auto-repeat: swallow
            if not self.armed or not bound:
                return bound
            self._on_press(self._bindings[key])
        else:
            self._pressed.discard(key)
            if bound:
                m = self._bindings[key]
                if m.stops_on_release():
                    self._stop(m)
        return bound

    def _on_press(self, m: Macro) -> None:
        if m.is_toggle():
            if id(m) in self._toggled_on:
                self._toggled_on.discard(id(m))
                self._stop(m)
            else:
                self._toggled_on.add(id(m))
                self._start(m, m.loops_for_activation())
        else:
            self._start(m, m.loops_for_activation())

    def notify_finished(self, m: Macro) -> None:
        """A finite run ended by itself; clear toggle state so the next press
        starts fresh instead of being a dead 'toggle off'."""
        self._toggled_on.discard(id(m))
