"""macrobin windowless entry — double-click me to launch (no console).
Windows runs .pyw files with pythonw automatically, so no console box appears.
"""

import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from macrobin import main

if __name__ == "__main__":
    sys.exit(main())
