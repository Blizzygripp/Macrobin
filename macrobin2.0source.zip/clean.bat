@echo off
setlocal
cd /d "%~dp0"

echo ==================================================
echo   macrobin - clean the folder for release
echo ==================================================
echo.
echo This removes generated junk. Source files are never touched.
echo.

if exist ".venv" (
    echo   removing .venv\        ^(unused - deps install to your user site-packages^)
    rd /s /q ".venv"
)
if exist "__pycache__" (
    echo   removing __pycache__\
    rd /s /q "__pycache__"
)
if exist "build" (
    echo   removing build\        ^(PyInstaller intermediates^)
    rd /s /q "build"
)
if exist "macrobin_error.log" (
    echo   removing macrobin_error.log
    del /q "macrobin_error.log"
)
del /q *.pyc 2>nul

echo.
echo Kept:
if exist "dist\macrobin.exe" echo   dist\macrobin.exe   - your release build
if exist "macros.json"       echo   macros.json         - YOUR macros ^(do not ship this^)
if exist "config.json"       echo   config.json         - YOUR settings ^(do not ship this^)
echo.

set "RMDIST="
set /p RMDIST=Also delete dist\ so you can do a fresh build? [y/N] 
if /i "%RMDIST%"=="y" (
    if exist "dist" rd /s /q "dist"
    echo   dist\ removed.
)

set "RMDATA="
set /p RMDATA=Also delete macros.json and config.json ^(resets the app^)? [y/N] 
if /i "%RMDATA%"=="y" (
    if exist "macros.json" del /q "macros.json"
    if exist "config.json" del /q "config.json"
    echo   user data removed.
)

echo.
echo Done.
echo.
pause
