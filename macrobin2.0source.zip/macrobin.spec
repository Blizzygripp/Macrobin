# -*- mode: python ; coding: utf-8 -*-
# PyInstaller spec for macrobin — one-file, windowed, with the app icon.
# Build:  build_exe.bat   (or:  py -3 -m PyInstaller --noconfirm macrobin.spec)
import glob
import os

here = os.path.abspath(os.getcwd())

# Find the app icon. Prefer an explicitly named macrobin icon, otherwise take
# whatever .ico is sitting in the folder, so renaming the file doesn't silently
# drop the branding from the build.
icon_path = None
for name in ("Macrobin.ico", "macrobin.ico", "icon.ico"):
    candidate = os.path.join(here, name)
    if os.path.exists(candidate):
        icon_path = candidate
        break
if icon_path is None:
    found = sorted(glob.glob(os.path.join(here, "*.ico")))
    icon_path = found[0] if found else None

# Ship the icon inside the exe too, so the window and tray icons match the
# executable's own icon at runtime.
datas = [(icon_path, ".")] if icon_path else []

a = Analysis(
    ["macrobin.py"],
    pathex=[here],
    binaries=[],
    datas=datas,
    hiddenimports=[
        # pynput picks its backend dynamically; PyInstaller needs these named.
        "pynput.keyboard._win32",
        "pynput.mouse._win32",
    ],
    hookspath=[],
    runtime_hooks=[],
    excludes=["tkinter", "customtkinter", "pystray", "PIL"],
)
pyz = PYZ(a.pure)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.datas,
    [],
    name="macrobin",
    debug=False,
    strip=False,
    upx=False,
    console=False,          # windowed — no console box
    icon=icon_path,
)
