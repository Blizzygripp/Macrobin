"""Headless self-test for macrobin.engine (v2, original-1.0.5-compatible model).
Runs in virtual time. Usage:  py -3 selftest.py"""

import os, sys, tempfile, json

from engine import (
    Action, Macro, MacroRunner, HotkeyRouter, interruptible_sleep,
    save_macros, load_macros, key_label,
    KD, KU, KPR, MM, MB_D, MB_U, MS, WT,
    LOOP_HOLD, LOOP_TOGGLE, LOOP_REPEAT, LOOP_ONCE, INFINITE,
)

_passed = _failed = 0


def check(cond, label):
    global _passed, _failed
    if cond:
        _passed += 1
        print(f"  ok   {label}")
    else:
        _failed += 1
        print(f"  FAIL {label}")


def approx(a, b, tol=1e-9):
    return abs(a - b) <= tol


class RecEx:
    def __init__(self):
        self.calls = []

    def execute(self, a):
        self.calls.append(a)


class VClock:
    def __init__(self):
        self.t = 0.0
        self.hook = None

    def sleep(self, s):
        self.t += s
        if self.hook:
            self.hook(self.t)


class Log:
    def __init__(self):
        self.ev = []

    def start(self, m, loops):
        self.ev.append(("start", m.name, loops))

    def stop(self, m):
        self.ev.append(("stop", m.name, None))


# 1) 1.0.5 file-format compatibility ------------------------------------------
def test_legacy_file_roundtrip():
    print("macros.json — 1.0.5 format compatibility")
    legacy = [{
        "name": "AutoClick", "trigger": "Keystrokes / Button Inputs",
        "loop": "While Holding Key", "bind_key": "Key.f6", "enabled": True,
        "capture": "Save Current Position", "min_delay": 1, "repeat_n": 1,
        "rec_move": True, "rec_btn": True, "rec_kb": True, "rec_wait": True,
        "actions": [
            {"kind": "mouse_down", "data": {"x": 500, "y": 400, "button": "Button.left"}, "delay": 0},
            {"kind": "mouse_up", "data": {"x": 500, "y": 400, "button": "Button.left"}, "delay": 12},
            {"kind": "key_press_release", "data": {"key": "'a'"}, "delay": 30},
            {"kind": "wait", "data": {"ms": 80}, "delay": 0},
        ],
    }]
    tmp = tempfile.mktemp(suffix=".json")
    with open(tmp, "w") as f:
        json.dump(legacy, f)
    ms = load_macros(tmp)
    check(len(ms) == 1 and ms[0].name == "AutoClick", "legacy macro loads")
    m = ms[0]
    check(m.bind_key == "Key.f6" and m.loop == "While Holding Key", "bind_key + loop preserved")
    check(len(m.actions) == 4 and m.actions[1].delay == 12, "per-action delay preserved")
    check(m.actions[2].data.get("key") == "'a'", "raw pynput key string preserved")
    save_macros(tmp, ms)
    raw = json.load(open(tmp))
    os.remove(tmp)
    check(isinstance(raw, list) and raw[0]["actions"][1]["delay"] == 12,
          "written file keeps 1.0.5 list schema (old app can still read it)")
    check(set(raw[0].keys()) >= {"name", "trigger", "loop", "bind_key", "enabled", "capture",
                                 "min_delay", "repeat_n", "rec_move", "rec_btn", "rec_kb",
                                 "rec_wait", "actions"},
          "all 1.0.5 keys present on save")


def test_labels():
    print("labels")
    check(key_label("Key.f6") == "F6", "Key.f6 -> F6")
    check(key_label("'a'") == "A", "'a' -> A")
    check(key_label("Button.middle") == "MMB", "Button.middle -> MMB")
    check(Action(WT, {"ms": 80}).label().endswith("80 ms"), "wait label")


# 2) runner --------------------------------------------------------------------
def test_runner_delay_semantics():
    print("runner: per-action delay + wait timing")
    ex, clk = RecEx(), VClock()
    m = Macro("t"); m.loop = LOOP_REPEAT; m.repeat_n = 2
    m.actions = [Action(KPR, {"key": "'a'"}, delay=10),
                 Action(WT, {"ms": 25}, delay=5)]
    MacroRunner(m, ex, loops=2, sleep=clk.sleep).run()
    check(approx(clk.t, 0.080), f"2 loops of delays+waits == 80ms (got {clk.t*1000:.1f})")
    check(len(ex.calls) == 2 and ex.calls[0].kind == KPR, "executed 1 non-wait action per loop")


def test_runner_loop_counts():
    print("runner: loop counts from loop mode")
    m = Macro("t"); m.loop = LOOP_REPEAT; m.repeat_n = 3
    check(m.loops_for_activation() == 3, "Repeat N -> N")
    m.loop = LOOP_ONCE
    check(m.loops_for_activation() == 1, "Run Once -> 1")
    m.loop = LOOP_HOLD
    check(m.loops_for_activation() == INFINITE, "Hold -> infinite")
    m.loop = LOOP_TOGGLE
    check(m.loops_for_activation() == INFINITE, "Toggle -> infinite")


def test_runner_infinite_stops():
    print("runner: infinite honors stop promptly")
    ex, clk = RecEx(), VClock()
    m = Macro("s"); m.loop = LOOP_TOGGLE
    m.actions = [Action(KPR, {"key": "'x'"}), Action(WT, {"ms": 50})]
    r = MacroRunner(m, ex, loops=INFINITE, sleep=clk.sleep)
    clk.hook = lambda t: (r.stop() if t >= 0.2 else None)
    r.run()
    check(r.completed_loops >= 1 and clk.t < 0.3, f"stopped near request (t={clk.t:.3f})")


def test_interruptible_sleep():
    print("interruptible sleep")
    clk = VClock(); flag = {"s": False}
    clk.hook = lambda t: flag.__setitem__("s", t >= 0.02)
    interruptible_sleep(10.0, lambda: flag["s"], clk.sleep)
    check(clk.t < 0.05, f"10s wait aborted at ~20ms (t={clk.t:.4f})")


# 3) router --------------------------------------------------------------------
def rt():
    log = Log()
    return HotkeyRouter(log.start, log.stop), log


def test_hold_mode():
    print("router: While Holding Key")
    r, log = rt()
    m = Macro("h"); m.loop = LOOP_HOLD; m.bind_key = "Key.f6"
    r.set_macros([m])
    r.on_key("Key.f6", True); r.on_key("Key.f6", True); r.on_key("Key.f6", True)
    r.on_key("Key.f6", False)
    starts = [e for e in log.ev if e[0] == "start"]
    check(len(starts) == 1 and starts[0][2] == INFINITE, "auto-repeat filtered; starts once, infinite")
    check(log.ev[-1][0] == "stop", "release stops")


def test_toggle_mode_fixed():
    print("router: Toggle On/Off (dead in 1.0.5 — now works)")
    r, log = rt()
    m = Macro("t"); m.loop = LOOP_TOGGLE; m.bind_key = "Key.f7"
    r.set_macros([m])
    r.on_key("Key.f7", True); r.on_key("Key.f7", False)
    r.on_key("Key.f7", True); r.on_key("Key.f7", False)
    r.on_key("Key.f7", True)
    kinds = [e[0] for e in log.ev]
    check(kinds == ["start", "stop", "start"], f"toggle start/stop/start (got {kinds})")


def test_repeat_and_once():
    print("router: Repeat N / Run Once")
    r, log = rt()
    m = Macro("r"); m.loop = LOOP_REPEAT; m.repeat_n = 5; m.bind_key = "Key.f8"
    r.set_macros([m])
    for _ in range(4):
        r.on_key("Key.f8", True)
    r.on_key("Key.f8", False)
    starts = [e for e in log.ev if e[0] == "start"]
    check(len(starts) == 1 and starts[0][2] == 5, "one start with loops=5")
    check(not any(e[0] == "stop" for e in log.ev), "no stop on release for Repeat N")
    r2, log2 = rt()
    m2 = Macro("o"); m2.loop = LOOP_ONCE; m2.bind_key = "Button.middle"
    r2.set_macros([m2])
    r2.on_key("Button.middle", True); r2.on_key("Button.middle", False)
    check(log2.ev == [("start", "o", 1)], "mouse-button trigger, Run Once -> loops=1")


def test_disarm_and_finish():
    print("router: disarm + self-finished toggle")
    r, log = rt()
    m = Macro("t"); m.loop = LOOP_TOGGLE; m.bind_key = "Key.f7"
    r.set_macros([m])
    r.on_key("Key.f7", True); r.on_key("Key.f7", False)
    r.set_armed(False)
    check(log.ev[-1][0] == "stop", "disarm stops running toggle")
    n = len(log.ev)
    r.on_key("Key.f7", True); r.on_key("Key.f7", False)
    check(len(log.ev) == n, "no triggers while disarmed")
    r.set_armed(True)
    r.on_key("Key.f7", True); r.on_key("Key.f7", False)
    check(log.ev[-1][0] == "start", "re-armed toggle starts fresh")
    r.notify_finished(m)
    r.on_key("Key.f7", True)
    check(log.ev[-1][0] == "start", "press after self-finish starts (not dead toggle-off)")


def test_unbound_and_bound_hint():
    print("router: unbound ignored, bound hint returned")
    r, log = rt()
    m = Macro("x"); m.loop = LOOP_ONCE; m.bind_key = "Key.f9"
    r.set_macros([m])
    check(r.on_key("'z'", True) is False and log.ev == [], "unbound key -> no events")
    check(r.on_key("Key.f9", True) is True, "bound key returns True")


def main():
    print("=" * 60)
    print("macrobin engine self-test (v2)")
    print("=" * 60)
    test_legacy_file_roundtrip()
    test_labels()
    test_runner_delay_semantics()
    test_runner_loop_counts()
    test_runner_infinite_stops()
    test_interruptible_sleep()
    test_hold_mode()
    test_toggle_mode_fixed()
    test_repeat_and_once()
    test_disarm_and_finish()
    test_unbound_and_bound_hint()
    print("-" * 60)
    print(f"{_passed} passed, {_failed} failed")
    print("=" * 60)
    return 1 if _failed else 0


if __name__ == "__main__":
    sys.exit(main())
