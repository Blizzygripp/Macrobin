@echo off
setlocal EnableDelayedExpansion
cd /d "%~dp0"

echo ==================================================
echo   macrobin - build macrobin.exe
echo ==================================================
echo.

REM ---- locate Python 3 -------------------------------------------------------
set "PYCMD="
py -3 --version >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD (
    python --version >nul 2>&1 && set "PYCMD=python"
)
if not defined PYCMD (
    echo ERROR: Python 3 not found. Run install_dependencies.bat first.
    echo.
    pause
    exit /b 1
)
echo Python:     %PYCMD%

REM ---- find the icon ---------------------------------------------------------
REM Prefers a named macrobin icon, otherwise takes any .ico in the folder.
set "ICON="
if exist "Macrobin.ico" set "ICON=Macrobin.ico"
if not defined ICON if exist "macrobin.ico" set "ICON=macrobin.ico"
if not defined ICON if exist "icon.ico"     set "ICON=icon.ico"
if not defined ICON (
    for %%F in (*.ico) do (
        if not defined ICON set "ICON=%%F"
    )
)

if defined ICON (
    echo Icon:       !ICON!
) else (
    echo Icon:       none found - the exe will use PyInstaller's default.
    echo             Put a .ico file in this folder and run this again.
)
echo.

REM ---- dependencies ----------------------------------------------------------
echo Checking PyInstaller ...
%PYCMD% -m pip install --user --upgrade pyinstaller
if errorlevel 1 (
    echo.
    echo ERROR: could not install PyInstaller.
    pause
    exit /b 1
)

REM ---- build -----------------------------------------------------------------
echo.
echo Building - this takes a couple of minutes ...
echo.
%PYCMD% -m PyInstaller --noconfirm --clean macrobin.spec
if errorlevel 1 (
    echo.
    echo BUILD FAILED - see the messages above.
    pause
    exit /b 1
)

REM ---- tidy intermediates, keep the output -----------------------------------
if exist "build" rd /s /q "build"

echo.
if exist "dist\macrobin.exe" (
    echo ==================================================
    echo   SUCCESS
    echo ==================================================
    echo   dist\macrobin.exe
    for %%A in ("dist\macrobin.exe") do echo   %%~zA bytes
    echo.
    echo Single windowed exe - no Python needed on the target machine.
    echo It reads/writes macros.json and config.json NEXT TO ITSELF, so you
    echo can move it anywhere; copy an existing macros.json beside it to
    echo bring your macros along.
    echo.
    if defined ICON (
        echo If Explorer still shows the old icon, that's Windows' icon cache:
        echo rename the exe, or run  ie4uinit.exe -show  to refresh it.
    )
) else (
    echo Build finished but dist\macrobin.exe was not found - check the output above.
)
echo.
pause
