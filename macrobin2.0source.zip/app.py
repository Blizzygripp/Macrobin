"""
macrobin.app — PySide6 UI, a faithful rebuild of the 1.0.5 layout:

  * Main window: header, scrollable macro list (colored accent bars, enable /
    edit / delete per row), "Disable System" + "+ Add New Macro", status bar
    with a settings gear.
  * Editor window per macro: left = name + Trigger Settings + Record Actions
    (capture combo, four record toggles, min-delay, Record with blinking dot),
    bottom Save + Play; right = Action Editor (10-button toolbar with tooltips,
    color-coded list with a Delay column, multi-select, context menu).
  * Settings: theme picker (Default / AMOLED / Terminal
    Green / Custom + full custom-theme editor), close-to-tray.
  * System tray (Qt native — pystray/Pillow no longer needed), single-instance
    guard, autosave to macros.json + config.json next to the exe/script.

Threading rule: pynput/runner threads never touch widgets; hooks.Runtime
reports through callbacks that a Bridge turns into Qt signals.
"""

from __future__ import annotations

import json
import os
import sys
import tempfile
import time

try:
    from PySide6.QtCore import Qt, QObject, Signal, QTimer, QSize, QPoint, QEvent
    from PySide6.QtGui import (QAction, QColor, QIcon, QPixmap, QPainter,
                               QBrush, QPen, QFont, QKeySequence, QPolygon)
    from PySide6.QtWidgets import (
        QApplication, QMainWindow, QWidget, QLabel, QPushButton, QLineEdit,
        QComboBox, QSpinBox, QAbstractSpinBox, QCheckBox, QListWidget,
        QListWidgetItem,
        QVBoxLayout, QHBoxLayout, QGridLayout, QFrame, QScrollArea, QDialog,
        QMessageBox, QFileDialog, QInputDialog, QMenu, QSystemTrayIcon,
        QAbstractItemView, QSizePolicy, QColorDialog,
    )
    _QT_OK = True
    _QT_ERR = None
except Exception as e:  # pragma: no cover
    _QT_OK = False
    _QT_ERR = f"{type(e).__name__}: {e}"

    class _MissingBase:
        def __init__(self, *a, **k):
            pass

    def _missing_signal(*a, **k):
        class _S:
            def connect(self, *a, **k): pass
            def emit(self, *a, **k): pass
        return _S()

    QObject = QMainWindow = QDialog = QWidget = _MissingBase  # noqa: N816
    Signal = _missing_signal                                   # noqa: N816

from engine import (
    Action, Macro, save_macros, load_macros, key_label, VER,
    TRIGGER_OPTS, LOOP_OPTS, CAPTURE_OPTS,
    LOOP_HOLD, LOOP_TOGGLE, LOOP_REPEAT, LOOP_ONCE,
    KD, KU, KPR, MM, MB_D, MB_U, MS, WT,
)
import hooks

APP = "macrobin"

# ── paths (frozen-aware, ported from 1.0.5) ──────────────────
def _get_app_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def _resource(relative):
    base = getattr(sys, "_MEIPASS", os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative)


def _find_icon() -> str:
    """Locate the app icon for the window and tray.

    Checks the PyInstaller bundle dir first (that's where the spec unpacks it),
    then the folder the app is running from. A named macrobin icon wins, but
    any .ico present is used rather than silently falling back to the drawn
    placeholder — so renaming the icon file doesn't quietly lose the branding.
    """
    roots = []
    bundled = getattr(sys, "_MEIPASS", None)
    if bundled:
        roots.append(bundled)
    roots.append(os.path.dirname(os.path.abspath(__file__)))
    roots.append(_get_app_dir())

    seen = set()
    for root in roots:
        if not root or root in seen:
            continue
        seen.add(root)
        for name in ("Macrobin.ico", "macrobin.ico", "icon.ico"):
            path = os.path.join(root, name)
            if os.path.exists(path):
                return path
        try:
            for entry in sorted(os.listdir(root)):
                if entry.lower().endswith(".ico"):
                    return os.path.join(root, entry)
        except Exception:
            pass
    return ""


SAVEF   = os.path.join(_get_app_dir(), "macros.json")
CONFIGF = os.path.join(_get_app_dir(), "config.json")
ICOF    = _find_icon()

# ── palettes (exact 1.0.5 values) ────────────────────────────
C_DEFAULT = dict(
    bg="#1c1c1c", panel="#252525", sidebar="#202020", widget="#2d2d2d",
    btn="#333333", btnhov="#3f3f3f", accent="#e91e8c", teal="#00d4ff",
    text="#dedede", dim="#808080", white="#ffffff", border="#3a3a3a",
    sel="#5a1040", green="#4caf50", red="#f44336", yellow="#ffab00",
    bar="#161616", tag_kb="#4caf50", tag_ms="#00d4ff", tag_wt="#ffab00",
    mac_a="#e91e8c", mac_b="#00d4ff", mac_c="#a855f7", mac_d="#4caf50",
)
C_AMOLED = dict(
    bg="#000000", panel="#0a0a0a", sidebar="#050505", widget="#111111",
    btn="#1e1e1e", btnhov="#404040", accent="#ffffff", teal="#444444",
    text="#e8e8e8", dim="#777777", white="#ffffff", border="#2a2a2a",
    sel="#3a3a3a", green="#aaaaaa", red="#dddddd", yellow="#bbbbbb",
    bar="#000000", tag_kb="#aaaaaa", tag_ms="#cccccc", tag_wt="#bbbbbb",
    mac_a="#ffffff", mac_b="#bbbbbb", mac_c="#888888", mac_d="#555555",
)
C_TERMINAL = dict(
    bg="#000000", panel="#001a00", sidebar="#000d00", widget="#002200",
    btn="#003300", btnhov="#005500", accent="#00ff41", teal="#00aa2a",
    text="#00e533", dim="#007a1a", white="#00ff41", border="#004400",
    sel="#004d00", green="#00ff41", red="#ff3333", yellow="#aaff00",
    bar="#000000", tag_kb="#00cc33", tag_ms="#00ff41", tag_wt="#aaff00",
    mac_a="#00ff41", mac_b="#00cc33", mac_c="#009922", mac_d="#006611",
)
C_CUSTOM = dict(C_DEFAULT)
THEMES = {
    "Default (Dark)":         C_DEFAULT,
    "AMOLED (Black & White)": C_AMOLED,
    "Terminal Green":         C_TERMINAL,
    "Custom":                 C_CUSTOM,
}
C = dict(C_DEFAULT)   # live palette

def _luminance(hex_color):
    h = hex_color.lstrip("#")
    try:
        r, g, b = int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)
    except Exception:
        return 0
    return 0.299 * r + 0.587 * g + 0.114 * b

def accent_fg():
    return "#000000" if _luminance(C["accent"]) > 100 else "#ffffff"

def teal_fg():
    return "#000000" if _luminance(C["teal"]) > 100 else "#ffffff"

# ── config.json (same keys as 1.0.5) ─────────────────────────
class Config:
    def __init__(self):
        self.theme = "Default (Dark)"
        self.close_to_tray = True

    def load(self):
        if not os.path.exists(CONFIGF):
            return
        try:
            with open(CONFIGF, "r", encoding="utf-8") as f:
                cfg = json.load(f)
            self.theme = cfg.get("theme", "Default (Dark)")
            self.close_to_tray = bool(cfg.get("close_to_tray", True))
            saved = cfg.get("custom_theme", {})
            if saved:
                C_CUSTOM.update({k: v for k, v in saved.items() if k in C_DEFAULT})
        except Exception:
            pass

    def save(self):
        try:
            with open(CONFIGF, "w", encoding="utf-8") as f:
                json.dump({"theme": self.theme,
                           "close_to_tray": self.close_to_tray,
                           "custom_theme": dict(C_CUSTOM)}, f, indent=2)
        except Exception:
            pass

CONFIG = Config()

# ── single instance (Windows named mutex, ported) ────────────
_MUTEX = None
def ensure_single_instance() -> bool:
    global _MUTEX
    if sys.platform != "win32":
        return True
    try:
        import ctypes
        _MUTEX = ctypes.windll.kernel32.CreateMutexW(None, True, "Global\\macrobin_instance")
        if ctypes.windll.kernel32.GetLastError() == 183:   # ERROR_ALREADY_EXISTS
            return False
    except Exception:
        pass
    return True

# ── stylesheet built from the live palette ───────────────────
_QSS_TEMPLATE = """
QWidget { background: @bg@; color: @text@; font-family: 'Segoe UI'; font-size: 9pt; }
QFrame#Bar { background: @bar@; }
QFrame#Panel { background: @panel@; }
QFrame#HLine { background: @border@; max-height: 1px; min-height: 1px; }
QFrame#AccentLine { background: @accent@; max-height: 1px; min-height: 1px; }
QLabel { background: transparent; }
QLabel#Accent { color: @accent@; }
QLabel#Dim { color: @dim@; }
QLabel#White { color: @white@; }
QLineEdit, QSpinBox, QComboBox {
  background: @widget@; color: @white@; border: 2px solid @border@;
  border-radius: 10px; padding: 4px 8px; selection-background-color: @sel@;
  min-height: 22px;
}
QLineEdit:focus, QSpinBox:focus { border-color: @accent@; }
QLineEdit:read-only { color: @text@; }

@SPINCOMBO@
QComboBox QAbstractItemView {
  background: @widget@; color: @text@; border: 1px solid @border@;
  selection-background-color: @sel@; selection-color: @white@; outline: none;
}
QPushButton {
  background: @btn@; color: @text@; border: none; border-radius: 10px;
  padding: 7px 12px;
}
QPushButton:hover { background: @btnhov@; }
QPushButton:disabled { color: @dim@; }
QListWidget {
  background: @bg@; color: @text@; border: none; outline: none;
  font-family: 'Consolas'; font-size: 9pt;
}
QListWidget::item { padding: 2px 4px; }
QListWidget::item:selected { background: @sel@; color: @white@; }
QScrollArea { border: none; background: @bg@; }
QScrollBar:vertical { background: transparent; width: 10px; margin: 2px; }
QScrollBar::handle:vertical { background: @border@; border-radius: 5px; min-height: 24px; }
QScrollBar::handle:vertical:hover { background: @accent@; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical { background: transparent; }
QMenu { background: @widget@; color: @text@; border: 1px solid @border@; }
QMenu::item:selected { background: @sel@; color: @white@; }
QToolTip { background: @widget@; color: @text@; border: 1px solid @border@; }
QCheckBox { background: transparent; color: @text@; }
QCheckBox::indicator { width: 15px; height: 15px; border: 2px solid @border@;
  border-radius: 4px; background: @widget@; }
QCheckBox::indicator:checked { background: @accent@; border-color: @accent@; }
QMessageBox { background: @panel@; }
"""

# Spin/combo sub-controls. Two variants: the themed one needs real arrow
# images (Qt's stylesheet engine can't draw CSS triangles), the plain one is
# the fallback if generating those images fails for any reason.
_QSS_SPINCOMBO_THEMED = """
/* The +/- steppers are real QPushButtons placed next to the field (see
   spin_with_buttons). Qt ignores percentage heights on these sub-controls, so
   styling them stacked both buttons in the same rect: one arrow was painted
   over the other and the clicks went to the wrong one. */
QSpinBox::up-button, QSpinBox::down-button { width: 0; height: 0; border: none; }

QComboBox { padding-right: 32px; }
QComboBox::drop-down {
  subcontrol-origin: border; subcontrol-position: center right; width: 26px;
  background: @btn@; border: none; border-left: 2px solid @border@;
  border-top-right-radius: 8px; border-bottom-right-radius: 8px;
}
QComboBox::drop-down:hover { background: @btnhov@; }
QComboBox::down-arrow { image: url("@down@"); width: 9px; height: 6px; }
QComboBox:focus, QComboBox:on {
  background: @sel@; color: @white@; border-color: @accent@;
}
"""

_QSS_SPINCOMBO_PLAIN = """
QSpinBox::up-button, QSpinBox::down-button { width: 0; height: 0; border: none; }
QComboBox { padding-right: 26px; }
QComboBox::drop-down {
  subcontrol-origin: border; subcontrol-position: center right;
  width: 22px; border: none; background: transparent;
}
QComboBox:focus, QComboBox:on {
  background: @sel@; color: @white@; border-color: @accent@;
}
"""

_ARROW_DIR = os.path.join(tempfile.gettempdir(), "macrobin_ui")


def _arrow_icons():
    """Render the up/down arrows to small PNGs in the temp dir and return their
    paths. Qt stylesheets can only take arrows as images, so this is how the
    spinners and combos get arrows that match the theme's text colour instead
    of the platform's default ones."""
    try:
        os.makedirs(_ARROW_DIR, exist_ok=True)
        col = QColor(C["text"])
        out = []
        for name, up in (("up", True), ("down", False)):
            fp = os.path.join(_ARROW_DIR, f"{name}_{col.name().lstrip('#')}.png")
            if not os.path.exists(fp):
                pm = QPixmap(9, 6)
                pm.fill(QColor(0, 0, 0, 0))
                p = QPainter(pm)
                p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
                p.setPen(Qt.PenStyle.NoPen)
                p.setBrush(QBrush(col))
                pts = ([QPoint(0, 5), QPoint(8, 5), QPoint(4, 0)] if up
                       else [QPoint(0, 0), QPoint(8, 0), QPoint(4, 5)])
                p.drawPolygon(QPolygon(pts))
                p.end()
                pm.save(fp, "PNG")
            out.append(fp.replace("\\", "/"))
        return out[0], out[1]
    except Exception:
        return None, None


def build_qss() -> str:
    up, down = _arrow_icons()
    if up and down:
        spin = _QSS_SPINCOMBO_THEMED.replace("@up@", up).replace("@down@", down)
    else:
        spin = _QSS_SPINCOMBO_PLAIN
    t = _QSS_TEMPLATE.replace("@SPINCOMBO@", spin)
    for k, v in C.items():
        t = t.replace(f"@{k}@", v)
    return t

def app_icon() -> "QIcon":
    if ICOF and os.path.exists(ICOF):
        ic = QIcon(ICOF)
        if not ic.isNull():
            return ic
    # drawn fallback (same motif as 1.0.5's generated tray icon)
    pm = QPixmap(64, 64)
    pm.fill(QColor(0, 0, 0, 0))
    p = QPainter(pm)
    p.setRenderHint(QPainter.RenderHint.Antialiasing, True)
    p.setBrush(QBrush(QColor("#1c1c1c")))
    p.setPen(Qt.PenStyle.NoPen)
    p.drawEllipse(2, 2, 60, 60)
    pen = QPen(QColor("#e91e8c")); pen.setWidth(4)
    p.setPen(pen); p.setBrush(Qt.BrushStyle.NoBrush)
    p.drawEllipse(4, 4, 56, 56)
    p.setPen(Qt.PenStyle.NoPen); p.setBrush(QBrush(QColor("#ffffff")))
    from PySide6.QtGui import QPolygon
    from PySide6.QtCore import QPoint
    p.drawPolygon(QPolygon([QPoint(24, 19), QPoint(24, 45), QPoint(46, 32)]))
    p.end()
    return QIcon(pm)

# ── thread -> GUI bridge ─────────────────────────────────────
class Bridge(QObject):
    status = Signal(str, str)          # msg, level ("green"/"yellow"/"red"/"")
    active = Signal(object)            # set of id(macro)
    armed = Signal(bool)
    recording = Signal(bool)
    actionRecorded = Signal()
    captured = Signal(str)             # one-shot bind result (raw pynput str)


# ── keyboard navigation is disabled app-wide ─────────────────
_NAV_FILTER = None
_NAV_KEYS = None


def _nav_keys():
    global _NAV_KEYS
    if _NAV_KEYS is None:
        k = Qt.Key
        _NAV_KEYS = {
            k.Key_Tab, k.Key_Backtab, k.Key_Up, k.Key_Down, k.Key_Left,
            k.Key_Right, k.Key_Space, k.Key_Return, k.Key_Enter, k.Key_Select,
            k.Key_Home, k.Key_End, k.Key_PageUp, k.Key_PageDown,
        }
    return _NAV_KEYS


class NoKeyNav(QObject):
    """Blocks keyboard navigation across the whole app: Tab, the arrow keys,
    Space and Enter never move focus or activate a control, so the UI is
    mouse-driven only. Typing still works inside text fields and spin boxes,
    and Esc still closes dialogs."""

    def eventFilter(self, obj, ev):
        try:
            if ev.type() == QEvent.Type.KeyPress:
                w = QApplication.focusWidget()
                # Editable fields keep every key so people can still type.
                if isinstance(w, QSpinBox):
                    return False
                if isinstance(w, QLineEdit) and not w.isReadOnly():
                    return False
                if ev.key() in _nav_keys():
                    return True
        except Exception:
            pass
        return False

# ── small widget helpers ─────────────────────────────────────
def hline(obj="HLine") -> "QFrame":
    f = QFrame(); f.setObjectName(obj); f.setFixedHeight(1)
    return f

def section_header(title: str) -> "QWidget":
    w = QWidget(); lay = QHBoxLayout(w)
    lay.setContentsMargins(12, 10, 12, 6)
    lab = QLabel(title.upper()); lab.setObjectName("Accent")
    f = lab.font(); f.setPointSize(7); f.setBold(True); lab.setFont(f)
    lay.addWidget(lab)
    ln = hline("AccentLine")
    lay.addWidget(ln, 1)
    return w

def _mix(a: str, b: str, t: float) -> str:
    """Blend hex colour a toward b by t (0..1)."""
    ah, bh = a.lstrip("#"), b.lstrip("#")
    try:
        ar, ag, ab = int(ah[0:2], 16), int(ah[2:4], 16), int(ah[4:6], 16)
        br, bg, bb = int(bh[0:2], 16), int(bh[2:4], 16), int(bh[4:6], 16)
    except Exception:
        return a
    m = lambda x, y: max(0, min(255, int(round(x + (y - x) * t))))
    return "#%02x%02x%02x" % (m(ar, br), m(ag, bg), m(ab, bb))


def hover_of(bg: str, amount: float = 0.18) -> str:
    """A hover shade derived from the button's OWN colour: dark colours lighten,
    light ones darken. Previously every button hovered to the same grey, so a
    pink or teal button lost its colour and its label could vanish against it."""
    return _mix(bg, "#ffffff" if _luminance(bg) < 128 else "#000000", amount)


def style_btn(b: "QPushButton", bg: str, fg: str, bold=False, pt=9, pad="7px 12px"):
    # Hover does two things at once so it reads on every theme: a stronger
    # shift of the button's OWN colour, plus an outline. On AMOLED a white
    # button darkening slightly was almost invisible; the outline isn't.
    edge = _mix(bg, "#ffffff" if _luminance(bg) < 128 else "#000000", 0.70)
    b.setStyleSheet(
        f"QPushButton {{ background: {bg}; color: {fg};"
        f" border: 2px solid {bg}; border-radius: 10px; padding: {pad};"
        f" font-size: {pt}pt; font-weight: {'600' if bold else '400'}; }}"
        f"QPushButton:hover {{ background: {hover_of(bg, 0.30)}; color: {fg};"
        f" border-color: {edge}; }}"
        f"QPushButton:pressed {{ background: {hover_of(bg, 0.45)}; color: {fg};"
        f" border-color: {edge}; }}"
        f"QPushButton:disabled {{ color: {C['dim']}; background: {C['btn']};"
        f" border-color: {C['btn']}; }}")

_MAC_COLORS = ["mac_a", "mac_b", "mac_c", "mac_d"]


def spin_with_buttons(spin: "QSpinBox", width: int = 0) -> "QWidget":
    """Wrap a QSpinBox with our own down/up buttons and return the container.

    Qt's built-in spin sub-controls can't be laid out reliably from a
    stylesheet (percentage heights are ignored, so both buttons collapse into
    the same rect). Real QPushButtons sidestep that entirely and are styled by
    the same style_btn() as every other button, so they match the rest of the
    UI exactly."""
    spin.setButtonSymbols(QAbstractSpinBox.ButtonSymbols.NoButtons)
    spin.setAlignment(Qt.AlignmentFlag.AlignVCenter)
    if width:
        spin.setFixedWidth(width)
    w = QWidget()
    lay = QHBoxLayout(w)
    lay.setContentsMargins(0, 0, 0, 0)
    lay.setSpacing(4)
    lay.addWidget(spin, 1)
    for glyph, delta, tip in (("\u25bc", -1, "Decrease"), ("\u25b2", 1, "Increase")):
        b = QPushButton(glyph)
        b.setToolTip(tip)
        b.setFixedSize(QSize(30, 30))
        b.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        b.setAutoDefault(False)
        b.setAutoRepeat(True)
        b.setAutoRepeatDelay(350)
        b.setAutoRepeatInterval(60)
        style_btn(b, C["btn"], C["text"], pt=8, pad="0px")
        b.clicked.connect(
            lambda _=False, s=spin, d=delta: s.setValue(s.value() + d * s.singleStep()))
        lay.addWidget(b)
    return w

# Short labels for the macro-list subtitle. The old code did loop.split()[0],
# which turned "While Holding Key" into a dangling "While".
LOOP_SHORT = {
    LOOP_HOLD: "Hold",
    LOOP_TOGGLE: "Toggle",
    LOOP_REPEAT: "Repeat N",
    LOOP_ONCE: "Once",
}

# ═════════════════════ MAIN WINDOW ═══════════════════════
class MainWindow(QMainWindow):
    def __init__(self, runtime, bridge):
        super().__init__()
        self.runtime = runtime
        self.bridge = bridge
        self.macros: list = []
        self.cur = -1
        self.editor = None
        self._active_ids: set = set()
        self._rows: list = []
        self._status_timer = QTimer(self); self._status_timer.setSingleShot(True)
        self._status_timer.timeout.connect(lambda: self._set_status("Ready", ""))

        self.setWindowTitle(APP)
        self.resize(500, 580)
        self.setMinimumSize(400, 380)

        self._build_ui()
        self._wire()
        self._load()
        if not self.macros:
            self.macros.append(Macro("Macro 1"))
            self.cur = 0
        self._push_macros()
        self.rebuild_tabs()
        self._setup_tray()

    # ---- UI ---------------------------------------------------------------
    def _build_ui(self):
        central = QWidget(); self.setCentralWidget(central)
        v = QVBoxLayout(central); v.setContentsMargins(0, 0, 0, 0); v.setSpacing(0)

        hdr = QFrame(); hdr.setObjectName("Bar")
        h = QHBoxLayout(hdr); h.setContentsMargins(12, 12, 10, 12)
        t = QLabel("  " + APP); t.setObjectName("Accent")
        f = t.font(); f.setPointSize(13); f.setBold(True); t.setFont(f)
        h.addWidget(t); h.addStretch(1)
        vr = QLabel(f"v{VER}"); vr.setObjectName("Dim")
        fv = vr.font(); fv.setPointSize(8); vr.setFont(fv)
        h.addWidget(vr)
        v.addWidget(hdr); v.addWidget(hline())

        self.scroll = QScrollArea(); self.scroll.setWidgetResizable(True)
        self.list_host = QWidget()
        self.list_lay = QVBoxLayout(self.list_host)
        self.list_lay.setContentsMargins(0, 0, 0, 0); self.list_lay.setSpacing(0)
        self.list_lay.addStretch(1)
        self.scroll.setWidget(self.list_host)
        v.addWidget(self.scroll, 1)

        v.addWidget(hline())
        bot = QWidget(); b = QHBoxLayout(bot); b.setContentsMargins(12, 10, 12, 10)
        self.sys_btn = QPushButton("Disable System")
        self.sys_btn.clicked.connect(self._toggle_system)
        self.add_btn = QPushButton("+ Add New Macro")
        self.add_btn.clicked.connect(self._new_macro)
        b.addWidget(self.sys_btn, 1); b.addWidget(self.add_btn, 1)
        v.addWidget(bot)

        v.addWidget(hline())
        sb = QFrame(); sb.setObjectName("Bar")
        s = QHBoxLayout(sb); s.setContentsMargins(10, 4, 6, 4)
        self.status_lbl = QLabel("Ready"); self.status_lbl.setObjectName("Dim")
        fs = self.status_lbl.font(); fs.setPointSize(8); self.status_lbl.setFont(fs)
        s.addWidget(self.status_lbl); s.addStretch(1)
        if not hooks.pynput_available():
            warn = QLabel("\u26a0 pynput not installed"); s.addWidget(warn)
            warn.setStyleSheet(f"color: {C['yellow']}; font-size: 8pt;")
        gear = QPushButton("Settings")
        gear.setFixedHeight(26)
        gear.clicked.connect(self._settings_dlg)
        style_btn(gear, C["btn"], C["text"], pt=8, pad="2px 12px")
        s.addWidget(gear)
        v.addWidget(sb)
        self._refresh_chrome()

    def _refresh_chrome(self):
        style_btn(self.add_btn, C["accent"], accent_fg(), bold=True)
        armed = self.runtime.armed if self.runtime else False
        if armed:
            self.sys_btn.setText("Disable System")
            style_btn(self.sys_btn, C["btn"], C["white"])
        else:
            self.sys_btn.setText("Enable System")
            style_btn(self.sys_btn, C["green"],
                      "#000000" if _luminance(C["green"]) > 100 else "#ffffff")
        self.sys_btn.setEnabled(self.runtime is not None)

    # ---- bridge wiring ----------------------------------------------------
    def _wire(self):
        self.bridge.status.connect(self._set_status)
        self.bridge.active.connect(self._on_active)
        self.bridge.armed.connect(lambda a: self._refresh_chrome())

    def _set_status(self, msg, level=""):
        colors = {"green": C["green"], "yellow": C["yellow"], "red": C["red"]}
        self.status_lbl.setText(msg)
        self.status_lbl.setStyleSheet(
            f"color: {colors.get(level, C['dim'])}; font-size: 8pt;")
        if level == "green":
            self._status_timer.start(2500)

    def _on_active(self, ids):
        self._active_ids = set(ids or [])
        for i, (row, dot) in enumerate(self._rows):
            if i < len(self.macros):
                m = self.macros[i]
                run = id(m) in self._active_ids
                base = C[_MAC_COLORS[i % 4]] if m.enabled else C["dim"]
                dot.setStyleSheet(
                    f"color: {C['green'] if run else base}; font-size: 10pt;")
                dot.setToolTip("Running" if run else "")

    # ---- macro list -------------------------------------------------------
    def rebuild_tabs(self):
        while self.list_lay.count() > 1:
            item = self.list_lay.takeAt(0)
            w = item.widget()
            if w:
                w.deleteLater()
        self._rows = []
        if not self.macros:
            empty = QLabel('There are no macros yet.\nClick "+ Add New Macro" to create one.')
            empty.setObjectName("Dim")
            empty.setAlignment(Qt.AlignmentFlag.AlignCenter)
            self.list_lay.insertWidget(0, empty)
            return
        for i, m in enumerate(self.macros):
            self.list_lay.insertWidget(i * 2, self._make_row(i, m))
            self.list_lay.insertWidget(i * 2 + 1, hline())
        self._on_active(self._active_ids)

    def _make_row(self, i, m):
        sel = (i == self.cur)
        enabled = m.enabled
        ind = C[_MAC_COLORS[i % 4]] if enabled else C["dim"]
        item_bg = C["widget"] if sel else C["bg"]
        name_fg = (C["white"] if sel else C["text"]) if enabled else C["dim"]
        info_fg = (C["teal"] if m.bind_key else C["dim"]) if enabled else C["dim"]

        row = QFrame()
        row.setObjectName("MacroRow")
        # Scope the rule to this frame by name — a bare "QFrame {...}" also
        # restyled the child frames/labels, which is why the highlight stopped
        # partway across the row.
        row.setStyleSheet(
            f"QFrame#MacroRow {{ background: {item_bg}; }}"
            f"QFrame#MacroRow:hover {{ background: {hover_of(item_bg, 0.16)}; }}")
        h = QHBoxLayout(row); h.setContentsMargins(0, 0, 10, 0); h.setSpacing(0)

        bar = QFrame(); bar.setFixedWidth(4)
        bar.setStyleSheet(f"background: {ind};")
        h.addWidget(bar)

        dot = QLabel("\u25cf")
        dot.setStyleSheet(f"color: {ind}; font-size: 10pt; background: transparent;")
        dot.setContentsMargins(10, 0, 10, 0)
        h.addWidget(dot)

        info = QWidget(); info.setStyleSheet("background: transparent;")
        iv = QVBoxLayout(info)
        iv.setContentsMargins(0, 12, 0, 12); iv.setSpacing(1)
        name = QLabel(m.name)
        nf = name.font(); nf.setPointSize(10); nf.setBold(sel); name.setFont(nf)
        name.setStyleSheet(f"color: {name_fg}; background: transparent;")
        iv.addWidget(name)
        bind_str = key_label(m.bind_key) if m.bind_key else "No key bound"
        sub = QLabel(f"{bind_str}  \u00b7  {LOOP_SHORT.get(m.loop, m.loop)}")
        sf = sub.font(); sf.setPointSize(7); sub.setFont(sf)
        sub.setStyleSheet(f"color: {info_fg}; background: transparent;")
        iv.addWidget(sub)
        h.addWidget(info, 1)

        # Text buttons rather than emoji: the old pencil/trash glyphs fell back
        # to tofu boxes in Segoe UI and the trash was clipped by the row edge.
        h.addSpacing(6)
        tog = QPushButton("On" if enabled else "Off")
        tog.setToolTip("Disable macro" if enabled else "Enable macro")
        tog.setFixedSize(QSize(44, 30))
        style_btn(tog, C["teal"] if enabled else C["btn"],
                  teal_fg() if enabled else C["dim"], bold=True, pt=8)
        tog.clicked.connect(lambda _, idx=i: self._toggle_enabled(idx))
        h.addWidget(tog)

        h.addSpacing(6)
        edit = QPushButton("Edit"); edit.setToolTip("Edit macro")
        edit.setFixedSize(QSize(50, 30))
        style_btn(edit, C["btn"], C["text"], pt=8)
        edit.clicked.connect(lambda _, idx=i: self.open_editor(idx))
        h.addWidget(edit)

        h.addSpacing(6)
        dele = QPushButton("Delete"); dele.setToolTip("Delete macro")
        dele.setFixedSize(QSize(60, 30))
        style_btn(dele, C["btn"], C["text"], pt=8)
        dele.clicked.connect(lambda _, idx=i: self._del_macro(idx))
        h.addWidget(dele)

        def press(ev, idx=i):
            self._select(idx)
        def dbl(ev, idx=i):
            self.open_editor(idx)
        for w in (row, dot, info, name, sub):
            w.mousePressEvent = press
            w.mouseDoubleClickEvent = dbl
        self._rows.append((row, dot))
        return row

    def _select(self, idx):
        self.cur = idx
        self.rebuild_tabs()

    def _new_macro(self):
        m = Macro(f"Macro {len(self.macros) + 1}")
        self.macros.append(m)
        self.cur = len(self.macros) - 1
        self._push_macros()
        self.rebuild_tabs()
        self.open_editor(self.cur)

    def _del_macro(self, idx):
        if len(self.macros) == 1:
            QMessageBox.warning(self, "Cannot Delete", "Need at least one macro.")
            return
        if not (0 <= idx < len(self.macros)):
            return
        m = self.macros[idx]
        r = QMessageBox.question(self, "Delete", f"Delete '{m.name}'?",
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if r != QMessageBox.StandardButton.Yes:
            return
        if self.runtime:
            self.runtime.stop(m)
        if self.editor and self.editor.macro is m:
            self.editor.close_silent()
        self.macros.pop(idx)
        self.cur = min(idx, len(self.macros) - 1)
        self._push_macros()
        self.save()
        self.rebuild_tabs()

    def _toggle_enabled(self, idx):
        if not (0 <= idx < len(self.macros)):
            return
        m = self.macros[idx]
        m.enabled = not m.enabled
        if not m.enabled and self.runtime:
            self.runtime.stop(m)
        self._push_macros()
        self.save()
        self.rebuild_tabs()

    def _toggle_system(self):
        if not self.runtime:
            return
        self.runtime.arm(not self.runtime.armed)
        self._refresh_chrome()

    # ---- editor -----------------------------------------------------------
    def open_editor(self, idx):
        if not (0 <= idx < len(self.macros)):
            return
        self.cur = idx
        self.rebuild_tabs()
        if self.editor is None:
            self.editor = EditorWindow(self)
        self.editor.load_macro(self.macros[idx])
        self.editor.show()
        self.editor.raise_()
        self.editor.activateWindow()

    def editor_closed(self):
        self.editor = None
        self.save()
        self.rebuild_tabs()

    # ---- persistence ------------------------------------------------------
    def _push_macros(self):
        if self.runtime:
            self.runtime.set_macros(self.macros)

    def save(self):
        try:
            save_macros(SAVEF, self.macros)
            self._set_status("Saved \u2714", "green")
        except Exception as e:
            QMessageBox.critical(self, "Save Error", str(e))

    def _load(self):
        if not os.path.exists(SAVEF):
            return
        try:
            self.macros = load_macros(SAVEF)
            if self.macros:
                self.cur = 0
        except Exception as e:
            QMessageBox.warning(self, APP, f"Could not load macros.json:\n{e}")

    # ---- settings / theming ----------------------------------------------
    def _settings_dlg(self):
        SettingsDialog(self).exec()

    def retheme(self):
        app = QApplication.instance()
        if app:
            app.setStyleSheet(build_qss())
        reopen = None
        if self.editor is not None:
            reopen = self.editor.macro
            self.editor.close_silent()
        self._refresh_chrome()
        self.rebuild_tabs()
        CONFIG.save()
        if reopen is not None and reopen in self.macros:
            self.open_editor(self.macros.index(reopen))

    # ---- tray / close -----------------------------------------------------
    def _setup_tray(self):
        self.tray = None
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray = QSystemTrayIcon(app_icon(), self)
        menu = QMenu()
        a_show = QAction("Show macrobin", menu)
        a_show.triggered.connect(self._restore)
        a_quit = QAction("Quit", menu)
        a_quit.triggered.connect(self.quit_app)
        menu.addAction(a_show)
        menu.addSeparator()
        menu.addAction(a_quit)
        self.tray.setContextMenu(menu)
        self.tray.setToolTip(APP)
        self.tray.activated.connect(
            lambda reason: self._restore()
            if reason == QSystemTrayIcon.ActivationReason.Trigger else None)

    def _restore(self):
        self.showNormal()
        self.raise_()
        self.activateWindow()

    def closeEvent(self, ev):
        if self.tray is not None and CONFIG.close_to_tray:
            ev.ignore()
            self.hide()
            self.tray.show()
        else:
            self.quit_app()
            ev.accept()

    def quit_app(self):
        if self.editor is not None:
            self.editor.commit_fields()
            self.editor.close_silent()
        try:
            save_macros(SAVEF, self.macros)
        except Exception:
            pass
        CONFIG.save()
        if self.runtime:
            self.runtime.shutdown()
        if self.tray is not None:
            self.tray.hide()
        app = QApplication.instance()
        if app:
            app.quit()


# ═════════════════════ EDITOR WINDOW ═════════════════════
class EditorWindow(QMainWindow):
    def __init__(self, main: MainWindow):
        super().__init__()
        self.main = main
        self.runtime = main.runtime
        self.bridge = main.bridge
        self.macro: Macro = None
        self.sel: list = []
        self._cap_slot = None
        self._cap_guard = 0.0
        self._loading = False
        self._blink_on = False
        self._blink = QTimer(self); self._blink.setInterval(500)
        self._blink.timeout.connect(self._do_blink)

        self.setWindowTitle(f"{APP} \u2014 Macro Editor")
        self.resize(1060, 660)
        self.setMinimumSize(860, 520)
        self._build_ui()

        self.bridge.recording.connect(self._on_recording)
        self.bridge.actionRecorded.connect(self._on_action_recorded)
        self.bridge.active.connect(self._on_active)
        self.bridge.status.connect(self._set_status)

    # ---- UI ---------------------------------------------------------------
    def _build_ui(self):
        central = QWidget(); self.setCentralWidget(central)
        h = QHBoxLayout(central); h.setContentsMargins(0, 0, 0, 0); h.setSpacing(0)

        # left panel
        lp = QFrame(); lp.setObjectName("Panel"); lp.setFixedWidth(380)
        lv = QVBoxLayout(lp); lv.setContentsMargins(0, 0, 0, 0); lv.setSpacing(0)

        nb = QFrame(); nb.setObjectName("Bar")
        nbl = QHBoxLayout(nb); nbl.setContentsMargins(12, 10, 12, 10)
        lab = QLabel("Macro Name"); lab.setObjectName("Dim")
        fl = lab.font(); fl.setPointSize(8); lab.setFont(fl)
        nbl.addWidget(lab)
        lv.addWidget(nb)

        nr = QWidget(); nrl = QHBoxLayout(nr); nrl.setContentsMargins(10, 6, 10, 6)
        self.name_edit = QLineEdit(); self.name_edit.setPlaceholderText("Macro name\u2026")
        self.name_edit.editingFinished.connect(self._name_changed)
        nrl.addWidget(self.name_edit)
        lv.addWidget(nr)
        lv.addWidget(hline())

        mid = QScrollArea(); mid.setWidgetResizable(True)
        mid_host = QWidget(); mid_host.setObjectName("Panel")
        mv = QVBoxLayout(mid_host); mv.setContentsMargins(0, 0, 0, 8); mv.setSpacing(0)
        self._build_trigger_section(mv)
        mv.addWidget(hline())
        self._build_record_section(mv)
        mv.addStretch(1)
        mid.setWidget(mid_host)
        lv.addWidget(mid, 1)

        lv.addWidget(hline())
        lb = QWidget(); lbl = QHBoxLayout(lb); lbl.setContentsMargins(12, 10, 12, 10)
        self.save_btn = QPushButton("Save")
        self.save_btn.clicked.connect(self._save_clicked)
        self.play_btn = QPushButton("\u25b6  Play")
        self.play_btn.clicked.connect(self._toggle_play)
        lbl.addWidget(self.save_btn, 1); lbl.addWidget(self.play_btn, 1)
        lv.addWidget(lb)
        h.addWidget(lp)

        vline = QFrame(); vline.setFixedWidth(1)
        vline.setStyleSheet(f"background: {C['border']};")
        h.addWidget(vline)

        # right panel
        rp = QFrame(); rp.setObjectName("Panel")
        rv = QVBoxLayout(rp); rv.setContentsMargins(0, 0, 0, 0); rv.setSpacing(0)

        rh = QFrame(); rh.setObjectName("Bar")
        rhl = QHBoxLayout(rh); rhl.setContentsMargins(12, 10, 10, 10)
        ttl = QLabel("Action Editor"); ttl.setObjectName("White")
        ft = ttl.font(); ft.setPointSize(10); ft.setBold(True); ttl.setFont(ft)
        rhl.addWidget(ttl); rhl.addStretch(1)
        self.cnt_lbl = QLabel("0 actions"); self.cnt_lbl.setObjectName("Dim")
        fc = self.cnt_lbl.font(); fc.setPointSize(8); self.cnt_lbl.setFont(fc)
        rhl.addWidget(self.cnt_lbl)
        rv.addWidget(rh); rv.addWidget(hline())

        tbw = QWidget(); tb = QHBoxLayout(tbw)
        tb.setContentsMargins(6, 5, 6, 5); tb.setSpacing(3)
        # Text labels: the emoji toolbar glyphs rendered inconsistently (several
        # fell back to boxes) and got clipped inside 40px squares.
        tools = [
            ("Add", "Add a new action", self._add_dlg),
            ("Edit", "Edit the selected action", self._edit_dlg),
            ("Duplicate", "Duplicate the selected action(s)", self._duplicate),
            ("Delete", "Delete the selected action(s)", self._delete_sel),
            ("\u2191", "Move up", self._move_up),
            ("\u2193", "Move down", self._move_down),
            ("Add Wait", "Insert a wait step", self._wait_dlg),
            ("Stop All", "Stop playback and recording", self._stop_all),
            ("Export", "Export actions to JSON", self._export),
            ("Import", "Import actions from JSON", self._import),
        ]
        for txt, tip, cmd in tools:
            b = QPushButton(txt); b.setToolTip(tip)
            b.setFixedHeight(32)
            if txt in ("\u2191", "\u2193"):
                b.setFixedWidth(34)
            style_btn(b, C["btn"], C["text"], pt=9)
            b.clicked.connect(cmd)
            tb.addWidget(b)
        tb.addStretch(1)
        rv.addWidget(tbw); rv.addWidget(hline())

        chw = QWidget(); ch = QHBoxLayout(chw)
        ch.setContentsMargins(12, 4, 12, 0)
        for txt, stretch in [("#", 0), ("Type / Action", 1), ("Delay", 0)]:
            l = QLabel(txt); l.setObjectName("Dim")
            f8 = l.font(); f8.setPointSize(8); l.setFont(f8)
            if txt == "#":
                l.setFixedWidth(36)
            elif txt == "Delay":
                l.setFixedWidth(64)
            ch.addWidget(l, stretch)
        rv.addWidget(chw)

        self.lb = QListWidget()
        self.lb.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.lb.itemSelectionChanged.connect(self._sel_changed)
        self.lb.itemDoubleClicked.connect(lambda _: self._edit_dlg())
        self.lb.setContextMenuPolicy(Qt.ContextMenuPolicy.CustomContextMenu)
        self.lb.customContextMenuRequested.connect(self._ctx_menu)
        rv.addWidget(self.lb, 1)

        del_act = QAction(self.lb)
        del_act.setShortcut(QKeySequence(Qt.Key.Key_Delete))
        del_act.setShortcutContext(Qt.ShortcutContext.WidgetShortcut)
        del_act.triggered.connect(self._delete_sel)
        self.lb.addAction(del_act)

        rv.addWidget(hline())
        sbf = QFrame(); sbf.setObjectName("Bar")
        sl = QHBoxLayout(sbf); sl.setContentsMargins(10, 4, 10, 4)
        self.status_lbl = QLabel("Ready"); self.status_lbl.setObjectName("Dim")
        f9 = self.status_lbl.font(); f9.setPointSize(8); self.status_lbl.setFont(f9)
        sl.addWidget(self.status_lbl); sl.addStretch(1)
        if not hooks.pynput_available():
            w = QLabel("\u26a0 pynput not installed \u2014 pip install pynput")
            w.setStyleSheet(f"color: {C['yellow']}; font-size: 8pt;")
            sl.addWidget(w)
        rv.addWidget(sbf)
        h.addWidget(rp, 1)
        self._refresh_chrome()

    def _build_trigger_section(self, mv):
        mv.addWidget(section_header("Trigger Settings"))
        w = QWidget(); g = QVBoxLayout(w); g.setContentsMargins(14, 0, 14, 6)

        g.addWidget(QLabel("Trigger by"))
        self.trigger_combo = QComboBox(); self.trigger_combo.addItems(TRIGGER_OPTS)
        self.trigger_combo.currentIndexChanged.connect(self.commit_fields)
        g.addWidget(self.trigger_combo)

        g.addSpacing(6)
        g.addWidget(QLabel("Loop"))
        self.loop_combo = QComboBox(); self.loop_combo.addItems(LOOP_OPTS)
        self.loop_combo.currentIndexChanged.connect(self._loop_changed)
        g.addWidget(self.loop_combo)

        self.repeat_row = QWidget()
        rr = QHBoxLayout(self.repeat_row); rr.setContentsMargins(0, 4, 0, 0)
        rr.addWidget(QLabel("Repeat Count:"))
        self.repeat_spin = QSpinBox(); self.repeat_spin.setRange(1, 1000000)
        self.repeat_spin.valueChanged.connect(self.commit_fields)
        rr.addWidget(spin_with_buttons(self.repeat_spin, width=110)); rr.addStretch(1)
        g.addWidget(self.repeat_row)
        self.repeat_row.setVisible(False)

        g.addSpacing(6)
        g.addWidget(QLabel("Trigger / Bind Key"))
        kf = QWidget(); kl = QHBoxLayout(kf); kl.setContentsMargins(0, 0, 0, 0)
        self.bind_ent = QLineEdit(); self.bind_ent.setReadOnly(True)
        self.bind_ent.setFixedWidth(130)
        kl.addWidget(self.bind_ent)
        self.setkey_btn = QPushButton("Set Key")
        self.setkey_btn.setFocusPolicy(Qt.FocusPolicy.NoFocus)
        self.setkey_btn.clicked.connect(self._start_bind)
        kl.addWidget(self.setkey_btn)
        self.clrkey_btn = QPushButton("\u2715"); self.clrkey_btn.setFixedWidth(34)
        self.clrkey_btn.clicked.connect(self._clear_bind)
        kl.addWidget(self.clrkey_btn); kl.addStretch(1)
        g.addWidget(kf)
        mv.addWidget(w)

    def _build_record_section(self, mv):
        mv.addWidget(section_header("Record Actions"))
        w = QWidget(); g = QVBoxLayout(w); g.setContentsMargins(14, 0, 14, 8)

        g.addWidget(QLabel("Mouse Position Capture"))
        self.capture_combo = QComboBox(); self.capture_combo.addItems(CAPTURE_OPTS)
        self.capture_combo.currentIndexChanged.connect(self.commit_fields)
        g.addWidget(self.capture_combo)

        g.addSpacing(8)
        grid = QGridLayout(); grid.setSpacing(8)
        self._toggles = {}
        for n, (key, label) in enumerate([
                ("rec_move", "Mouse Movement"),
                ("rec_btn",  "Mouse Buttons"),
                ("rec_kb",   "Keyboard Keys"),
                ("rec_wait", "Wait Time / Delays")]):
            b = QPushButton(label); b.setCheckable(True)
            b.setMinimumHeight(36)
            b.toggled.connect(self._toggles_changed)
            grid.addWidget(b, n // 2, n % 2)
            self._toggles[key] = b
        g.addLayout(grid)

        g.addSpacing(8)
        dr = QHBoxLayout()
        dr.addWidget(QLabel("Ignore delays less than:"))
        self.min_delay_spin = QSpinBox(); self.min_delay_spin.setRange(0, 60000)
        self.min_delay_spin.valueChanged.connect(self.commit_fields)
        dr.addWidget(spin_with_buttons(self.min_delay_spin, width=76))
        dr.addWidget(QLabel("ms")); dr.addStretch(1)
        g.addLayout(dr)

        g.addSpacing(8)
        rr = QHBoxLayout()
        self.rec_btn = QPushButton(f"\u25cf  Record  [{hooks.RECORD_STOP_LABEL}]")
        self.rec_btn.setMinimumHeight(36)
        self.rec_btn.clicked.connect(self._toggle_rec)
        rr.addWidget(self.rec_btn)
        self.rec_dot = QLabel("\u25cf")
        self.rec_dot.setStyleSheet(f"color: {C['dim']}; font-size: 14pt;")
        rr.addWidget(self.rec_dot); rr.addStretch(1)
        g.addLayout(rr)
        mv.addWidget(w)

    def _refresh_chrome(self):
        style_btn(self.save_btn, C["btn"], C["white"], pt=10)
        self._refresh_play_btn(False)
        self._update_toggle_styles()
        has_input = hooks.pynput_available() and self.runtime is not None
        self.rec_btn.setEnabled(has_input)
        self.play_btn.setEnabled(has_input)

    # ---- load/commit ------------------------------------------------------
    def load_macro(self, m: Macro):
        if self.macro is not None and self.macro is not m:
            self.commit_fields()
        self.macro = m
        self._loading = True
        self.setWindowTitle(f"{APP} \u2014 {m.name}")
        self.name_edit.setText(m.name)
        self.trigger_combo.setCurrentIndex(
            TRIGGER_OPTS.index(m.trigger) if m.trigger in TRIGGER_OPTS else 0)
        self.loop_combo.setCurrentIndex(
            LOOP_OPTS.index(m.loop) if m.loop in LOOP_OPTS else 0)
        self.repeat_spin.setValue(m.repeat_n)
        self.repeat_row.setVisible(m.loop == LOOP_REPEAT)
        self.bind_ent.setText(key_label(m.bind_key) if m.bind_key else "")
        self.capture_combo.setCurrentIndex(
            CAPTURE_OPTS.index(m.capture) if m.capture in CAPTURE_OPTS else 0)
        self.min_delay_spin.setValue(m.min_delay)
        for k, b in self._toggles.items():
            b.setChecked(bool(getattr(m, k)))
        self._loading = False
        self._update_toggle_styles()
        self.refresh_list()
        self._refresh_play_btn(self.runtime.is_playing(m) if self.runtime else False)

    def commit_fields(self):
        if self._loading or self.macro is None:
            return
        m = self.macro
        m.name = self.name_edit.text().strip() or m.name
        m.trigger = self.trigger_combo.currentText()
        m.loop = self.loop_combo.currentText()
        m.repeat_n = self.repeat_spin.value()
        m.capture = self.capture_combo.currentText()
        m.min_delay = self.min_delay_spin.value()
        for k, b in self._toggles.items():
            setattr(m, k, b.isChecked())
        self.main._push_macros()
        self.main.rebuild_tabs()

    def _name_changed(self):
        self.commit_fields()
        if self.macro:
            self.setWindowTitle(f"{APP} \u2014 {self.macro.name}")

    def _loop_changed(self):
        self.repeat_row.setVisible(self.loop_combo.currentText() == LOOP_REPEAT)
        self.commit_fields()

    def _toggles_changed(self):
        self._update_toggle_styles()
        self.commit_fields()

    def _update_toggle_styles(self):
        for b in self._toggles.values():
            on = b.isChecked()
            bg = C["teal"] if on else C["btn"]
            fg = teal_fg() if on else C["dim"]
            style_btn(b, bg, fg, bold=True, pt=8)

    # ---- bind key ---------------------------------------------------------
    def _start_bind(self):
        if self.macro is None:
            return
        if not (hooks.pynput_available() and self.runtime):
            raw, ok = QInputDialog.getText(
                self, "Bind Key", "Key name (e.g. Key.f5, 'a', Button.middle):")
            if ok and raw:
                self._apply_bind(raw)
            return
        self.bind_ent.setText("Press key or mouse button\u2026")
        self.bind_ent.setStyleSheet(f"border-color: {C['accent']};")
        self._set_status("Waiting for key or mouse button\u2026", "yellow")

        self._drop_pending_capture()
        self._cap_slot = self._make_one_shot(self._finish_bind)
        self.bridge.captured.connect(self._cap_slot)
        self.runtime.start_bind(lambda raw: self.bridge.captured.emit(raw))

    def _make_one_shot(self, fn):
        def slot(raw):
            try:
                self.bridge.captured.disconnect(slot)
            except Exception:
                pass
            if getattr(self, '_cap_slot', None) is slot:
                self._cap_slot = None
            # The captured key also reaches Qt as a normal key event. Guard
            # briefly so it can't type into a field or re-press a button.
            self._cap_guard = time.monotonic() + 0.35
            fn(raw)
        return slot

    def keyPressEvent(self, ev):
        if getattr(self, "_cap_slot", None) is not None or \
                time.monotonic() < getattr(self, "_cap_guard", 0.0):
            ev.accept()
            return
        super().keyPressEvent(ev)

    def _drop_pending_capture(self):
        slot = getattr(self, '_cap_slot', None)
        if slot is not None:
            try:
                self.bridge.captured.disconnect(slot)
            except Exception:
                pass
            self._cap_slot = None

    def _finish_bind(self, raw):
        self.bind_ent.setStyleSheet("")
        if raw in ("Button.left", "Button.right"):
            self.bind_ent.setText(key_label(self.macro.bind_key) if self.macro.bind_key else "")
            self._set_status(
                f"{key_label(raw)} cannot be used as a trigger \u2014 choose a key or middle/side button.",
                "yellow")
            return
        if raw:
            self._apply_bind(raw)

    def _apply_bind(self, raw):
        for other in self.main.macros:
            if other is not self.macro and other.bind_key == raw:
                other.bind_key = ""
        self.macro.bind_key = raw
        self.bind_ent.setText(key_label(raw))
        self.main._push_macros()
        self.main.save()
        self.main.rebuild_tabs()
        self._set_status(f"Bound: {key_label(raw)}", "green")

    def _clear_bind(self):
        if self.runtime:
            self.runtime.cancel_bind()
        self._drop_pending_capture()
        self.bind_ent.setStyleSheet("")
        if self.macro:
            self.macro.bind_key = ""
        self.bind_ent.setText("")
        self.main._push_macros()
        self.main.rebuild_tabs()
        self._set_status("Key binding cleared", "")

    # ---- record -----------------------------------------------------------
    def _toggle_rec(self):
        if not self.runtime:
            return
        if self.runtime.recording:
            self.runtime.stop_record()
            return
        if self.macro is None:
            return
        if self.runtime.any_playing():
            QMessageBox.warning(self, "Busy", "Stop playback first.")
            return
        self.commit_fields()
        if self.macro.actions:
            box = QMessageBox(self)
            box.setWindowTitle("Recording")
            box.setText("Replace existing actions?")
            rep = box.addButton("Replace", QMessageBox.ButtonRole.YesRole)
            box.addButton("Append", QMessageBox.ButtonRole.NoRole)
            can = box.addButton("Cancel", QMessageBox.ButtonRole.RejectRole)
            box.exec()
            if box.clickedButton() is can:
                return
            if box.clickedButton() is rep:
                self.macro.actions.clear()
                self.refresh_list()
        self.runtime.start_record(self.macro)

    def _on_recording(self, rec: bool):
        if rec:
            self.rec_btn.setText(f"\u25a0  Stop Recording  [{hooks.RECORD_STOP_LABEL}]")
            style_btn(self.rec_btn, C["red"], "#ffffff", bold=True)
            self._blink.start()
        else:
            self.rec_btn.setText(f"\u25cf  Record  [{hooks.RECORD_STOP_LABEL}]")
            style_btn(self.rec_btn, C["btn"], C["white"], bold=True)
            self._blink.stop()
            self.rec_dot.setStyleSheet(f"color: {C['dim']}; font-size: 14pt;")
            self.refresh_list()
            self.main.save()
        self.main._refresh_chrome()

    def _do_blink(self):
        self._blink_on = not self._blink_on
        col = C["red"] if self._blink_on else C["panel"]
        self.rec_dot.setStyleSheet(f"color: {col}; font-size: 14pt;")

    def _on_action_recorded(self):
        if self.macro is None:
            return
        i = self.lb.count()
        if i < len(self.macro.actions):
            self._append_item(i, self.macro.actions[i])
            self.lb.scrollToBottom()
            self._update_count()

    # ---- play -------------------------------------------------------------
    def _toggle_play(self):
        if not self.runtime or self.macro is None:
            return
        if self.runtime.is_playing(self.macro):
            self.runtime.stop(self.macro)
            return
        if self.runtime.recording:
            return
        if not self.macro.actions:
            QMessageBox.information(self, "Empty", "No actions to play.")
            return
        self.commit_fields()
        self.runtime.play(self.macro)

    def _on_active(self, ids):
        if self.macro is None:
            return
        self._refresh_play_btn(id(self.macro) in set(ids or []))

    def _refresh_play_btn(self, playing: bool):
        if playing:
            self.play_btn.setText("\u25a0  Stop")
            style_btn(self.play_btn, C["accent"], accent_fg(), bold=True, pt=10)
        else:
            self.play_btn.setText("\u25b6  Play")
            style_btn(self.play_btn, C["teal"], teal_fg(), bold=True, pt=10)

    def _stop_all(self):
        if self.runtime:
            if self.runtime.recording:
                self.runtime.stop_record()
            self.runtime.stop_all()

    # ---- action list ------------------------------------------------------
    def refresh_list(self):
        self.lb.clear()
        if self.macro is None:
            return
        for i, a in enumerate(self.macro.actions):
            self._append_item(i, a)
        self._update_count()

    def _append_item(self, i, a: Action):
        delay = f"{a.delay:>5}ms" if a.delay else "       \u2014"
        item = QListWidgetItem(f"  {i + 1:>3}.   {a.label():<40}  {delay}")
        item.setForeground(QColor(C[a.color_key()]))
        self.lb.addItem(item)

    def _update_count(self):
        n = self.lb.count()
        self.cnt_lbl.setText(f"{n} action{'s' if n != 1 else ''}")

    def _sel_changed(self):
        self.sel = sorted(i.row() for i in self.lb.selectedIndexes())

    def _ctx_menu(self, pos):
        menu = QMenu(self)
        for spec in [("Edit", self._edit_dlg),
                     ("Duplicate", self._duplicate), None,
                     ("Move Up", self._move_up),
                     ("Move Down", self._move_down), None,
                     ("Delete", self._delete_sel),
                     ("Clear All", self._clear_all)]:
            if spec is None:
                menu.addSeparator()
            else:
                act = QAction(spec[0], menu)
                act.triggered.connect(spec[1])
                menu.addAction(act)
        menu.exec(self.lb.mapToGlobal(pos))

    def _add_dlg(self):
        if self.macro is None:
            return
        pos = (max(self.sel) + 1) if self.sel else None
        dlg = ActionDialog(self, self.macro, action=None, insert_after=pos)
        if dlg.exec() == QDialog.DialogCode.Accepted:
            self.refresh_list()
            self.main.save()

    def _edit_dlg(self):
        if self.macro is None or not self.sel:
            return
        idx = self.sel[0]
        if idx < len(self.macro.actions):
            dlg = ActionDialog(self, self.macro, action=self.macro.actions[idx], idx=idx)
            if dlg.exec() == QDialog.DialogCode.Accepted:
                self.refresh_list()
                self.lb.setCurrentRow(idx)
                self.main.save()

    def _duplicate(self):
        m = self.macro
        if not m or not self.sel:
            return
        for i in sorted(self.sel, reverse=True):
            if i < len(m.actions):
                m.actions.insert(i + 1, Action.from_dict(m.actions[i].to_dict()))
        self.refresh_list()

    def _delete_sel(self):
        m = self.macro
        if not m or not self.sel:
            return
        for i in sorted(self.sel, reverse=True):
            if i < len(m.actions):
                m.actions.pop(i)
        self.sel = []
        self.refresh_list()

    def _move_up(self):
        m = self.macro
        if not m or not self.sel:
            return
        i = self.sel[0]
        if i > 0:
            m.actions[i], m.actions[i - 1] = m.actions[i - 1], m.actions[i]
            self.refresh_list()
            self.lb.setCurrentRow(i - 1)

    def _move_down(self):
        m = self.macro
        if not m or not self.sel:
            return
        i = self.sel[0]
        if i < len(m.actions) - 1:
            m.actions[i], m.actions[i + 1] = m.actions[i + 1], m.actions[i]
            self.refresh_list()
            self.lb.setCurrentRow(i + 1)

    def _wait_dlg(self):
        m = self.macro
        if not m:
            return
        ms, ok = QInputDialog.getInt(self, "Add Wait", "Duration (ms):",
                                     500, 0, 600000)
        if not ok:
            return
        a = Action(WT, {"ms": ms}, 0)
        if self.sel:
            m.actions.insert(max(self.sel) + 1, a)
        else:
            m.actions.append(a)
        self.refresh_list()

    def _clear_all(self):
        m = self.macro
        if not m:
            return
        r = QMessageBox.question(self, "Clear All", "Delete all actions in this macro?",
                                 QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No)
        if r == QMessageBox.StandardButton.Yes:
            m.actions.clear()
            self.sel = []
            self.refresh_list()

    def _export(self):
        m = self.macro
        if not m:
            return
        path, _ = QFileDialog.getSaveFileName(
            self, "Export Actions", f"{m.name}_actions.json",
            "JSON (*.json);;All files (*)")
        if not path:
            return
        try:
            with open(path, "w", encoding="utf-8") as f:
                json.dump([a.to_dict() for a in m.actions], f, indent=2)
            self._set_status(f"Exported {len(m.actions)} actions.", "green")
        except Exception as e:
            QMessageBox.critical(self, "Export Error", str(e))

    def _import(self):
        m = self.macro
        if not m:
            return
        path, _ = QFileDialog.getOpenFileName(
            self, "Import Actions", "", "JSON (*.json);;All files (*)")
        if not path:
            return
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
            actions = [Action.from_dict(a) for a in data]
            m.actions.extend(actions)
            self.refresh_list()
            self._set_status(f"Imported {len(actions)} actions.", "green")
        except Exception as e:
            QMessageBox.critical(self, "Import Error", str(e))

    # ---- misc -------------------------------------------------------------
    def _save_clicked(self):
        self.commit_fields()
        self.main.save()
        self._set_status("Saved \u2714", "green")

    def _set_status(self, msg, level=""):
        colors = {"green": C["green"], "yellow": C["yellow"], "red": C["red"]}
        self.status_lbl.setText(msg)
        self.status_lbl.setStyleSheet(
            f"color: {colors.get(level, C['dim'])}; font-size: 8pt;")

    def close_silent(self):
        self._closing_silent = True
        self.close()
        self._closing_silent = False

    def closeEvent(self, ev):
        if self.runtime and self.runtime.recording:
            self.runtime.stop_record()
        if self.runtime:
            self.runtime.cancel_bind()
        self._drop_pending_capture()
        self.commit_fields()
        if not getattr(self, "_closing_silent", False):
            self.main.editor_closed()
        ev.accept()

# ═════════════════════ ACTION DIALOG ═════════════════════
class ActionDialog(QDialog):
    DISP_TYPES = ["Keyboard Key", "Mouse Button", "Mouse Move", "Wait"]
    KEY_STATUS = ["Press and Release", "Press / Hold", "Release"]
    _KS_TO_KIND = {"Press and Release": KPR, "Press / Hold": KD, "Release": KU}
    _KIND_TO_KS = {KD: "Press / Hold", KU: "Release", KPR: "Press and Release"}
    # Mouse buttons now offer the same three statuses as keys. The 1.0.5 file
    # format has no single "click" kind, so "Press and Release" is stored as a
    # Mouse Down followed by a Mouse Up — which keeps macros.json readable by
    # the old app and keeps every step visible/editable in the action list.
    BTN_STATUS = ["Press and Release", "Press / Hold", "Release"]
    _BS_TO_KIND = {"Press and Release": MB_D, "Press / Hold": MB_D, "Release": MB_U}
    _KIND_TO_BS = {MB_D: "Press / Hold", MB_U: "Release"}
    _KIND_TO_DISP = {KD: "Keyboard Key", KU: "Keyboard Key", KPR: "Keyboard Key",
                     MM: "Mouse Move", MB_D: "Mouse Button", MB_U: "Mouse Button",
                     WT: "Wait"}

    def __init__(self, editor, m: Macro, action=None, idx=None, insert_after=None):
        super().__init__(editor)
        self.editor = editor
        self.runtime = editor.runtime
        self.bridge = editor.bridge
        self.m = m
        self.action = action
        self.idx = idx
        self.insert_after = insert_after
        self.editing = action is not None
        self._pending_slot = None
        self._cap_guard = 0.0
        self._key_raw = action.data.get("key", "") if (self.editing and action.kind in (KD, KU, KPR)) else ""
        self._btn_raw = action.data.get("button", "Button.left") if (self.editing and action.kind in (MB_D, MB_U)) else "Button.left"

        self.setWindowTitle("Edit Action" if self.editing else "Add Action")
        self.setModal(True)
        self.setFixedWidth(390)

        v = QVBoxLayout(self)
        title = QLabel("Edit Action" if self.editing else "Add Action")
        tf = title.font(); tf.setPointSize(11); tf.setBold(True); title.setFont(tf)
        v.addWidget(title)

        self.type_combo = QComboBox(); self.type_combo.addItems(self.DISP_TYPES)
        init_disp = self._KIND_TO_DISP.get(action.kind, "Keyboard Key") if self.editing else "Keyboard Key"
        self.type_combo.setCurrentText(init_disp)
        if self.editing:
            self.type_combo.setVisible(False)
        else:
            v.addWidget(QLabel("Action Type:"))
            v.addWidget(self.type_combo)
        self.type_combo.currentIndexChanged.connect(self._rebuild_form)

        self.dyn = QWidget(); self.dyn_lay = QVBoxLayout(self.dyn)
        self.dyn_lay.setContentsMargins(0, 4, 0, 4)
        v.addWidget(self.dyn)

        dr = QHBoxLayout()
        dr.addWidget(QLabel("Delay before (ms):"))
        self.delay_spin = QSpinBox(); self.delay_spin.setRange(0, 600000)
        self.delay_spin.setValue(action.delay if self.editing else 0)
        dr.addWidget(spin_with_buttons(self.delay_spin, width=96)); dr.addStretch(1)
        v.addLayout(dr)

        bl = QHBoxLayout(); bl.addStretch(1)
        okb = QPushButton("Save" if self.editing else "Add")
        okb.setAutoDefault(False)
        style_btn(okb, C["accent"], accent_fg(), bold=True)
        okb.clicked.connect(self._commit)
        cb = QPushButton("Cancel"); cb.setAutoDefault(False); cb.clicked.connect(self.reject)
        bl.addWidget(okb); bl.addWidget(cb); bl.addStretch(1)
        v.addLayout(bl)

        self._rebuild_form()

    def _clear_dyn(self):
        while self.dyn_lay.count():
            it = self.dyn_lay.takeAt(0)
            w = it.widget()
            if w:
                w.deleteLater()
            elif it.layout():
                lay = it.layout()
                while lay.count():
                    sub = lay.takeAt(0)
                    if sub.widget():
                        sub.widget().deleteLater()

    def _cancel_capture(self):
        if self.runtime:
            self.runtime.cancel_bind()
        slot = getattr(self, '_pending_slot', None)
        if slot is not None:
            try:
                self.bridge.captured.disconnect(slot)
            except Exception:
                pass
            self._pending_slot = None

    def _rebuild_form(self):
        self._cancel_capture()
        self._clear_dyn()
        t = self.type_combo.currentText()

        if t == "Keyboard Key":
            self.dyn_lay.addWidget(QLabel("Key Status:"))
            self.ks_combo = QComboBox(); self.ks_combo.addItems(self.KEY_STATUS)
            if self.editing:
                self.ks_combo.setCurrentText(self._KIND_TO_KS.get(self.action.kind, "Press and Release"))
            self.dyn_lay.addWidget(self.ks_combo)
            self.dyn_lay.addWidget(QLabel("Key:"))
            row = QHBoxLayout()
            self.key_disp = QLineEdit(); self.key_disp.setReadOnly(True)
            self.key_disp.setFixedWidth(160)
            self.key_disp.setText(key_label(self._key_raw) if self._key_raw else "")
            row.addWidget(self.key_disp)
            cap = QPushButton("Capture Key"); cap.clicked.connect(self._capture_key)
            # No focus + no auto-default: otherwise the button keeps keyboard
            # focus after a capture, so capturing Space would immediately press
            # the button again and start a second capture.
            cap.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            cap.setAutoDefault(False)
            row.addWidget(cap)
            self.key_status = QLabel("")
            self.key_status.setStyleSheet(f"color: {C['yellow']}; font-size: 8pt;")
            row.addWidget(self.key_status); row.addStretch(1)
            self.dyn_lay.addLayout(row)

        elif t == "Mouse Move":
            self.dyn_lay.addWidget(QLabel("Position:"))
            row = QHBoxLayout()
            row.addWidget(QLabel("X:"))
            self.x_spin = QSpinBox(); self.x_spin.setRange(-100000, 100000)
            row.addWidget(spin_with_buttons(self.x_spin, width=72))
            row.addWidget(QLabel("Y:"))
            self.y_spin = QSpinBox(); self.y_spin.setRange(-100000, 100000)
            row.addWidget(spin_with_buttons(self.y_spin, width=72)); row.addStretch(1)
            if self.editing:
                self.x_spin.setValue(int(self.action.data.get("x", 0)))
                self.y_spin.setValue(int(self.action.data.get("y", 0)))
            self.dyn_lay.addLayout(row)
            self.pos_status = QLabel("")
            self.pos_status.setStyleSheet(f"color: {C['yellow']}; font-size: 8pt;")
            self.dyn_lay.addWidget(self.pos_status)
            capb = QPushButton("Capture from Mouse")
            capb.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            capb.setAutoDefault(False)
            capb.clicked.connect(self._capture_pos)
            self.dyn_lay.addWidget(capb)

        elif t == "Mouse Button":
            self.dyn_lay.addWidget(QLabel("Button Status:"))
            self.bs_combo = QComboBox(); self.bs_combo.addItems(self.BTN_STATUS)
            if self.editing:
                self.bs_combo.setCurrentText(
                    self._KIND_TO_BS.get(self.action.kind, "Press and Release"))
            self.dyn_lay.addWidget(self.bs_combo)
            self.dyn_lay.addWidget(QLabel("Mouse Button:"))
            row = QHBoxLayout()
            self.btn_disp = QLineEdit(); self.btn_disp.setReadOnly(True)
            self.btn_disp.setFixedWidth(130)
            self.btn_disp.setText(key_label(self._btn_raw))
            row.addWidget(self.btn_disp)
            capb = QPushButton("Capture Button"); capb.clicked.connect(self._capture_btn)
            capb.setFocusPolicy(Qt.FocusPolicy.NoFocus)
            capb.setAutoDefault(False)
            row.addWidget(capb)
            self.btn_status = QLabel("")
            self.btn_status.setStyleSheet(f"color: {C['yellow']}; font-size: 8pt;")
            row.addWidget(self.btn_status); row.addStretch(1)
            self.dyn_lay.addLayout(row)

        elif t == "Wait":
            self.dyn_lay.addWidget(QLabel("Duration (ms):"))
            self.ms_spin = QSpinBox(); self.ms_spin.setRange(0, 600000)
            self.ms_spin.setValue(int(self.action.data.get("ms", 500)) if self.editing else 500)
            self.dyn_lay.addWidget(spin_with_buttons(self.ms_spin))
        self.adjustSize()

    def _one_shot(self, fn):
        def slot(raw):
            try:
                self.bridge.captured.disconnect(slot)
            except Exception:
                pass
            if getattr(self, '_pending_slot', None) is slot:
                self._pending_slot = None
            # See EditorWindow._make_one_shot: swallow the trailing key event.
            self._cap_guard = time.monotonic() + 0.35
            fn(raw)
        return slot

    def keyPressEvent(self, ev):
        if getattr(self, "_pending_slot", None) is not None or \
                time.monotonic() < getattr(self, "_cap_guard", 0.0):
            ev.accept()
            return
        super().keyPressEvent(ev)

    def _begin(self, fn, status_widget, msg):
        if not (self.runtime and hooks.pynput_available()):
            raw, ok = QInputDialog.getText(self, "Enter Key",
                                           "Key name (e.g. Key.space, 'a', Key.f1):")
            if ok and raw:
                fn(raw)
            return
        self._cancel_capture()
        status_widget.setText(msg)
        slot = self._one_shot(fn)
        self._pending_slot = slot
        self.bridge.captured.connect(slot)
        self.runtime.start_bind(lambda raw: self.bridge.captured.emit(raw))

    def _capture_key(self):
        def got(raw):
            if raw.startswith("Button."):
                self._begin(got, self.key_status, "Press a key\u2026")
                return
            self._key_raw = raw
            self.key_disp.setText(key_label(raw))
            self.key_status.setText(f"\u2714 {key_label(raw)}")
        self._begin(got, self.key_status, "Press a key\u2026")

    def _capture_btn(self):
        def got(raw):
            if not raw.startswith("Button."):
                self._begin(got, self.btn_status, "Click a mouse button\u2026")
                return
            self._btn_raw = raw
            self.btn_disp.setText(key_label(raw))
            self.btn_status.setText(f"\u2714 {key_label(raw)}")
        self._begin(got, self.btn_status, "Click a mouse button\u2026")

    def _capture_pos(self):
        def got(_raw):
            x, y = self.runtime.mouse_position() if self.runtime else (0, 0)
            self.x_spin.setValue(int(x))
            self.y_spin.setValue(int(y))
            self.pos_status.setText(f"\u2714  ({int(x)}, {int(y)})")
        self._begin(got, self.pos_status,
                    "Move mouse to position, then press any key\u2026")

    def _commit(self):
        self._cancel_capture()
        t = self.type_combo.currentText()
        delay = self.delay_spin.value()
        pair_up = False          # True when a mouse "Press and Release" needs its Up
        try:
            if t == "Keyboard Key":
                if not self._key_raw:
                    QMessageBox.warning(self, "No Key", "Please capture a key first.")
                    return
                kind = self._KS_TO_KIND[self.ks_combo.currentText()]
                data = {"key": self._key_raw}
            elif t == "Mouse Move":
                kind = MM
                data = {"x": self.x_spin.value(), "y": self.y_spin.value()}
            elif t == "Mouse Button":
                status = self.bs_combo.currentText()
                kind = self._BS_TO_KIND[status]
                data = {"button": self._btn_raw}
                pair_up = (status == "Press and Release")
            else:
                kind = WT; data = {"ms": self.ms_spin.value()}
        except Exception as e:
            QMessageBox.critical(self, "Input Error", str(e))
            return

        if self.editing:
            self.action.kind = kind
            self.action.data = data
            self.action.delay = delay
            if pair_up:
                try:
                    at = self.m.actions.index(self.action)
                except ValueError:
                    at = self.idx if self.idx is not None else len(self.m.actions) - 1
                self.m.actions.insert(at + 1, Action(MB_U, dict(data), 0))
        else:
            a = Action(kind, data, delay)
            if self.insert_after is not None:
                self.m.actions.insert(self.insert_after, a)
                if pair_up:
                    self.m.actions.insert(self.insert_after + 1,
                                          Action(MB_U, dict(data), 0))
            else:
                self.m.actions.append(a)
                if pair_up:
                    self.m.actions.append(Action(MB_U, dict(data), 0))
        self.accept()

    def reject(self):
        self._cancel_capture()
        super().reject()

    def closeEvent(self, ev):
        self._cancel_capture()
        super().closeEvent(ev)


# ═════════════════════ SETTINGS DIALOG ═══════════════════
class SettingsDialog(QDialog):
    def __init__(self, main):
        super().__init__(main)
        self.main = main
        self.setWindowTitle("Settings")
        self.setModal(True)
        self.setFixedWidth(380)

        v = QVBoxLayout(self)
        t = QLabel("Settings")
        tf = t.font(); tf.setPointSize(12); tf.setBold(True); t.setFont(tf)
        t.setAlignment(Qt.AlignmentFlag.AlignHCenter)
        v.addWidget(t)

        for text in [f"Version: {VER}",
                     f"Macros file: {SAVEF}"]:
            l = QLabel(text); l.setObjectName("Dim"); l.setWordWrap(True)
            v.addWidget(l)
        if not hooks.pynput_available():
            w = QLabel("pynput isn't installed \u2014 recording and hotkeys are "
                       "disabled.\nInstall it with:  pip install pynput")
            w.setWordWrap(True)
            w.setStyleSheet(f"color: {C['yellow']};")
            v.addWidget(w)

        v.addWidget(hline())
        v.addWidget(QLabel("Theme:"))
        tr = QHBoxLayout()
        self.theme_combo = QComboBox()
        self.theme_combo.addItems(list(THEMES.keys()))
        self.theme_combo.setCurrentText(CONFIG.theme)
        self.theme_combo.currentTextChanged.connect(self._on_theme)
        tr.addWidget(self.theme_combo, 1)
        cust = QPushButton("Customize")
        cust.clicked.connect(self._customize)
        tr.addWidget(cust)
        v.addLayout(tr)

        v.addWidget(hline())
        self.tray_chk = QCheckBox("Minimize to system tray on close")
        self.tray_chk.setChecked(CONFIG.close_to_tray)
        self.tray_chk.toggled.connect(self._on_tray)
        v.addWidget(self.tray_chk)
        if main.tray is None:
            n = QLabel("(system tray not available)")
            n.setObjectName("Dim")
            v.addWidget(n)

        close = QPushButton("Close"); close.clicked.connect(self.accept)
        v.addWidget(close)

    def _on_theme(self, name):
        if name == CONFIG.theme:
            return
        CONFIG.theme = name
        C.update(THEMES.get(name) or C_DEFAULT)
        CONFIG.save()
        self.accept()
        self.main.retheme()

    def _on_tray(self, on):
        CONFIG.close_to_tray = bool(on)
        CONFIG.save()

    def _customize(self):
        CustomThemeDialog(self.main, self).exec()


# ═════════════════ CUSTOM THEME EDITOR ══════════════════
class CustomThemeDialog(QDialog):
    KEY_LABELS = {
        "bg": "Background", "panel": "Panel / Surface", "sidebar": "Sidebar",
        "widget": "Input / Widget bg", "btn": "Button", "btnhov": "Button Hover",
        "accent": "Accent (logo / highlights)",
        "teal": "Secondary accent (play/toggle)", "text": "Main text",
        "dim": "Dimmed / secondary text", "white": "Bright text",
        "border": "Borders / separators", "sel": "Selection highlight",
        "green": "Success / green", "red": "Error / stop / red",
        "yellow": "Warning / amber", "bar": "Top & bottom bars",
    }

    def __init__(self, main, parent_dlg=None):
        super().__init__(parent_dlg or main)
        self.main = main
        self.parent_dlg = parent_dlg
        self.working = dict(C_CUSTOM)
        self.hex_edits = {}
        self.swatches = {}

        self.setWindowTitle("Custom Theme Editor")
        self.setModal(True)
        self.resize(470, 560)

        v = QVBoxLayout(self)
        t = QLabel("Custom Theme Editor")
        tf = t.font(); tf.setPointSize(11); tf.setBold(True); t.setFont(tf)
        v.addWidget(t)
        n = QLabel("Changes apply when you click 'Apply & Use'.")
        n.setObjectName("Dim")
        v.addWidget(n)
        v.addWidget(hline())

        sc = QScrollArea(); sc.setWidgetResizable(True)
        host = QWidget(); hv = QVBoxLayout(host); hv.setSpacing(4)
        for key in self.KEY_LABELS:
            hv.addLayout(self._row(key))
        hv.addStretch(1)
        sc.setWidget(host)
        v.addWidget(sc, 1)

        v.addWidget(hline())
        base = QHBoxLayout()
        bl = QLabel("Start from:"); bl.setObjectName("Dim")
        base.addWidget(bl)
        for name, pal in [("Default", C_DEFAULT), ("AMOLED", C_AMOLED),
                          ("Terminal", C_TERMINAL)]:
            b = QPushButton(name)
            b.clicked.connect(lambda _, p=pal: self._load_base(p))
            base.addWidget(b)
        base.addStretch(1)
        v.addLayout(base)

        bb = QHBoxLayout(); bb.addStretch(1)
        ap = QPushButton("Apply & Use")
        style_btn(ap, C["accent"], accent_fg(), bold=True)
        ap.clicked.connect(self._apply)
        ca = QPushButton("Cancel"); ca.clicked.connect(self.reject)
        bb.addWidget(ap); bb.addWidget(ca); bb.addStretch(1)
        v.addLayout(bb)

    def _row(self, key):
        row = QHBoxLayout()
        sw = QPushButton(); sw.setFixedSize(QSize(30, 24))
        sw.setStyleSheet(f"background: {self.working.get(key, '#000000')};"
                         f" border: 1px solid {C['border']}; border-radius: 4px;")
        sw.clicked.connect(lambda _, k=key: self._pick(k))
        row.addWidget(sw)
        self.swatches[key] = sw
        lab = QLabel(self.KEY_LABELS[key]); lab.setFixedWidth(190)
        row.addWidget(lab)
        ed = QLineEdit(self.working.get(key, "#000000"))
        ed.setFixedWidth(90)
        ed.setStyleSheet("font-family: Consolas;")
        ed.textChanged.connect(lambda txt, k=key: self._hex_changed(k, txt))
        row.addWidget(ed)
        self.hex_edits[key] = ed
        pick = QPushButton("Pick"); pick.setFixedWidth(46)
        pick.clicked.connect(lambda _, k=key: self._pick(k))
        row.addWidget(pick)
        row.addStretch(1)
        return row

    def _pick(self, key):
        init = QColor(self.working.get(key, "#ffffff"))
        col = QColorDialog.getColor(init, self,
                                    f"Pick colour \u2014 {self.KEY_LABELS[key]}")
        if col.isValid():
            self.hex_edits[key].setText(col.name())

    def _hex_changed(self, key, txt):
        txt = txt.strip()
        if len(txt) == 7 and txt.startswith("#") and QColor(txt).isValid():
            self.working[key] = txt
            self.swatches[key].setStyleSheet(
                f"background: {txt}; border: 1px solid {C['border']};"
                f" border-radius: 4px;")

    def _load_base(self, pal):
        for k in self.KEY_LABELS:
            if k in pal:
                self.hex_edits[k].setText(pal[k])

    def _apply(self):
        C_CUSTOM.update(self.working)
        CONFIG.theme = "Custom"
        C.update(C_CUSTOM)
        CONFIG.save()
        self.accept()
        if self.parent_dlg is not None:
            try:
                self.parent_dlg.accept()
            except Exception:
                pass
        self.main.retheme()


# ═════════════════════ bootstrap ════════════════════════
def run() -> int:
    if not _QT_OK:
        sys.stderr.write(
            "macrobin needs PySide6 for its window.\n"
            f"Import error: {_QT_ERR}\n"
            "Install with:  pip install PySide6 pynput\n")
        return 2

    app = QApplication(sys.argv)
    app.setApplicationName(APP)

    if not ensure_single_instance():
        QMessageBox.information(None, APP, "macrobin is already running.")
        return 0

    CONFIG.load()
    C.update(THEMES.get(CONFIG.theme) or C_DEFAULT)
    app.setStyleSheet(build_qss())
    app.setWindowIcon(app_icon())

    global _NAV_FILTER
    _NAV_FILTER = NoKeyNav()
    app.installEventFilter(_NAV_FILTER)

    bridge = Bridge()
    runtime = None
    if hooks.pynput_available():
        try:
            runtime = hooks.Runtime(hooks.RuntimeCallbacks(
                on_status=lambda m, lv: bridge.status.emit(m, lv),
                on_active_changed=lambda ids: bridge.active.emit(ids),
                on_armed_changed=lambda a: bridge.armed.emit(a),
                on_recording_changed=lambda r: bridge.recording.emit(r),
                on_action_recorded=lambda a: bridge.actionRecorded.emit(),
            ))
        except Exception as e:
            runtime = None
            sys.stderr.write(f"Input hooks unavailable: {e}\n")

    win = MainWindow(runtime, bridge)
    app.setQuitOnLastWindowClosed(False)   # tray keeps us alive
    win.show()
    return app.exec()


if __name__ == "__main__":
    sys.exit(run())
