@echo off
setlocal
cd /d "%~dp0"
REM ---------------------------------------------------------------------------
REM DEBUG launcher. Normal launching = double-click macrobin.pyw (no console).
REM This one keeps a console open so you can watch for errors live. Crashes are
REM also always written to macrobin_error.log next to the app.
REM ---------------------------------------------------------------------------
set "PYCMD="
py -3 --version >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD set "PYCMD=python"

%PYCMD% macrobin.py
set "EXITCODE=%ERRORLEVEL%"
if not "%EXITCODE%"=="0" (
    echo.
    echo --------------------------------------------------
    echo macrobin exited with code %EXITCODE%.
    echo See the error above, or macrobin_error.log
    echo --------------------------------------------------
    pause
)
endlocal
