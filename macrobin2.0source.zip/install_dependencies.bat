@echo off
setlocal
cd /d "%~dp0"

echo ==================================================
echo   macrobin - install dependencies
echo ==================================================
echo.

REM ---- locate Python 3 -------------------------------------------------------
set "PYCMD="
py -3 --version >nul 2>&1 && set "PYCMD=py -3"
if not defined PYCMD (
    python --version >nul 2>&1 && set "PYCMD=python"
)
if not defined PYCMD (
    echo ERROR: Python 3 was not found on your PATH.
    echo Install Python 3.9+ from https://www.python.org/downloads/
    echo and TICK "Add Python to PATH" during setup, then run this again.
    echo.
    pause
    exit /b 1
)
echo Using: %PYCMD%
%PYCMD% --version
echo.

REM ---- install into your user site-packages -----------------------------------
REM This is what lets you simply double-click macrobin.pyw to launch.
echo Installing PySide6 and pynput  (PySide6 is large - a few minutes) ...
%PYCMD% -m pip install --user --upgrade -r requirements.txt
if errorlevel 1 (
    echo.
    echo ERROR: dependency installation failed. See messages above.
    pause
    exit /b 1
)

echo.
echo ==================================================
echo   Done. Launch by double-clicking:  macrobin.pyw
echo ==================================================
echo.
pause
