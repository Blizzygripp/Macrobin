# macrobin 2.0

A keyboard and mouse macro tool for Windows: build a sequence of inputs, bind it
to a key, pick how it fires, and go. Built for gaming — hold-to-autofire,
press-to-toggle, or fixed repeat counts — with recording included for when it's
faster to demonstrate a sequence than to write one.

Version 2.0 is a ground-up rebuild of 1.0.5. The feature set and the
`macros.json` format are unchanged, so **existing macros load as-is**. The UI
moved from Tkinter/customtkinter to PySide6 (Qt), and input runs on pynput with
a proper threading model.

---

## Install

Requires **Python 3.9+** ([python.org](https://www.python.org/downloads/) — tick
*Add Python to PATH* during setup).

1. Run **`install_dependencies.bat`** once.
2. Double-click **`macrobin.pyw`**.

That's it — no console window, no virtual environment to activate.

## Build a standalone .exe

Run **`build_exe.bat`** → produces `dist\macrobin.exe`, a single windowed file
with the app icon and no Python install required on the target machine.

The icon is picked up automatically: `Macrobin.ico` if present, otherwise any
`.ico` in the folder. It's both applied to the executable and bundled inside it,
so the window and tray icons match.

The exe reads and writes `macros.json` and `config.json` *next to itself*, so
you can put it anywhere. To bring existing macros along, copy your `macros.json`
next to the exe.

---

## Using it

**Macro list** (main window) — one row per macro, showing its bound key and
loop mode. `On`/`Off` arms an individual macro, `Edit` opens it, `Delete`
removes it. `Disable System` is the master switch that pauses every hotkey at
once. Closing the window minimises to the system tray.

**Trigger settings** (editor, left) — bind any key or mouse button with
`Set Key`, then choose a loop mode:

| Mode | Behaviour |
| --- | --- |
| While Holding Key | Runs on a loop for as long as you hold the key |
| Toggle On/Off | Press to start looping, press again to stop |
| Repeat N Times | One press plays the sequence N times |
| Run Once | One press, one playthrough |

Left and right mouse buttons are rejected as triggers on purpose — binding them
would make the mouse unusable. Middle and side buttons are fine.

**Recording** — pick what to capture (movement, buttons, keys, delays), set a
minimum delay to filter out noise, then hit `Record`. **Ctrl+F10** stops
recording from anywhere, even when macrobin isn't the focused window.

**Action editor** (editor, right) — every step with its delay, colour-coded by
type. Add, edit, duplicate, reorder, delete, insert waits, and export or import
sequences as JSON. Multi-select works; right-click for the same menu.

**Settings** — four themes (Default, AMOLED, Terminal Green, and a fully
custom palette editor) and close-to-tray.

The UI is mouse-driven by design: keyboard navigation is disabled app-wide so a
stray Space or Enter can never fire a control while you're binding keys.

---

## Notes

- **Games running as administrator** only accept input from an equally elevated
  process. If a macro fires on the desktop but not in a game, right-click
  `macrobin.pyw` (or the exe) and *Run as administrator*.
- **Antivirus** sometimes flags freshly built PyInstaller executables. This is a
  generic heuristic against unsigned single-file exes, not a detection of
  anything specific.
- `macros.json` and `config.json` are your data. They're generated on first run
  and are excluded from version control — don't ship them with a release.

## Troubleshooting

Run **`debug_console.bat`** instead of `macrobin.pyw`: it keeps a console open
so you can see errors as they happen. Any crash is also appended to
`macrobin_error.log` next to the app.

To verify the core logic on your own machine:

```
py -3 selftest.py
```

30 checks covering the loop modes, trigger routing, auto-repeat filtering,
delay timing, and `macros.json` compatibility. All should pass.

---

## Project layout

| File | Role |
| --- | --- |
| `macrobin.pyw` | Double-click launcher (no console) |
| `macrobin.py` | Console entry point; also the PyInstaller target |
| `app.py` | PySide6 UI — both windows, dialogs, themes, tray |
| `hooks.py` | pynput layer — listeners, recorder, playback, key capture |
| `engine.py` | Data model and trigger/loop logic (pure, no UI) |
| `selftest.py` | Headless tests for `engine.py` |
| `Macrobin.ico` | App icon — used for the exe, the window and the tray |
| `macrobin.spec` | PyInstaller build spec |
| `install_dependencies.bat` | One-time setup |
| `build_exe.bat` | Builds `dist\macrobin.exe` |
| `debug_console.bat` | Runs the app with a visible console |
| `clean.bat` | Removes build artifacts and caches |

The dependency direction is strictly `app → hooks → engine`, never the reverse.
That's what allows the timing and trigger logic to be tested without a display.

See [CHANGELOG.md](CHANGELOG.md) for what changed in 2.0.
