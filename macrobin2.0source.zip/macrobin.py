#!/usr/bin/env python3
"""
macrobin launcher (console entry).

Normal launching is double-clicking macrobin.pyw (no console). This .py entry
is what the .bat debug launcher and the PyInstaller build use. Any crash is
appended to macrobin_error.log next to the app (or next to the .exe when
frozen), so errors are visible even with no console.
"""

import sys
import os
import datetime
import traceback


def _app_dir() -> str:
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def _log_crash(exc_type, exc, tb) -> str:
    logpath = os.path.join(_app_dir(), "macrobin_error.log")
    try:
        with open(logpath, "a", encoding="utf-8") as f:
            f.write("\n" + "=" * 70 + "\n")
            f.write("macrobin crash @ " + datetime.datetime.now().isoformat() + "\n")
            f.write("Python " + sys.version.replace("\n", " ") + "\n")
            f.write("-" * 70 + "\n")
            traceback.print_exception(exc_type, exc, tb, file=f)
    except Exception:
        pass
    try:
        traceback.print_exception(exc_type, exc, tb)
    except Exception:
        pass
    return logpath


def main() -> int:
    if sys.version_info < (3, 9):
        sys.stderr.write(f"macrobin needs Python 3.9+. You have {sys.version.split()[0]}.\n")
        return 2

    # Make sure our own folder is importable even when launched from elsewhere.
    here = _app_dir()
    if here not in sys.path:
        sys.path.insert(0, here)

    try:
        import PySide6  # noqa: F401
    except Exception:
        sys.stderr.write(
            "\nmacrobin can't start: PySide6 (the GUI toolkit) isn't installed.\n"
            "Run install_dependencies.bat, or:  pip install PySide6 pynput\n\n")
        return 2
    try:
        import pynput  # noqa: F401
    except Exception:
        sys.stderr.write(
            "\nHeads up: pynput isn't installed, so recording and hotkeys are\n"
            "disabled (editor-only mode). Install it:  pip install pynput\n\n")

    sys.excepthook = lambda et, e, tb: _log_crash(et, e, tb)
    try:
        import app
        return app.run()
    except SystemExit:
        raise
    except BaseException:
        logpath = _log_crash(*sys.exc_info())
        sys.stderr.write(f"\nmacrobin hit an error. Details: {logpath}\n")
        return 1


if __name__ == "__main__":
    sys.exit(main())
