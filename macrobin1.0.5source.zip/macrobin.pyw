#!/usr/bin/env python3
"""
macrobin - Full-featured Macro Editor
Mirrors all TGMacro features: recording, playback, hotkey binding,
action editing, loop modes, and more.

Requirements: pip install pynput
"""

import tkinter as tk
from tkinter import ttk, messagebox, simpledialog, filedialog
import json, os, time, threading, copy, queue, sys
from pathlib import Path

try:
    import customtkinter as ctk
    ctk.set_appearance_mode("dark")
    ctk.set_default_color_theme("dark-blue")
    CTK = True
except ImportError:
    CTK = False

# ── Hide console window on Windows (works even with .pyw) ────
if sys.platform == "win32":
    import ctypes
    ctypes.windll.kernel32.FreeConsole()

# ── Single-instance guard ────────────────────────────────────
# On Windows we use a named mutex; on other platforms a lock file.
_INSTANCE_MUTEX = None
def _ensure_single_instance():
    global _INSTANCE_MUTEX
    if sys.platform == "win32":
        import ctypes
        _INSTANCE_MUTEX = ctypes.windll.kernel32.CreateMutexW(None, True, "Global\\macrobin_instance")
        last_err = ctypes.windll.kernel32.GetLastError()
        if last_err == 183:   # ERROR_ALREADY_EXISTS
            # Another instance is running — bring it to the foreground then exit
            import tkinter as _tk
            _r = _tk.Tk(); _r.withdraw()
            _tk.messagebox.showinfo("macrobin", "macrobin is already running.")
            _r.destroy()
            sys.exit(0)
    else:
        import fcntl, tempfile
        _lock_path = os.path.join(tempfile.gettempdir(), "macrobin.lock")
        _INSTANCE_MUTEX = open(_lock_path, "w")
        try:
            fcntl.flock(_INSTANCE_MUTEX, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except OSError:
            import tkinter as _tk
            _r = _tk.Tk(); _r.withdraw()
            _tk.messagebox.showinfo("macrobin", "macrobin is already running.")
            _r.destroy()
            sys.exit(0)

_ensure_single_instance()

# ── Optional pynput ──────────────────────────────────────────
try:
    from pynput import mouse as pmouse, keyboard as pkeyboard
    from pynput.keyboard import Key, KeyCode, Controller as KbCtrl
    from pynput.mouse import Button, Controller as MsCtrl
    PYNPUT = True
except ImportError:
    PYNPUT = False

# ── Optional pystray (system tray) ──────────────────────────
try:
    import pystray
    from PIL import Image, ImageDraw
    PYSTRAY = True
except ImportError:
    PYSTRAY = False

# ── Constants ────────────────────────────────────────────────
APP    = "macrobin"
VER    = "1.0.5"

def _get_app_dir():
    """Returns the directory containing the .exe (frozen) or the script (dev).
    Ensures macros.json and config.json are always written next to the
    executable rather than into PyInstaller's temp extraction folder."""
    if getattr(sys, 'frozen', False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))

def _resource(relative):
    """Resolves a bundled resource path whether frozen (PyInstaller _MEIPASS)
    or running from source. Use for read-only assets like icon.ico."""
    base = getattr(sys, '_MEIPASS', os.path.dirname(os.path.abspath(__file__)))
    return os.path.join(base, relative)

SAVEF   = os.path.join(_get_app_dir(), "macros.json")
CONFIGF = os.path.join(_get_app_dir(), "config.json")

# Palette  (Windows 11 dark + pink/cyan logo accents)
C = dict(
    bg       = "#1c1c1c",   # Windows 11 dark background
    panel    = "#252525",   # elevated panel surface
    sidebar  = "#202020",   # sidebar surface
    widget   = "#2d2d2d",   # input/widget background
    btn      = "#333333",   # button default
    btnhov   = "#3f3f3f",   # button hover
    accent   = "#e91e8c",   # hot pink (logo accent)
    teal     = "#00d4ff",   # cyan (logo accent)
    text     = "#dedede",   # main text
    dim      = "#808080",   # dimmed text
    white    = "#ffffff",   # white
    border   = "#3a3a3a",   # separator / border
    sel      = "#5a1040",   # listbox selection (pink-tinted)
    green    = "#4caf50",   # green
    red      = "#f44336",   # red
    yellow   = "#ffab00",   # amber / wait
    bar      = "#161616",   # top/bottom bars
    tag_kb   = "#4caf50",   # keyboard action tag
    tag_ms   = "#00d4ff",   # mouse action tag
    tag_wt   = "#ffab00",   # wait action tag
    mac_a    = "#e91e8c",   # macro indicator colour A (pink)
    mac_b    = "#00d4ff",   # macro indicator colour B (cyan)
    mac_c    = "#a855f7",   # macro indicator colour C (purple)
    mac_d    = "#4caf50",   # macro indicator colour D (green)
)

# Snapshot of the default palette so we can restore it
C_DEFAULT = dict(C)

# AMOLED black-and-white theme
# Note: accent_fg is a helper used by buttons with bg=accent so text stays legible
C_AMOLED = dict(
    bg       = "#000000",
    panel    = "#0a0a0a",
    sidebar  = "#050505",
    widget   = "#111111",
    btn      = "#1e1e1e",
    btnhov   = "#404040",   # much lighter so hover is clearly visible
    accent   = "#ffffff",
    teal     = "#444444",   # dark grey so white text stays readable on it
    text     = "#e8e8e8",
    dim      = "#777777",
    white    = "#ffffff",
    border   = "#2a2a2a",
    sel      = "#3a3a3a",
    green    = "#aaaaaa",
    red      = "#dddddd",
    yellow   = "#bbbbbb",
    bar      = "#000000",
    tag_kb   = "#aaaaaa",
    tag_ms   = "#cccccc",
    tag_wt   = "#bbbbbb",
    mac_a    = "#ffffff",
    mac_b    = "#bbbbbb",
    mac_c    = "#888888",
    mac_d    = "#555555",
)

# Terminal Green — classic phosphor CRT aesthetic
# Pure black bg, bright #00ff41 phosphor green for text/accents,
# dark green tones for surfaces. Red kept for errors/stop only.
C_TERMINAL = dict(
    bg       = "#000000",   # pure black
    panel    = "#001a00",   # very dark green panel
    sidebar  = "#000d00",   # near-black sidebar
    widget   = "#002200",   # dark green input background
    btn      = "#003300",   # button default
    btnhov   = "#005500",   # button hover — clearly brighter
    accent   = "#00ff41",   # phosphor green (logo / accent)
    teal     = "#00aa2a",   # mid-green for play/toggle buttons
    text     = "#00e533",   # main text — bright green
    dim      = "#007a1a",   # dimmed text — darker green
    white    = "#00ff41",   # "white" equivalent is phosphor green
    border   = "#004400",   # separator lines
    sel      = "#004d00",   # selection highlight
    green    = "#00ff41",   # success / positive
    red      = "#ff3333",   # errors / stop (intentionally non-green)
    yellow   = "#aaff00",   # warnings → lime
    bar      = "#000000",   # top/bottom bars
    tag_kb   = "#00cc33",
    tag_ms   = "#00ff41",
    tag_wt   = "#aaff00",
    mac_a    = "#00ff41",
    mac_b    = "#00cc33",
    mac_c    = "#009922",
    mac_d    = "#006611",
)

THEMES = {
    "Default (Dark)":         C_DEFAULT,
    "AMOLED (Black & White)": C_AMOLED,
    "Terminal Green":          C_TERMINAL,
    "Custom":                  None,   # populated at runtime from config
}

# Custom theme starts as a copy of the default; overwritten by _load_config
C_CUSTOM = dict(C_DEFAULT)

def _luminance(hex_color):
    """Return perceptual luminance 0-255 for a hex color string."""
    h = hex_color.lstrip("#")
    r, g, b = int(h[0:2],16), int(h[2:4],16), int(h[4:6],16)
    return 0.299*r + 0.587*g + 0.114*b

def accent_fg():
    """Legible foreground for buttons whose bg=C['accent']."""
    return "#000000" if _luminance(C["accent"]) > 100 else "#ffffff"

def teal_fg():
    """Legible foreground for buttons whose bg=C['teal']."""
    return "#000000" if _luminance(C["teal"]) > 100 else "#ffffff"

def hover_fg(base_fg):
    """Ensure text stays readable after hover changes bg to btnhov."""
    if _luminance(C["btnhov"]) > 160:
        return "#000000"
    return base_fg

# Action type tokens
KD = "key_down";   KU = "key_up";  KPR = "key_press_release"
MM = "mouse_move"; MB_D = "mouse_down"; MB_U = "mouse_up"
MS = "mouse_scroll"; WT = "wait"

# Human labels for loop / trigger / capture combos
TRIGGER_OPTS  = ["Keystrokes / Button Inputs", "Gamepad Inputs", "Scheduled"]
LOOP_OPTS     = ["While Holding Key", "Toggle On/Off", "Repeat N Times", "Run Once"]
CAPTURE_OPTS  = ["Save Current Position", "Relative to Window", "Don't Capture"]

SPECIAL = {
    "Key.space":"Space","Key.enter":"Enter","Key.tab":"Tab",
    "Key.backspace":"Backspace","Key.delete":"Delete","Key.escape":"Escape",
    "Key.shift":"Shift","Key.shift_r":"Shift(R)","Key.ctrl_l":"Ctrl",
    "Key.ctrl_r":"Ctrl(R)","Key.alt_l":"Alt","Key.alt_r":"Alt(R)",
    "Key.up":"↑","Key.down":"↓","Key.left":"←","Key.right":"→",
    **{f"Key.f{i}":f"F{i}" for i in range(1,13)},
    "Button.left":"LMB","Button.right":"RMB","Button.middle":"MMB",
    "Button.x1":"XButton1","Button.x2":"XButton2",
}

def key_label(s):
    if s in SPECIAL: return SPECIAL[s]
    if s.startswith("'") and s.endswith("'"): return s[1:-1].upper()
    return s or "—"


# ── Data Models ──────────────────────────────────────────────
class Action:
    def __init__(self, kind, data=None, delay=0):
        self.kind  = kind
        self.data  = data or {}
        self.delay = delay       # ms before this action

    def to_dict(self):
        return {"kind": self.kind, "data": self.data, "delay": self.delay}

    @classmethod
    def from_dict(cls, d):
        return cls(d["kind"], d.get("data",{}), d.get("delay",0))

    # ── display helpers ──
    def label(self):
        k, d = self.kind, self.data
        if k == KD:    return f"▼ Key    {key_label(d.get('key',''))}"
        if k == KU:    return f"▲ Key    {key_label(d.get('key',''))}"
        if k == KPR:   return f"▼▲ Key   {key_label(d.get('key',''))}"
        if k == MM:    return f"⊕ Move   ({d.get('x',0)}, {d.get('y',0)})"
        if k == MB_D:  return f"▼ Mouse  {key_label(d.get('button',''))}"
        if k == MB_U:  return f"▲ Mouse  {key_label(d.get('button',''))}"
        if k == MS:    return f"⊞ Scroll dy={d.get('dy',0)}"
        if k == WT:    return f"⏱ Wait   {d.get('ms',0)} ms"
        return f"? {k}"

    def color(self):
        return {KD:C["green"],KU:C["green"],KPR:C["green"],
                MM:C["teal"],MB_D:C["teal"],MB_U:C["teal"],MS:C["teal"],
                WT:C["yellow"]}.get(self.kind, C["text"])


class Macro:
    def __init__(self, name="Macro 1"):
        self.name        = name
        self.trigger     = TRIGGER_OPTS[0]
        self.loop        = LOOP_OPTS[0]
        self.bind_key    = ""          # raw pynput string
        self.enabled     = True        # whether hotkey is active
        self.capture     = CAPTURE_OPTS[0]
        self.min_delay   = 1           # ms – ignore delays less than this
        self.repeat_n    = 1
        self.rec_move    = True
        self.rec_btn     = True
        self.rec_kb      = True
        self.rec_wait    = True
        self.actions     = []

    def to_dict(self):
        return {k: getattr(self, k) if k != "actions"
                else [a.to_dict() for a in self.actions]
                for k in ["name","trigger","loop","bind_key","enabled","capture",
                          "min_delay","repeat_n","rec_move","rec_btn",
                          "rec_kb","rec_wait","actions"]}

    @classmethod
    def from_dict(cls, d):
        m = cls(d.get("name","Macro"))
        for k in ["trigger","loop","bind_key","enabled","capture",
                  "min_delay","repeat_n","rec_move","rec_kb","rec_wait","rec_btn"]:
            if k in d: setattr(m, k, d[k])
        m.actions = [Action.from_dict(a) for a in d.get("actions",[])]
        return m


# ── Recorder ─────────────────────────────────────────────────
class Recorder:
    """Captures keyboard / mouse events into a Macro's action list."""
    def __init__(self, macro, on_add=None):
        self.macro   = macro
        self.on_add  = on_add
        self.active  = False
        self._t0     = 0
        self._kbl    = None
        self._msl    = None
        self._lock   = threading.Lock()
        self._last_move = 0

    def start(self):
        if not PYNPUT: return False
        self.active = True
        self._t0    = time.time()

        if self.macro.rec_kb:
            self._kbl = pkeyboard.Listener(
                on_press=self._kp, on_release=self._kr, suppress=False)
            self._kbl.start()

        if self.macro.rec_move or self.macro.rec_btn:
            self._msl = pmouse.Listener(
                on_move=self._mm, on_click=self._mc, on_scroll=self._msc)
            self._msl.start()
        return True

    def stop(self):
        self.active = False
        for l in (self._kbl, self._msl):
            if l:
                try: l.stop()
                except: pass
        self._kbl = self._msl = None

    def _delay(self):
        now = time.time()
        ms  = int((now - self._t0) * 1000)
        self._t0 = now
        return ms if (self.macro.rec_wait and ms >= self.macro.min_delay) else 0

    def _push(self, a):
        with self._lock:
            self.macro.actions.append(a)
        if self.on_add: self.on_add(a)

    def _kp(self, key):
        if not self.active: return
        self._push(Action(KD, {"key": str(key)}, self._delay()))

    def _kr(self, key):
        if not self.active: return
        self._push(Action(KU, {"key": str(key)}, self._delay()))

    def _mm(self, x, y):
        if not self.active or not self.macro.rec_move: return
        now = time.time()
        if now - self._last_move < 0.05: return   # throttle to ~20fps
        self._last_move = now
        self._push(Action(MM, {"x": x, "y": y}, self._delay()))

    def _mc(self, x, y, button, pressed):
        if not self.active or not self.macro.rec_btn: return
        kind = MB_D if pressed else MB_U
        self._push(Action(kind, {"x":x,"y":y,"button":str(button)}, self._delay()))

    def _msc(self, x, y, dx, dy):
        if not self.active or not self.macro.rec_move: return
        self._push(Action(MS, {"x":x,"y":y,"dx":dx,"dy":dy}, self._delay()))


# ── Player ───────────────────────────────────────────────────
class Player:
    """Replays a Macro's action list with correct timing."""
    def __init__(self, macro):
        self.macro   = macro
        self.playing = False
        self._stop   = threading.Event()
        if PYNPUT:
            self._kb = KbCtrl()
            self._ms = MsCtrl()

    def play(self, done_cb=None):
        if not PYNPUT or self.playing: return False
        self.playing = True
        self._stop.clear()

        def run():
            loop = self.macro.loop
            n    = 0
            while not self._stop.is_set():
                self._play_once()
                n += 1
                if loop == "Run Once": break
                if loop == "Repeat N Times" and n >= self.macro.repeat_n: break
                if self._stop.is_set(): break
            self.playing = False
            if done_cb:
                try: done_cb()
                except: pass

        threading.Thread(target=run, daemon=True).start()
        return True

    def stop(self):
        self._stop.set()
        self.playing = False

    def _play_once(self):
        for a in self.macro.actions:
            if self._stop.is_set(): return
            if a.delay > 0:
                self._stop.wait(a.delay / 1000.0)
                if self._stop.is_set(): return
            self._exec(a)

    def _exec(self, a):
        try:
            k, d = a.kind, a.data
            if   k == KD:   self._kb.press(self._pk(d.get("key","")))
            elif k == KU:   self._kb.release(self._pk(d.get("key","")))
            elif k == KPR:
                pk = self._pk(d.get("key",""))
                self._kb.press(pk); self._kb.release(pk)
            elif k == MM:   self._ms.position = (d.get("x",0), d.get("y",0))
            elif k == MB_D:
                if "x" in d: self._ms.position = (d["x"], d["y"])
                self._ms.press(self._pb(d.get("button","Button.left")))
            elif k == MB_U:
                if "x" in d: self._ms.position = (d["x"], d["y"])
                self._ms.release(self._pb(d.get("button","Button.left")))
            elif k == MS:   self._ms.scroll(d.get("dx",0), d.get("dy",0))
            elif k == WT:   self._stop.wait(d.get("ms",0)/1000.0)
        except: pass

    def _pk(self, s):
        if not s: return None
        try:
            if s.startswith("Key."): return getattr(pkeyboard.Key, s[4:], None)
            if s.startswith("'") and s.endswith("'"): return s[1:-1]
            return pkeyboard.KeyCode.from_char(s)
        except: return None

    def _pb(self, s):
        return {
            "Button.left":  pmouse.Button.left,
            "Button.right": pmouse.Button.right,
            "Button.middle":pmouse.Button.middle,
        }.get(s, pmouse.Button.left)


# ── Hotkey manager ───────────────────────────────────────────
class HotkeyMgr:
    def __init__(self):
        self._binds   = {}   # key_str -> (on_press, on_release)
        self._held    = set()
        self._kbl     = None
        self._msl     = None
        self._bind_cb = None  # one-shot capture callback for Set Key mode

    def register(self, key_str, press=None, release=None):
        if key_str: self._binds[key_str] = (press, release)

    def unregister(self, key_str):
        self._binds.pop(key_str, None)

    def clear(self):
        self._binds.clear()

    def start_bind(self, callback):
        self._bind_cb = callback

    def cancel_bind(self):
        self._bind_cb = None

    def start(self):
        if not PYNPUT: return
        def on_press(key):
            s = str(key)
            if self._bind_cb:
                cb = self._bind_cb; self._bind_cb = None
                threading.Thread(target=cb, args=(s,), daemon=True).start()
                return
            if s not in self._held:
                self._held.add(s)
                if s in self._binds and self._binds[s][0]:
                    threading.Thread(target=self._binds[s][0], daemon=True).start()
        def on_release(key):
            s = str(key)
            self._held.discard(s)
            if s in self._binds and self._binds[s][1]:
                threading.Thread(target=self._binds[s][1], daemon=True).start()
        def on_click(x, y, button, pressed):
            s = str(button)
            if pressed:
                if self._bind_cb:
                    cb = self._bind_cb; self._bind_cb = None
                    threading.Thread(target=cb, args=(s,), daemon=True).start()
                    return
                if s not in self._held:
                    self._held.add(s)
                    if s in self._binds and self._binds[s][0]:
                        threading.Thread(target=self._binds[s][0], daemon=True).start()
            else:
                self._held.discard(s)
                if s in self._binds and self._binds[s][1]:
                    threading.Thread(target=self._binds[s][1], daemon=True).start()
        self._kbl = pkeyboard.Listener(on_press=on_press, on_release=on_release)
        self._kbl.daemon = True
        self._kbl.start()
        self._msl = pmouse.Listener(on_click=on_click)
        self._msl.daemon = True
        self._msl.start()

    def stop(self):
        for l in (self._kbl, self._msl):
            if l:
                try: l.stop()
                except: pass


# ── Tooltip helper ───────────────────────────────────────────
def attach_tooltip(widget, text):
    tip   = [None]
    after = [None]   # pending after() id

    def _show():
        after[0] = None
        if tip[0]: return
        tip[0] = tk.Toplevel(widget)
        tip[0].wm_overrideredirect(True)
        tip[0].wm_geometry(f"+{widget.winfo_rootx()+18}+{widget.winfo_rooty()+22}")
        tk.Label(tip[0], text=text, bg="#ffffe0", fg="#000", font=("Segoe UI",8),
                 padx=4, pady=2, relief="solid", bd=1).pack()

    def show(e):
        # Cancel any pending hide, schedule show with a short delay.
        # This prevents flicker when the mouse briefly crosses an inner
        # sub-widget (e.g. the icon label inside a CTkButton).
        if after[0]:
            widget.after_cancel(after[0])
        after[0] = widget.after(300, _show)

    def hide(e):
        if after[0]:
            widget.after_cancel(after[0])
            after[0] = None
        if tip[0]:
            tip[0].destroy()
            tip[0] = None

    # Use add="+" so we layer on top of existing bindings.
    # Bind to the widget AND propagate to all its children so
    # crossing into child sub-widgets doesn't re-trigger show/hide.
    widget.bind("<Enter>", show, add="+")
    widget.bind("<Leave>", hide, add="+")

    def _bind_children(w):
        for child in w.winfo_children():
            child.bind("<Enter>", show, add="+")
            child.bind("<Leave>", hide, add="+")
            _bind_children(child)

    # Defer child binding until after the widget is fully rendered
    widget.after(100, lambda: _bind_children(widget))


# ── Slim flat scrollbar ───────────────────────────────────────
class FlatScrollbar(tk.Canvas):
    """A minimal pill-style vertical scrollbar drawn on a Canvas.
    Drop-in replacement for ttk.Scrollbar (orient=VERTICAL)."""

    TRACK_W  = 6    # total widget width (px)
    THUMB_W  = 4    # thumb width (px)
    MIN_THUMB = 24  # minimum thumb height (px)
    PAD_X    = 1    # horizontal offset so thumb is centred in track

    def __init__(self, parent, **kw):
        # Colour scheme – track is nearly invisible, thumb is a soft grey pill
        self._bg_col    = kw.pop("bg",        C["bg"])
        self._track_col = kw.pop("troughcolor", "#2a2a2a")
        self._thumb_col = kw.pop("thumbcolor",  "#4a4a4a")
        self._hover_col = kw.pop("hovercolor",  C["accent"])

        super().__init__(parent,
                         width=self.TRACK_W,
                         bg=self._bg_col,
                         highlightthickness=0,
                         bd=0,
                         cursor="arrow",
                         **kw)

        self._command   = None   # e.g. listbox.yview
        self._pos_start = 0.0
        self._pos_end   = 1.0
        self._dragging  = False
        self._drag_y    = 0
        self._drag_start = 0.0
        self._hovered   = False
        self._thumb_id  = None

        self.bind("<Configure>",        self._draw)
        self.bind("<ButtonPress-1>",    self._on_press)
        self.bind("<B1-Motion>",        self._on_drag)
        self.bind("<ButtonRelease-1>",  self._on_release)
        self.bind("<MouseWheel>",       self._on_wheel)
        self.bind("<Enter>",            self._on_enter)
        self.bind("<Leave>",            self._on_leave)

    # ── public API (mirrors ttk.Scrollbar) ───────────────────
    def config(self, **kw):
        if "command" in kw:
            self._command = kw.pop("command")
        super().config(**kw)

    configure = config

    def set(self, first, last):
        """Called by the linked widget (e.g. Listbox) to update thumb position."""
        self._pos_start = float(first)
        self._pos_end   = float(last)
        self._draw()

    # ── drawing ──────────────────────────────────────────────
    def _draw(self, _event=None):
        self.delete("all")
        h = self.winfo_height()
        if h < 2:
            return

        # Thumb geometry
        span       = self._pos_end - self._pos_start
        thumb_h    = max(self.MIN_THUMB, int(h * span))
        thumb_top  = int(h * self._pos_start)
        thumb_bot  = thumb_top + thumb_h
        if thumb_bot > h:
            thumb_bot = h
            thumb_top = h - thumb_h

        x0 = self.PAD_X
        x1 = x0 + self.THUMB_W

        # Only draw thumb when content overflows
        if span < 1.0:
            colour = self._hover_col if self._hovered else self._thumb_col
            r = self.THUMB_W // 2   # corner radius = half the thumb width
            self._round_rect(x0, thumb_top, x1, thumb_bot, r, colour)

    def _round_rect(self, x0, y0, x1, y1, r, fill):
        """Draw a rounded rectangle using polygon + ovals."""
        if y1 - y0 < 2 * r:
            r = (y1 - y0) // 2
        self.create_arc(x0, y0, x0+2*r, y0+2*r, start=90,  extent=90,  fill=fill, outline="")
        self.create_arc(x1-2*r, y0, x1, y0+2*r, start=0,   extent=90,  fill=fill, outline="")
        self.create_arc(x0, y1-2*r, x0+2*r, y1, start=180, extent=90,  fill=fill, outline="")
        self.create_arc(x1-2*r, y1-2*r, x1, y1, start=270, extent=90,  fill=fill, outline="")
        self.create_rectangle(x0+r, y0, x1-r, y1, fill=fill, outline="")
        self.create_rectangle(x0, y0+r, x1, y1-r, fill=fill, outline="")

    # ── interaction ──────────────────────────────────────────
    def _thumb_bounds(self):
        h = self.winfo_height()
        span      = self._pos_end - self._pos_start
        thumb_h   = max(self.MIN_THUMB, int(h * span))
        thumb_top = int(h * self._pos_start)
        return thumb_top, thumb_top + thumb_h

    def _on_press(self, event):
        top, bot = self._thumb_bounds()
        if top <= event.y <= bot:
            self._dragging   = True
            self._drag_y     = event.y
            self._drag_start = self._pos_start
        else:
            # Click above/below thumb → page scroll
            h = self.winfo_height()
            if h > 0 and self._command:
                frac = event.y / h
                if frac < self._pos_start:
                    self._command("scroll", -1, "pages")
                else:
                    self._command("scroll",  1, "pages")

    def _on_drag(self, event):
        if not self._dragging:
            return
        h = self.winfo_height()
        if h <= 0:
            return
        delta  = (event.y - self._drag_y) / h
        new_pos = max(0.0, min(1.0, self._drag_start + delta))
        if self._command:
            self._command("moveto", new_pos)

    def _on_release(self, _event):
        self._dragging = False

    def _on_wheel(self, event):
        if self._command:
            self._command("scroll", int(-1 * (event.delta / 120)), "units")

    def _on_enter(self, _event):
        self._hovered = True
        self._draw()

    def _on_leave(self, _event):
        self._hovered = False
        self._draw()


# ── Toggling Option Menu ─────────────────────────────────────
# CTkOptionMenu has no built-in toggle — clicking the arrow always opens.
# We fix this by tracking whether the menu is currently visible and
# ── Toggling Option Menu ─────────────────────────────────────
#
# Event sequence when user clicks arrow while menu is OPEN:
#   1. DropdownMenu loses focus  → <FocusOut> fires on it       ← we timestamp here
#   2. CTK's FocusOut handler    → calls withdraw() internally
#   3. Canvas <Button-1> fires   → CTK calls _open_dropdown_menu ← we check timestamp
#
# FocusOut (step 1) always fires BEFORE _open_dropdown_menu (step 3).
# So we timestamp FocusOut and suppress any _open_dropdown_menu call
# that arrives within 150 ms — that's the "same click closed it" case.
#
# Why earlier attempts failed:
#   • ButtonPress bind: our add="+" fires AFTER CTK's <Button-1>, too late.
#   • withdraw() patch: CTkToplevel's withdraw is a C bound method, not replaceable.
#   • Unmap/Map events: unreliable across CTK versions.
if CTK:
    class TogglingOptionMenu(ctk.CTkOptionMenu):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self._focusout_time = 0.0

            # _dropdown_menu exists right after super().__init__()
            menu = getattr(self, "_dropdown_menu", None)
            if menu is not None:
                try:
                    menu.bind(
                        "<FocusOut>",
                        lambda e: setattr(self, "_focusout_time", time.time()),
                        add="+"
                    )
                except Exception:
                    pass

        def _open_dropdown_menu(self):
            elapsed = time.time() - self._focusout_time
            if elapsed < 0.15:
                # FocusOut just fired — this open call is from the same click
                # that closed the menu. Suppress it (acts as toggle-off).
                return
            try:
                super()._open_dropdown_menu()
            except Exception:
                pass
            # Highlight the currently selected item after the menu renders
            self.after(20, self._highlight_selected)

        def _highlight_selected(self):
            try:
                menu = getattr(self, "_dropdown_menu", None)
                if menu is None or not menu.winfo_viewable():
                    return
                current = self.get()
                self._walk_highlight(menu, current)
            except Exception:
                pass

        def _walk_highlight(self, widget, current):
            try:
                if hasattr(widget, "cget") and hasattr(widget, "configure"):
                    try:
                        if widget.cget("text") == current:
                            widget.configure(
                                fg_color=C["sel"],
                                text_color=C["white"])
                        else:
                            widget.configure(
                                fg_color=C["widget"],
                                text_color=C["text"])
                    except Exception:
                        pass
            except Exception:
                pass
            for child in widget.winfo_children():
                self._walk_highlight(child, current)
else:
    TogglingOptionMenu = None


# ── Main Application ─────────────────────────────────────────
class App:
    def __init__(self):
        self.root = ctk.CTk() if CTK else tk.Tk()
        self.root.title(APP)
        self.root.geometry("500x580")
        self.root.minsize(400, 380)
        self.root.configure(bg=C["bg"])
        self.root.overrideredirect(False)   # keep native frame for reliability
        self._editor_win = None   # open editor Toplevel (only one at a time)
        self._ico = _resource("icon.ico")

        # Set window / taskbar icon from icon.ico
        self._set_icon(self.root)

        # State
        self.macros   : list[Macro] = []
        self.cur      : int         = -1   # current macro index
        self.sel      : list[int]   = []   # selected action rows
        self.recorder : Recorder | None = None
        self.player   : Player   | None = None
        self.is_rec   = False
        self.is_play  = False
        self.binding  = False
        self.hkmgr    = HotkeyMgr()
        self._q       : queue.Queue = queue.Queue()

        self._tray_icon = None
        self._alpha = 0.92
        self._theme_name    = "Default (Dark)"
        self._close_to_tray = True
        self._editor_macro_idx = -1
        self._system_disabled  = False
        THEMES["Custom"] = C_CUSTOM   # ensure Custom entry always valid before load
        self._load_config()          # load theme + prefs BEFORE building UI
        THEMES["Custom"] = C_CUSTOM   # _load_config may have updated C_CUSTOM
        theme_palette = THEMES.get(self._theme_name) or C_DEFAULT
        C.update(theme_palette)
        self.root.configure(bg=C["bg"])
        self._styles()
        self._ui()
        self._load()
        if not self.macros:
            m = Macro("Macro 1")
            self.macros.append(m)
            self.cur = 0
            self._rebuild_tabs()
        self.hkmgr.start()
        self._poll()
        self._apply_alpha()
        self.root.protocol("WM_DELETE_WINDOW", self._on_close)
        self._setup_tray()

    def run(self): self.root.mainloop()

    # ── Styles ──────────────────────────────────────────────
    def _styles(self):
        # Only used as fallback when customtkinter is not installed
        s = ttk.Style()
        s.theme_use("clam")
        s.configure("TCombobox", fieldbackground=C["widget"], background=C["widget"],
                    foreground=C["text"], selectbackground=C["sel"],
                    selectforeground=C["white"], arrowcolor=C["accent"], relief="flat",
                    borderwidth=0, lightcolor=C["widget"], darkcolor=C["widget"])

    # ── Icon helper ─────────────────────────────────────────
    def _set_icon(self, win):
        """Apply icon.ico to any window or Toplevel."""
        if os.path.exists(self._ico):
            try: win.iconbitmap(self._ico)
            except: pass

    # ── UI skeleton ─────────────────────────────────────────
    def _ui(self):
        main = tk.Frame(self.root, bg=C["bg"])
        main.pack(fill=tk.BOTH, expand=True)
        self._build_main_page(main)

    # ═══════════════════ MAIN PAGE ═════════════════════════
    def _build_main_page(self, parent):
        # ── Top header bar ──
        hdr = tk.Frame(parent, bg=C["bar"])
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="  macrobin", bg=C["bar"], fg=C["accent"],
                 font=("Segoe UI", 13, "bold"), pady=14).pack(side=tk.LEFT)
        tk.Label(hdr, text=f"v{VER}", bg=C["bar"], fg=C["dim"],
                 font=("Segoe UI", 8)).pack(side=tk.RIGHT, padx=10)
        tk.Frame(parent, bg=C["border"], height=1).pack(fill=tk.X)

        # ── Macro list (scrollable) ──
        list_outer = tk.Frame(parent, bg=C["bg"])
        list_outer.pack(fill=tk.BOTH, expand=True)

        self.macro_canvas = tk.Canvas(list_outer, bg=C["bg"], highlightthickness=0)
        ml_scroll = FlatScrollbar(list_outer, bg=C["bg"])
        ml_scroll.config(command=self.macro_canvas.yview)
        self.macro_canvas.configure(yscrollcommand=ml_scroll.set)
        ml_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        self.macro_canvas.pack(fill=tk.BOTH, expand=True)

        self.macro_list_frame = tk.Frame(self.macro_canvas, bg=C["bg"])
        self._macro_list_wid = self.macro_canvas.create_window(
            (0, 0), window=self.macro_list_frame, anchor="nw")

        def _resize_ml(e):
            self.macro_canvas.configure(scrollregion=self.macro_canvas.bbox("all"))
            self.macro_canvas.itemconfig(self._macro_list_wid, width=e.width)
        self.macro_canvas.bind("<Configure>", _resize_ml)
        self.macro_list_frame.bind("<Configure>",
            lambda e: self.macro_canvas.configure(
                scrollregion=self.macro_canvas.bbox("all")))
        self.macro_canvas.bind("<MouseWheel>",
            lambda e: self.macro_canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        # ── Bottom bar: Disable System + Add New ──
        tk.Frame(parent, bg=C["border"], height=1).pack(fill=tk.X)
        bot = tk.Frame(parent, bg=C["bg"])
        bot.pack(fill=tk.X, padx=12, pady=10)
        bot.columnconfigure(0, weight=1)
        bot.columnconfigure(1, weight=1)

        self.sys_btn = self._btn(bot, "⏸  Disable System", self._toggle_system,
                                 bg=C["btn"], fg=C["white"], fs=9)
        self.sys_btn.grid(row=0, column=0, sticky="ew", padx=(0, 5), ipady=5)

        self._btn(bot, "+ Add New Macro", self._new_macro,
                  bg=C["accent"], fg=accent_fg(), fs=9).grid(
            row=0, column=1, sticky="ew", padx=(5, 0), ipady=5)

        # Status bar
        tk.Frame(parent, bg=C["border"], height=1).pack(fill=tk.X)
        sb = tk.Frame(parent, bg=C["bar"], pady=4)
        sb.pack(fill=tk.X)
        self.status = tk.Label(sb, text="Ready", bg=C["bar"], fg=C["dim"],
                               font=("Segoe UI", 8))
        self.status.pack(side=tk.LEFT, padx=10)
        self._btn(sb, "⚙", self._settings_dlg,
                  bg=C["bar"], fg=C["dim"], fs=11, w=3).pack(side=tk.RIGHT, padx=6)

        if not PYNPUT:
            tk.Label(sb, text="⚠ pynput not installed",
                     bg=C["bar"], fg=C["yellow"], font=("Segoe UI", 8)).pack(
                side=tk.RIGHT, padx=8)

    # ── Trigger Settings ────────────────────────────────────
    def _build_trigger_section(self, parent):
        self._section_hdr(parent, "Trigger Settings")
        f = tk.Frame(parent, bg=C["panel"], padx=14)
        f.pack(fill=tk.X, pady=(0,6))

        # Trigger by
        tk.Label(f, text="Trigger by", **self._lkw()).grid(row=0,column=0,sticky="w",pady=(4,0))
        self.v_trigger = tk.StringVar(value=TRIGGER_OPTS[0])
        self._combo(f, self.v_trigger, TRIGGER_OPTS, width=240).grid(
            row=1, column=0, sticky="w", pady=(3,8))

        # Loop
        tk.Label(f, text="Loop", **self._lkw()).grid(row=2,column=0,sticky="w")
        self.v_loop = tk.StringVar(value=LOOP_OPTS[0])
        self._combo(f, self.v_loop, LOOP_OPTS, width=240,
                    on_change=self._loop_changed).grid(
            row=3, column=0, sticky="w", pady=(3,8))

        # Repeat N (hidden unless loop==Repeat N Times)
        self.repeat_row = tk.Frame(f, bg=C["panel"])
        tk.Label(self.repeat_row, text="Repeat Count:", **self._lkw()).pack(side=tk.LEFT)
        self.v_repeat = tk.StringVar(value="1")
        self._entry(self.repeat_row, self.v_repeat, w=6).pack(side=tk.LEFT, padx=4)
        self.repeat_row.grid(row=4, column=0, sticky="w", pady=4)
        self.repeat_row.grid_remove()

        # Bind key
        tk.Label(f, text="Trigger / Bind Key", **self._lkw()).grid(
            row=5, column=0, sticky="w", pady=(4,0))
        kf = tk.Frame(f, bg=C["panel"])
        kf.grid(row=6, column=0, sticky="w", pady=(3,6))

        self.v_bind = tk.StringVar(value="")
        if CTK:
            self.bind_ent = ctk.CTkEntry(kf, textvariable=self.v_bind,
                                         fg_color=C["widget"], text_color=C["white"],
                                         border_color=C["border"], border_width=2,
                                         corner_radius=10, font=("Segoe UI", 9),
                                         width=120, state="disabled")
        else:
            self.bind_ent = tk.Entry(kf, textvariable=self.v_bind, bg=C["widget"],
                                     fg=C["white"], state="readonly", width=14,
                                     relief="flat", readonlybackground=C["widget"],
                                     highlightthickness=2, highlightbackground=C["border"],
                                     highlightcolor=C["accent"],
                                     font=("Segoe UI", 9))
        self.bind_ent.pack(side=tk.LEFT, padx=(0,4))

        set_k = self._btn(kf, "Set Key", self._start_bind, bg=C["btn"], fg=C["white"], w=8)
        set_k.pack(side=tk.LEFT, padx=(6,0))

        clr_k = self._btn(kf, "✕", self._clear_bind, bg=C["widget"],
                          fg=C["red"], w=3)
        clr_k.pack(side=tk.LEFT, padx=(3,0))

    # ── Record Actions ──────────────────────────────────────
    def _build_record_section(self, parent):
        self._section_hdr(parent, "Record Actions")
        f = tk.Frame(parent, bg=C["panel"], padx=14)
        f.pack(fill=tk.X, pady=(0,8))

        tk.Label(f, text="Mouse Position Capture", **self._lkw()).pack(anchor="w")
        self.v_capture = tk.StringVar(value=CAPTURE_OPTS[0])
        self._combo(f, self.v_capture, CAPTURE_OPTS, width=240).pack(anchor="w", pady=(3,10))

        # Toggle grid
        tg = tk.Frame(f, bg=C["panel"])
        tg.pack(fill=tk.X)
        tg.columnconfigure(0, weight=1); tg.columnconfigure(1, weight=1)

        self.v_rec_move = tk.BooleanVar(value=True)
        self.v_rec_btn  = tk.BooleanVar(value=True)
        self.v_rec_kb   = tk.BooleanVar(value=True)
        self.v_rec_wait = tk.BooleanVar(value=True)

        toggles = [
            ("🖱  Mouse Movement",   self.v_rec_move),
            ("🖲  Mouse Buttons",    self.v_rec_btn),
            ("⌨  Keyboard Keys",    self.v_rec_kb),
            ("⏱  Wait Time/Delays", self.v_rec_wait),
        ]
        self._toggle_btns = {}
        for i, (lbl, var) in enumerate(toggles):
            r, c = divmod(i, 2)
            if CTK:
                b = ctk.CTkButton(tg, text=lbl,
                                  fg_color=C["teal"], hover_color=C["btnhov"],
                                  text_color=teal_fg(),
                                  font=("Segoe UI", 8, "bold"),
                                  corner_radius=10, height=36,
                                  command=lambda v=var: self._toggle(v))
            else:
                b = tk.Button(tg, text=lbl, bg=C["teal"], fg=teal_fg(),
                              font=("Segoe UI", 8, "bold"), relief="flat", bd=0,
                              padx=8, pady=7, cursor="hand2",
                              command=lambda v=var: self._toggle(v))
            b.grid(row=r, column=c, padx=4, pady=4, sticky="ew")
            self._toggle_btns[id(var)] = (b, var)

        # Ignore delay row
        df = tk.Frame(f, bg=C["panel"])
        df.pack(fill=tk.X, pady=(10,4))
        tk.Label(df, text="Ignore delays less than:", **self._lkw()).pack(side=tk.LEFT)
        self.v_min_delay = tk.StringVar(value="1")
        self._entry(df, self.v_min_delay, w=5).pack(side=tk.LEFT, padx=4)
        tk.Label(df, text="ms", **self._lkw()).pack(side=tk.LEFT)

        # Record button + blink dot
        rb = tk.Frame(f, bg=C["panel"])
        rb.pack(fill=tk.X, pady=(10,2))
        if CTK:
            self.rec_btn = ctk.CTkButton(rb, text="⏺  Record  [Ctrl+F10]",
                                         fg_color=C["btn"], hover_color=C["btnhov"],
                                         text_color=C["white"],
                                         font=("Segoe UI", 9, "bold"),
                                         corner_radius=10, height=36,
                                         command=self._toggle_rec)
        else:
            self.rec_btn = tk.Button(rb, text="⏺  Record  [Ctrl+F10]",
                                     bg=C["btn"], fg=C["white"],
                                     font=("Segoe UI", 9, "bold"), relief="flat", bd=0,
                                     padx=14, pady=8, cursor="hand2",
                                     command=self._toggle_rec)
        self.rec_btn.pack(side=tk.LEFT)
        self.rec_dot = tk.Label(rb, text="●", bg=C["panel"], fg=C["dim"],
                                font=("Segoe UI", 14))
        self.rec_dot.pack(side=tk.LEFT, padx=6)

    # ═══════════════════ EDITOR WINDOW ═════════════════════
    def _open_editor(self, idx=None):
        """Open (or re-focus) the macro editor Toplevel for macro at idx."""
        if idx is not None:
            if 0 <= self.cur < len(self.macros):
                self._ui_to_macro()
            self.cur = idx
            self._editor_macro_idx = idx

        # Re-focus if already open
        if self._editor_win and self._editor_win.winfo_exists():
            self._editor_load_macro()
            self._editor_win.lift()
            self._editor_win.focus_force()
            return

        ed = tk.Toplevel(self._editor_win if (self._editor_win and self._editor_win.winfo_exists()) else self.root)
        ed.title(f"macrobin — Macro Editor")
        ed.geometry("1060x660")
        ed.minsize(860, 520)
        ed.configure(bg=C["bg"])
        ed.attributes("-alpha", self._alpha)
        self._editor_win = ed

        self._set_icon(ed)

        def _on_close_editor():
            self._ui_to_macro()
            self._save()
            self._rebuild_tabs()
            ed.destroy()
            self._editor_win = None

        ed.protocol("WM_DELETE_WINDOW", _on_close_editor)

        # ── Layout: left panel (settings) + right panel (action editor) ──
        main = tk.Frame(ed, bg=C["bg"])
        main.pack(fill=tk.BOTH, expand=True)

        # Left settings panel
        lp = tk.Frame(main, bg=C["panel"], width=380)
        lp.pack(side=tk.LEFT, fill=tk.BOTH)
        lp.pack_propagate(False)
        self._ed_lp = lp

        tk.Frame(main, bg=C["border"], width=1).pack(side=tk.LEFT, fill=tk.Y)

        # Right action editor panel
        rp = tk.Frame(main, bg=C["panel"])
        rp.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        self._ed_rp = rp

        self._build_editor_left(lp)
        self._build_editor_right(rp)
        self._editor_load_macro()

    def _build_editor_left(self, lp):
        # ── top bar: macro name ──
        top = tk.Frame(lp, bg=C["bar"])
        top.pack(fill=tk.X)
        tk.Label(top, text="Macro Name", bg=C["bar"], fg=C["dim"],
                 font=("Segoe UI", 8), pady=10).pack(side=tk.LEFT, padx=(12, 4))

        name_row = tk.Frame(lp, bg=C["panel"], pady=6)
        name_row.pack(fill=tk.X, padx=10)
        self.v_name = tk.StringVar()
        if CTK:
            ne = ctk.CTkEntry(name_row, textvariable=self.v_name,
                              fg_color=C["widget"], text_color=C["white"],
                              border_color=C["border"], border_width=2,
                              corner_radius=10, font=("Segoe UI", 10),
                              placeholder_text="Macro name…")
        else:
            ne = tk.Entry(name_row, textvariable=self.v_name,
                          bg=C["widget"], fg=C["white"],
                          relief="flat", font=("Segoe UI", 10),
                          insertbackground=C["accent"],
                          highlightthickness=2,
                          highlightbackground=C["border"],
                          highlightcolor=C["accent"])
        ne.pack(fill=tk.X, pady=2)
        ne.bind("<Return>",   lambda e: self._name_changed())
        ne.bind("<FocusOut>", lambda e: self._name_changed())

        tk.Frame(lp, bg=C["border"], height=1).pack(fill=tk.X)

        # ── scrollable middle (trigger + record sections) ──
        mid_outer = tk.Frame(lp, bg=C["panel"])
        mid_outer.pack(fill=tk.BOTH, expand=True)

        mid_canvas = tk.Canvas(mid_outer, bg=C["panel"], highlightthickness=0)
        mid_scroll = FlatScrollbar(mid_outer, bg=C["panel"])
        mid_scroll.config(command=mid_canvas.yview)
        mid_canvas.configure(yscrollcommand=mid_scroll.set)
        mid_scroll.pack(side=tk.RIGHT, fill=tk.Y)
        mid_canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

        self.mid = tk.Frame(mid_canvas, bg=C["panel"])
        win_id = mid_canvas.create_window((0, 0), window=self.mid, anchor="nw")

        def _resize(e):
            mid_canvas.configure(scrollregion=mid_canvas.bbox("all"))
            mid_canvas.itemconfig(win_id, width=e.width)
        mid_canvas.bind("<Configure>", _resize)
        self.mid.bind("<Configure>", lambda e: mid_canvas.configure(
            scrollregion=mid_canvas.bbox("all")))

        def _scroll(e):
            mid_canvas.yview_scroll(int(-1*(e.delta/120)), "units")
        mid_canvas.bind("<MouseWheel>", _scroll)

        self._build_trigger_section(self.mid)
        tk.Frame(self.mid, bg=C["border"], height=1).pack(fill=tk.X, pady=4)
        self._build_record_section(self.mid)

        # Bind mousewheel to all children so scrolling works anywhere in the panel
        def _bind_all_scroll(widget):
            widget.bind("<MouseWheel>", _scroll, add="+")
            for child in widget.winfo_children():
                _bind_all_scroll(child)
        _bind_all_scroll(self.mid)

        # ── bottom bar: Save + Play ──
        tk.Frame(lp, bg=C["border"], height=1).pack(fill=tk.X)
        bot = tk.Frame(lp, bg=C["panel"])
        bot.pack(fill=tk.X, padx=12, pady=10)
        bot.columnconfigure(0, weight=1)
        bot.columnconfigure(1, weight=1)

        save_btn = self._btn(bot, "💾  Save", self._save,
                             bg=C["btn"], fg=C["white"], fs=10)
        save_btn.grid(row=0, column=0, sticky="ew", padx=(0, 5), ipady=4)

        self.play_btn = self._btn(bot, "▶  Play", self._toggle_play,
                                  bg=C["teal"], fg=teal_fg(), fs=10)
        self.play_btn.grid(row=0, column=1, sticky="ew", padx=(5, 0), ipady=4)

    def _build_editor_right(self, rp):
        # Header row
        hdr = tk.Frame(rp, bg=C["bar"])
        hdr.pack(fill=tk.X)
        tk.Label(hdr, text="Action Editor", bg=C["bar"], fg=C["white"],
                 font=("Segoe UI", 10, "bold"), pady=11).pack(side=tk.LEFT, padx=12)
        self.cnt_lbl = tk.Label(hdr, text="0 actions", bg=C["bar"],
                                fg=C["dim"], font=("Segoe UI", 8))
        self.cnt_lbl.pack(side=tk.RIGHT, padx=10)
        tk.Frame(rp, bg=C["border"], height=1).pack(fill=tk.X)

        # Toolbar
        tb = tk.Frame(rp, bg=C["bg"], pady=5)
        tb.pack(fill=tk.X, padx=4)

        tools = [
            ("➕", "Add Action",      self._add_dlg),
            ("✏",  "Edit Action",     self._edit_dlg),
            ("⧉",  "Duplicate",       self._duplicate),
            ("🗑",  "Delete",          self._delete),
            ("⬆",  "Move Up",         self._move_up),
            ("⬇",  "Move Down",       self._move_down),
            ("⏱",  "Add Wait",        self._wait_dlg),
            ("🔴",  "Stop All",        self._stop_all),
            ("📁",  "Export Actions", self._export),
            ("📂",  "Import Actions", self._import),
        ]
        for txt, tip, cmd in tools:
            b = self._tbtn(tb, txt, cmd)
            b.pack(side=tk.LEFT, padx=2)
            attach_tooltip(b, tip)

        tk.Frame(rp, bg=C["border"], height=1).pack(fill=tk.X)

        # Column header
        ch = tk.Frame(rp, bg=C["bg"])
        ch.pack(fill=tk.X, padx=8, pady=(4, 0))
        for txt, w in [("#", 4), ("Type / Action", 30), ("Delay", 9)]:
            tk.Label(ch, text=txt, bg=C["bg"], fg=C["dim"],
                     font=("Segoe UI", 8), width=w, anchor="w").pack(side=tk.LEFT, padx=2)

        # Listbox + scrollbar
        lc = tk.Frame(rp, bg=C["bg"])
        lc.pack(fill=tk.BOTH, expand=True, padx=4, pady=(2, 4))

        vsb = FlatScrollbar(lc, bg=C["bg"])
        vsb.pack(side=tk.RIGHT, fill=tk.Y)

        self.lb = tk.Listbox(lc, bg=C["bg"], fg=C["text"], relief="flat",
                             selectbackground=C["sel"], selectforeground=C["white"],
                             font=("Consolas", 9), borderwidth=0, highlightthickness=0,
                             yscrollcommand=vsb.set, selectmode=tk.EXTENDED,
                             activestyle="none")
        self.lb.pack(fill=tk.BOTH, expand=True)
        vsb.config(command=self.lb.yview)

        self.lb.bind("<<ListboxSelect>>", lambda e: self._sel_changed())
        self.lb.bind("<Double-Button-1>", lambda e: self._edit_dlg())
        self.lb.bind("<Delete>",          lambda e: self._delete())
        self.lb.bind("<Button-3>",        self._ctx_menu)

        # Status bar
        tk.Frame(rp, bg=C["border"], height=1).pack(fill=tk.X)
        sb_f = tk.Frame(rp, bg=C["bar"], pady=4)
        sb_f.pack(fill=tk.X)
        self.status = tk.Label(sb_f, text="Ready", bg=C["bar"], fg=C["dim"],
                               font=("Segoe UI", 8))
        self.status.pack(side=tk.LEFT, padx=10)

        if not PYNPUT:
            tk.Label(sb_f, text="⚠ pynput not installed — pip install pynput",
                     bg=C["bar"], fg=C["yellow"], font=("Segoe UI", 8)).pack(
                side=tk.RIGHT, padx=8)

    def _editor_load_macro(self):
        """Push the current macro's data into the editor UI fields."""
        if not (0 <= self.cur < len(self.macros)): return
        self._editor_macro_idx = self.cur
        m = self.macros[self.cur]
        self.v_name.set(m.name)
        self.v_trigger.set(m.trigger)
        self.v_loop.set(m.loop)
        self.v_bind.set(key_label(m.bind_key) if m.bind_key else "")
        self.v_capture.set(m.capture)
        self.v_min_delay.set(str(m.min_delay))
        self.v_repeat.set(str(m.repeat_n))
        self.v_rec_move.set(m.rec_move)
        self.v_rec_btn.set(m.rec_btn)
        self.v_rec_kb.set(m.rec_kb)
        self.v_rec_wait.set(m.rec_wait)
        self._update_toggles()
        self._loop_changed()
        self._refresh_list()
        if self._editor_win:
            self._editor_win.title(f"macrobin — {m.name}")

    # ── Helper widget factories ──────────────────────────────
    def _lkw(self, bg=None):
        return dict(bg=bg or C["panel"], fg=C["text"], font=("Segoe UI", 9))

    def _btn(self, par, text, cmd, bg=C["btn"], fg=C["text"],
             w=None, pad=(0,0), fs=9):
        if CTK:
            px_w = w * 9 + 20 if w else 0
            b = ctk.CTkButton(par, text=text, command=cmd,
                              fg_color=bg, hover_color=C["btnhov"],
                              text_color=fg, font=("Segoe UI", fs),
                              corner_radius=10, width=px_w, height=34)
            return b
        kw = dict(text=text, command=cmd, bg=bg, fg=fg,
                  activebackground=C["btnhov"], activeforeground=hover_fg(fg),
                  font=("Segoe UI", fs), relief="flat", bd=0, cursor="hand2",
                  padx=12+pad[0], pady=6+pad[1])
        if w: kw["width"] = w
        b = tk.Button(par, **kw)
        b.bind("<Enter>", lambda e: b.config(bg=C["btnhov"], fg=hover_fg(fg)))
        b.bind("<Leave>", lambda e: b.config(bg=bg, fg=fg))
        return b

    def _tbtn(self, par, text, cmd):
        if CTK:
            return ctk.CTkButton(par, text=text, command=cmd,
                                 fg_color=C["btn"], hover_color=C["btnhov"],
                                 text_color=C["text"], font=("Segoe UI", 12),
                                 corner_radius=10, width=40, height=36)
        b = tk.Button(par, text=text, command=cmd,
                      bg=C["btn"], fg=C["text"],
                      activebackground=C["btnhov"], activeforeground=hover_fg(C["text"]),
                      font=("Segoe UI", 11), relief="flat", bd=0,
                      cursor="hand2", padx=9, pady=6, width=2)
        b.bind("<Enter>", lambda e: b.config(bg=C["btnhov"], fg=hover_fg(C["text"])))
        b.bind("<Leave>", lambda e: b.config(bg=C["btn"], fg=C["text"]))
        return b

    def _entry(self, par, var, w=20):
        if CTK:
            return ctk.CTkEntry(par, textvariable=var,
                                fg_color=C["widget"], text_color=C["white"],
                                border_color=C["border"], border_width=2,
                                corner_radius=10, font=("Segoe UI", 9),
                                width=max(w * 8, 64))
        return tk.Entry(par, textvariable=var, bg=C["widget"], fg=C["white"],
                        relief="flat", width=w, insertbackground=C["accent"],
                        highlightthickness=2, highlightbackground=C["border"],
                        highlightcolor=C["accent"], font=("Segoe UI", 9))

    def _combo(self, par, var, values, width=230, on_change=None):
        """Unified combobox — CTkOptionMenu when available, ttk.Combobox fallback."""
        if CTK:
            def _cmd(choice):
                if on_change: on_change()
            om = TogglingOptionMenu(par, variable=var, values=values,
                                    command=_cmd,
                                    fg_color=C["widget"],
                                    button_color=C["dim"],
                                    button_hover_color=C["btnhov"],
                                    dropdown_fg_color=C["widget"],
                                    dropdown_hover_color=C["btnhov"],
                                    dropdown_text_color=C["text"],
                                    text_color=C["text"],
                                    corner_radius=10,
                                    font=("Segoe UI", 9),
                                    dropdown_font=("Segoe UI", 9),
                                    width=width)
            return om
        cb = ttk.Combobox(par, textvariable=var, values=values,
                          state="readonly", width=width // 8)
        if on_change:
            cb.bind("<<ComboboxSelected>>", lambda e: on_change())
        return cb

    def _section_hdr(self, par, title):
        f = tk.Frame(par, bg=C["panel"], pady=10)
        f.pack(fill=tk.X, padx=12)
        tk.Label(f, text=title.upper(), bg=C["panel"], fg=C["accent"],
                 font=("Segoe UI", 7, "bold")).pack(side=tk.LEFT)
        tk.Frame(f, bg=C["accent"], height=1).pack(side=tk.LEFT, fill=tk.X,
                                                    expand=True, padx=(10, 0))

    # ── Macro sidebar list ───────────────────────────────────
    # Indicator colours cycling through macros
    _MAC_COLORS = ["mac_a", "mac_b", "mac_c", "mac_d"]

    def _rebuild_tabs(self):
        for w in self.macro_list_frame.winfo_children():
            w.destroy()

        if not self.macros:
            tk.Label(self.macro_list_frame,
                     text='There are no macros yet.\nClick "+ Add New Macro" to create one.',
                     bg=C["bg"], fg=C["dim"],
                     font=("Segoe UI", 9), justify="center").pack(pady=60)
            return

        for i, m in enumerate(self.macros):
            sel     = (i == self.cur)
            enabled = m.enabled
            ind_c   = C[self._MAC_COLORS[i % len(self._MAC_COLORS)]]
            # Dim the accent bar and dot for disabled macros
            bar_c   = ind_c if enabled else C["dim"]
            item_bg = C["widget"] if sel else C["bg"]
            # Text colours dimmed when macro is disabled
            name_fg_col = (C["white"] if sel else C["text"]) if enabled else C["dim"]
            info_fg_col = (C["teal"] if m.bind_key else C["dim"]) if enabled else C["dim"]

            row = tk.Frame(self.macro_list_frame, bg=item_bg)
            row.pack(fill=tk.X, padx=0, pady=0)

            # Coloured left accent bar
            tk.Frame(row, bg=bar_c, width=4).pack(side=tk.LEFT, fill=tk.Y)

            # Indicator dot
            dot = tk.Label(row, text="●", bg=item_bg, fg=bar_c,
                           font=("Segoe UI", 10), padx=10)
            dot.pack(side=tk.LEFT)

            # Name + bind-key sub-block
            info = tk.Frame(row, bg=item_bg)
            info.pack(side=tk.LEFT, fill=tk.X, expand=True, pady=12)

            name_lbl = tk.Label(info, text=m.name, bg=item_bg,
                                fg=name_fg_col,
                                font=("Segoe UI", 10,
                                      "bold" if sel else "normal"),
                                anchor="w")
            name_lbl.pack(anchor="w")

            bind_str = key_label(m.bind_key) if m.bind_key else "No key bound"
            tk.Label(info, text=f"⌨ {bind_str}  ·  {m.loop.split()[0]}",
                     bg=item_bg, fg=info_fg_col,
                     font=("Segoe UI", 7)).pack(anchor="w")

            # Right-side action buttons
            btn_bg = item_bg

            # Delete
            if CTK:
                del_btn = ctk.CTkButton(row, text="🗑",
                                        fg_color="transparent", hover_color=C["btnhov"],
                                        text_color=C["text"], font=("Segoe UI", 11),
                                        corner_radius=8, width=32, height=32,
                                        command=lambda idx=i: self._del_macro(idx))
            else:
                del_btn = tk.Button(row, text="🗑", bg=btn_bg, fg=C["text"],
                                    activebackground=C["btnhov"], activeforeground=C["text"],
                                    font=("Segoe UI", 10), relief="flat", bd=0,
                                    cursor="hand2", padx=6, pady=6,
                                    command=lambda idx=i: self._del_macro(idx))
            del_btn.pack(side=tk.RIGHT, padx=(2, 6))

            # Edit — border style so it's always distinct from the background
            if CTK:
                edit_btn = ctk.CTkButton(row, text="✏",
                                         fg_color=C["widget"], hover_color=C["btnhov"],
                                         text_color=C["text"], font=("Segoe UI", 11),
                                         border_width=1, border_color=C["border"],
                                         corner_radius=8, width=32, height=32,
                                         command=lambda idx=i: self._open_editor(idx))
            else:
                edit_btn = tk.Button(row, text="✏", bg=C["widget"], fg=C["text"],
                                     activebackground=C["btnhov"],
                                     activeforeground=hover_fg(C["text"]),
                                     font=("Segoe UI", 10), relief="flat", bd=0,
                                     cursor="hand2", padx=6, pady=6,
                                     command=lambda idx=i: self._open_editor(idx))
                edit_btn.bind("<Enter>", lambda e, b=edit_btn: b.config(
                    bg=C["btnhov"], fg=hover_fg(C["text"])))
                edit_btn.bind("<Leave>", lambda e, b=edit_btn: b.config(
                    bg=C["widget"], fg=C["text"]))
            edit_btn.pack(side=tk.RIGHT, padx=2)

            # Enable / Disable toggle button
            tog_text = "⏸" if enabled else "▶"
            tog_bg   = C["teal"] if enabled else C["btn"]
            tog_tc   = teal_fg() if enabled else C["dim"]
            tog_tip  = "Disable macro" if enabled else "Enable macro"
            if CTK:
                tog_btn = ctk.CTkButton(row, text=tog_text,
                                        fg_color=tog_bg, hover_color=C["btnhov"],
                                        text_color=tog_tc, font=("Segoe UI", 11),
                                        corner_radius=8, width=32, height=32,
                                        command=lambda idx=i: self._toggle_macro_enabled(idx))
            else:
                tog_btn = tk.Button(row, text=tog_text, bg=tog_bg, fg=tog_tc,
                                    activebackground=C["btnhov"],
                                    activeforeground=hover_fg(tog_tc),
                                    font=("Segoe UI", 10), relief="flat", bd=0,
                                    cursor="hand2", padx=6, pady=6,
                                    command=lambda idx=i: self._toggle_macro_enabled(idx))
            attach_tooltip(tog_btn, tog_tip)
            tog_btn.pack(side=tk.RIGHT, padx=2)

            # Click row to select (but not on buttons)
            for w in (row, dot, name_lbl, info):
                w.bind("<Double-Button-1>", lambda e, idx=i: self._open_editor(idx))
                w.config(cursor="hand2")
            for w in (row, dot, name_lbl, info):
                w.bind("<Button-1>", lambda e, idx=i: self._select(idx))

            # Hover — track fg colours too so text stays readable on hover bg
            all_children_fg = [
                (row,      None),
                (dot,      bar_c),
                (info,     None),
                (name_lbl, hover_fg(name_fg_col)),
            ]
            def _enter(e, r=row, bg=item_bg, items=all_children_fg):
                hover = C["btnhov"]
                r.config(bg=hover)
                for widget, fg in items:
                    try:
                        if fg is not None:
                            widget.config(bg=hover, fg=fg)
                        else:
                            widget.config(bg=hover)
                    except: pass
            def _leave(e, r=row, bg=item_bg, items=all_children_fg, nfg=name_fg_col):
                r.config(bg=bg)
                for widget, fg in items:
                    try:
                        if fg is not None:
                            widget.config(bg=bg, fg=nfg if widget is items[3][0] else fg)
                        else:
                            widget.config(bg=bg)
                    except: pass
            row.bind("<Enter>", _enter)
            row.bind("<Leave>", _leave)

            tk.Frame(self.macro_list_frame, bg=C["border"], height=1).pack(fill=tk.X)

    # ── Macro CRUD ───────────────────────────────────────────
    def _new_macro(self):
        m = Macro(f"Macro {len(self.macros)+1}")
        self.macros.append(m)
        idx = len(self.macros) - 1
        self._select(idx)
        self._open_editor(idx)

    def _del_macro(self, idx):
        if len(self.macros) == 1:
            messagebox.showwarning("Cannot Delete", "Need at least one macro."); return
        if messagebox.askyesno("Delete", f"Delete '{self.macros[idx].name}'?"):
            # Close editor if it's editing this macro
            if self._editor_win and self._editor_win.winfo_exists():
                self._editor_win.destroy()
                self._editor_win = None
            self.macros.pop(idx)
            new_cur = min(idx, len(self.macros) - 1)
            self.cur = new_cur
            self._rebuild_tabs()
            self._refresh_hotkeys()

    def _select(self, idx):
        if 0 <= self.cur < len(self.macros):
            self._ui_to_macro()
        self.cur = idx
        self._rebuild_tabs()
        self._refresh_hotkeys()
        # If the editor is open, update it
        if self._editor_win and self._editor_win.winfo_exists():
            self._editor_load_macro()

    def _toggle_macro_enabled(self, idx):
        """Toggle a macro's enabled state and refresh the hotkey registration."""
        if not (0 <= idx < len(self.macros)): return
        self.macros[idx].enabled = not self.macros[idx].enabled
        self._rebuild_tabs()
        self._refresh_hotkeys()
        self._save()

    def _toggle_system(self):
        """Disable/enable all hotkey-triggered macros."""
        self._system_disabled = not self._system_disabled
        if self._system_disabled:
            self.hkmgr.clear()
            if CTK:
                self.sys_btn.configure(text="▶  Enable System", fg_color=C["green"])
            else:
                self.sys_btn.config(text="▶  Enable System", bg=C["green"])
            self._set_status("System disabled — hotkeys paused.", C["yellow"])
        else:
            self._refresh_hotkeys()
            if CTK:
                self.sys_btn.configure(text="⏸  Disable System", fg_color=C["btn"])
            else:
                self.sys_btn.config(text="⏸  Disable System", bg=C["btn"])
            self._set_status("System enabled.", C["green"])


    def _ui_to_macro(self):
        if not (0 <= self.cur < len(self.macros)): return
        if not hasattr(self, "v_name"): return
        m = self.macros[self.cur]
        m.name    = self.v_name.get().strip() or m.name
        m.trigger = self.v_trigger.get()
        m.loop    = self.v_loop.get()
        m.capture = self.v_capture.get()
        m.rec_move = self.v_rec_move.get()
        m.rec_btn  = self.v_rec_btn.get()
        m.rec_kb   = self.v_rec_kb.get()
        m.rec_wait = self.v_rec_wait.get()
        try: m.min_delay = max(0, int(self.v_min_delay.get()))
        except: pass
        try: m.repeat_n = max(1, int(self.v_repeat.get()))
        except: pass

    def _name_changed(self):
        if not hasattr(self, "v_name"): return
        idx = self._editor_macro_idx
        if 0 <= idx < len(self.macros):
            new_name = self.v_name.get().strip()
            if new_name:
                self.macros[idx].name = new_name
            self._rebuild_tabs()
            if self._editor_win and self._editor_win.winfo_exists():
                self._editor_win.title(f"macrobin — {self.macros[idx].name}")

    def _loop_changed(self):
        if not hasattr(self, "repeat_row"): return
        if self.v_loop.get() == "Repeat N Times":
            self.repeat_row.grid()
        else:
            self.repeat_row.grid_remove()

    def _toggle(self, var):
        var.set(not var.get())
        self._update_toggles()

    def _update_toggles(self):
        if not hasattr(self, "_toggle_btns"): return
        for (b, var) in self._toggle_btns.values():
            on = var.get()
            if CTK:
                b.configure(fg_color=C["teal"] if on else C["btn"],
                            text_color=teal_fg() if on else C["dim"])
            else:
                b.config(bg=C["teal"] if on else C["btn"],
                         fg=teal_fg() if on else C["dim"])

    # ── Key binding ──────────────────────────────────────────
    def _start_bind(self):
        if self.binding: return
        self.binding = True
        self.v_bind.set("Press key or mouse button\u2026")
        if CTK:
            self.bind_ent.configure(border_color=C["accent"])
        else:
            self.bind_ent.config(highlightbackground=C["accent"])
        self._set_status("Waiting for key or mouse button\u2026", C["yellow"])

        if not PYNPUT:
            raw = simpledialog.askstring("Bind Key","Key name (e.g. F5, a, Key.space):")
            if raw:
                self.v_bind.set(raw)
                if 0 <= self.cur < len(self.macros):
                    self.macros[self.cur].bind_key = raw
                self._refresh_hotkeys()
            self.binding = False
            if not CTK:
                self.bind_ent.config(highlightbackground=C["border"])
            self._set_status("Ready")
            return

        # Route capture through HotkeyMgr's existing listeners so there is
        # only ever ONE keyboard hook and ONE mouse hook at a time.
        # The old approach (spawning extra listeners here) caused two
        # WH_MOUSE_LL hooks to fight over events (mouse clicks silently
        # dropped) and a stop()-vs-return-False race condition (PC freeze).
        def on_captured(raw):
            self._q.put(lambda r=raw: self._finish_bind(r))

        self.hkmgr.start_bind(on_captured)

    def _finish_bind(self, raw):
        self.binding = False
        if CTK:
            self.bind_ent.configure(border_color=C["border"])
        else:
            self.bind_ent.config(highlightbackground=C["border"])

        # Block left and right mouse buttons — they would interfere with normal use
        BLOCKED = {"Button.left", "Button.right"}
        if raw in BLOCKED:
            self.v_bind.set("")
            self._set_status(
                f"{key_label(raw)} cannot be used as a trigger — choose a key or middle/side button.",
                C["yellow"])
            self.root.after(1800, lambda: self._set_status("Ready"))
            return

        if raw:
            self.v_bind.set(key_label(raw))
            if 0 <= self.cur < len(self.macros):
                self.macros[self.cur].bind_key = raw
            self._refresh_hotkeys()
            self._set_status(f"Bound: {key_label(raw)}", C["green"])
        else:
            self._set_status("Ready")

    def _clear_bind(self):
        if self.binding:
            self.hkmgr.cancel_bind()
            self.binding = False
            if CTK:
                self.bind_ent.configure(border_color=C["border"])
            else:
                self.bind_ent.config(highlightbackground=C["border"])
        if 0 <= self.cur < len(self.macros):
            self.hkmgr.unregister(self.macros[self.cur].bind_key)
            self.macros[self.cur].bind_key = ""
        self.v_bind.set("")
        self._set_status("Key binding cleared")

    def _refresh_hotkeys(self):
        self.hkmgr.clear()
        if getattr(self, "_system_disabled", False):
            return   # system is paused — don't re-register any hotkeys
        for m in self.macros:
            if not m.bind_key: continue
            if not m.enabled: continue   # disabled macros don't respond to hotkeys
            def make(macro_ref):
                def press():
                    self._q.put(lambda mr=macro_ref: self._hotkey_press(mr))
                def release():
                    self._q.put(lambda mr=macro_ref: self._hotkey_release(mr))
                return press, release
            p, r = make(m)
            self.hkmgr.register(m.bind_key, p, r)

    def _hotkey_press(self, m):
        if m.loop in ("While Holding Key","Run Once","Repeat N Times"):
            self._play(m)

    def _hotkey_release(self, m):
        if m.loop == "While Holding Key" and self.player:
            self.player.stop()
            self._on_play_done()

    # ── Recording ────────────────────────────────────────────
    def _toggle_rec(self):
        if self.is_rec: self._stop_rec()
        else: self._start_rec()

    def _start_rec(self):
        if self.cur < 0: return
        if self.is_play:
            messagebox.showwarning("Busy","Stop playback first."); return
        self._ui_to_macro()
        m = self.macros[self.cur]
        if m.actions:
            ans = messagebox.askyesnocancel(
                "Recording",
                "Replace existing actions?\n\nYes=Replace  No=Append  Cancel=Abort")
            if ans is None: return
            if ans:
                m.actions.clear()
                self._refresh_list()
        self.recorder = Recorder(m, on_add=lambda a: self._q.put(self._refresh_list))
        if not self.recorder.start():
            messagebox.showerror("Error",
                "Cannot start recording.\nInstall pynput:  pip install pynput")
            return
        self.is_rec = True
        if hasattr(self, "rec_btn") and self.rec_btn.winfo_exists():
            if CTK:
                self.rec_btn.configure(text="⏹  Stop Recording  [Ctrl+F10]",
                                       fg_color=C["red"], text_color=C["white"])
            else:
                self.rec_btn.config(text="⏹  Stop Recording  [Ctrl+F10]",
                                    bg=C["red"], fg=C["white"])
        if hasattr(self, "rec_dot") and self.rec_dot.winfo_exists():
            self.rec_dot.config(fg=C["red"])
        self._blink()
        self._set_status("Recording…", C["red"])
        self.root.bind("<Control-F10>", lambda e: self._stop_rec())

    def _stop_rec(self):
        if not self.is_rec: return
        if self.recorder: self.recorder.stop(); self.recorder = None
        self.is_rec = False
        if hasattr(self, "rec_btn") and self.rec_btn.winfo_exists():
            if CTK:
                self.rec_btn.configure(text="⏺  Record  [Ctrl+F10]",
                                       fg_color=C["btn"], text_color=C["white"])
            else:
                self.rec_btn.config(text="⏺  Record  [Ctrl+F10]",
                                    bg=C["btn"], fg=C["white"])
        if hasattr(self, "rec_dot") and self.rec_dot.winfo_exists():
            self.rec_dot.config(fg=C["dim"])
        n = len(self.macros[self.cur].actions) if 0<=self.cur<len(self.macros) else 0
        self._set_status(f"Stopped — {n} actions captured.", C["green"])
        self.root.unbind("<Control-F10>")
        self._refresh_list()

    def _blink(self):
        if not self.is_rec: return
        if not hasattr(self, "rec_dot") or not self.rec_dot.winfo_exists(): return
        cur = self.rec_dot.cget("fg")
        self.rec_dot.config(fg=C["bg"] if cur == C["red"] else C["red"])
        self.root.after(500, self._blink)

    # ── Playback ─────────────────────────────────────────────
    def _toggle_play(self):
        if self.is_play: self._stop_play()
        elif 0<=self.cur<len(self.macros): self._play(self.macros[self.cur])

    def _play(self, m):
        if self.is_rec or self.is_play: return
        if not m.actions:
            messagebox.showinfo("Empty","No actions to play."); return
        if not PYNPUT:
            messagebox.showerror("Error","pynput not installed."); return
        self.player  = Player(m)
        self.is_play = True
        if hasattr(self, "play_btn") and self.play_btn.winfo_exists():
            if CTK:
                self.play_btn.configure(text="⏹  Stop",
                                        fg_color=C["accent"],
                                        text_color=accent_fg())
            else:
                self.play_btn.config(text="⏹  Stop",
                                     bg=C["accent"],
                                     fg=accent_fg())
        self._set_status("Playing…", C["green"])
        self.player.play(done_cb=lambda: self._q.put(self._on_play_done))

    def _stop_play(self):
        if self.player: self.player.stop()
        self._on_play_done()

    def _on_play_done(self):
        self.is_play = False
        self.player  = None
        if hasattr(self, "play_btn") and self.play_btn.winfo_exists():
            if CTK:
                self.play_btn.configure(text="▶  Play",
                                        fg_color=C["teal"],
                                        text_color=teal_fg())
            else:
                self.play_btn.config(text="▶  Play",
                                     bg=C["teal"],
                                     fg=teal_fg())
        self._set_status("Ready")
        self._rebuild_tabs()

    def _stop_all(self):
        self._stop_rec()
        self._stop_play()

    # ── Action list ──────────────────────────────────────────
    def _refresh_list(self, *_):
        if not (0 <= self.cur < len(self.macros)): return
        if not hasattr(self, "lb") or not self.lb.winfo_exists(): return
        m = self.macros[self.cur]
        self.lb.delete(0, tk.END)
        for i, a in enumerate(m.actions):
            delay = f"{a.delay:>5}ms" if a.delay else "       —"
            line  = f"  {i+1:>3}.   {a.label():<40}  {delay}"
            self.lb.insert(tk.END, line)
            self.lb.itemconfig(i, fg=a.color())
        n = len(m.actions)
        self.cnt_lbl.config(text=f"{n} action{'s' if n != 1 else ''}")

    def _sel_changed(self):
        self.sel = list(self.lb.curselection())

    def _cur_macro(self) -> Macro | None:
        return self.macros[self.cur] if 0<=self.cur<len(self.macros) else None

    # ── Action edit dialogs ──────────────────────────────────
    def _add_dlg(self):
        m = self._cur_macro()
        if not m: return
        self._action_dlg(m=m, action=None,
                         insert_after=max(self.sel)+1 if self.sel else None)

    def _edit_dlg(self):
        m = self._cur_macro()
        if not m or not self.sel: return
        idx = self.sel[0]
        if idx < len(m.actions):
            self._action_dlg(m=m, action=m.actions[idx], idx=idx)

    def _action_dlg(self, m, action=None, idx=None, insert_after=None):
        editing = action is not None
        dlg = tk.Toplevel(self._editor_win if (self._editor_win and self._editor_win.winfo_exists()) else self.root)
        dlg.title("Edit Action" if editing else "Add Action")
        dlg.geometry("370x400")
        dlg.configure(bg=C["panel"])
        dlg.resizable(False, False)
        dlg.grab_set()
        self._set_icon(dlg)

        tk.Label(dlg, text="Edit Action" if editing else "Add Action",
                 bg=C["panel"], fg=C["white"],
                 font=("Segoe UI", 11, "bold")).pack(pady=10, padx=14, anchor="w")

        sf = tk.Frame(dlg, bg=C["panel"], padx=14)
        sf.pack(fill=tk.X)

        # ── Type display mapping ─────────────────────────────
        DISP_TYPES   = ["Keyboard Key", "Mouse Move", "Mouse Down", "Mouse Up", "Wait"]
        DISP_TO_INT  = {"Keyboard Key": "kb_key", "Mouse Move": MM,
                        "Mouse Down": MB_D, "Mouse Up": MB_U, "Wait": WT}
        KIND_TO_DISP = {KD: "Keyboard Key", KU: "Keyboard Key", KPR: "Keyboard Key",
                        MM: "Mouse Move", MB_D: "Mouse Down",
                        MB_U: "Mouse Up", WT: "Wait"}
        KEY_STATUS_OPTS = ["Press and Release", "Press / Hold", "Release"]
        KIND_TO_KS      = {KD: "Press / Hold", KU: "Release", KPR: "Press and Release"}

        init_kind   = action.kind if editing else KD
        init_disp   = KIND_TO_DISP.get(init_kind, "Keyboard Key")
        init_status = KIND_TO_KS.get(init_kind, "Press and Release")

        v_type_disp  = tk.StringVar(value=init_disp)
        v_key_status = tk.StringVar(value=init_status)

        if not editing:
            tk.Label(sf, text="Action Type:", **self._lkw()).pack(anchor="w")
            self._combo(sf, v_type_disp, DISP_TYPES, width=260).pack(anchor="w", pady=(2, 8))

        dyn = tk.Frame(dlg, bg=C["panel"], padx=14)
        dyn.pack(fill=tk.X)
        widgets = {}
        _capturing = [False]   # mutable flag shared with closures

        def _stop_capture():
            _capturing[0] = False
            if PYNPUT:
                self.hkmgr.cancel_bind()

        # Make sure any in-progress capture is cancelled when dialog closes
        dlg.protocol("WM_DELETE_WINDOW", lambda: (_stop_capture(), dlg.destroy()))

        def build_form(*_):
            _stop_capture()
            for w in dyn.winfo_children():
                w.destroy()
            widgets.clear()
            t = DISP_TO_INT.get(v_type_disp.get(), "kb_key")

            # ── Keyboard Key ────────────────────────────────
            if t == "kb_key":
                tk.Label(dyn, text="Key Status:", **self._lkw()).pack(anchor="w")
                self._combo(dyn, v_key_status, KEY_STATUS_OPTS, width=200).pack(
                    anchor="w", pady=(2, 8))

                tk.Label(dyn, text="Key:", **self._lkw()).pack(anchor="w")
                init_key = action.data.get("key", "") if editing else ""
                v_key = tk.StringVar(value=key_label(init_key) if init_key else "")
                widgets["key_raw"] = [init_key]   # store raw pynput string

                cap_f = tk.Frame(dyn, bg=C["panel"])
                cap_f.pack(anchor="w", pady=(2, 8))

                if CTK:
                    key_disp = ctk.CTkEntry(cap_f, textvariable=v_key,
                                            fg_color=C["widget"], text_color=C["text"],
                                            border_color=C["border"], border_width=2,
                                            corner_radius=10, font=("Segoe UI", 9),
                                            width=160, state="disabled")
                else:
                    key_disp = tk.Entry(cap_f, textvariable=v_key,
                                        bg=C["widget"], fg=C["text"],
                                        state="readonly", width=18,
                                        readonlybackground=C["widget"],
                                        relief="flat", font=("Segoe UI", 9))
                key_disp.pack(side=tk.LEFT, padx=(0, 6))

                status_lbl = tk.Label(cap_f, text="", bg=C["panel"],
                                      fg=C["yellow"], font=("Segoe UI", 8))
                status_lbl.pack(side=tk.LEFT)

                def _start_key_capture():
                    if not PYNPUT:
                        # Fallback: manual entry
                        raw = simpledialog.askstring(
                            "Enter Key", "Key name (e.g. Key.space, 'a', Key.f1):",
                            parent=dlg)
                        if raw:
                            widgets["key_raw"][0] = raw
                            v_key.set(key_label(raw))
                        return
                    _capturing[0] = True
                    status_lbl.config(text="Press a key…")
                    if CTK:
                        key_disp.configure(border_color=C["accent"])
                    else:
                        key_disp.config(highlightbackground=C["accent"])

                    def on_captured(raw):
                        def _apply():
                            _capturing[0] = False
                            widgets["key_raw"][0] = raw
                            v_key.set(key_label(raw))
                            status_lbl.config(text=f"✔ {key_label(raw)}")
                            if CTK:
                                key_disp.configure(border_color=C["border"])
                            else:
                                key_disp.config(highlightbackground=C["border"])
                        dlg.after(0, _apply)

                    self.hkmgr.start_bind(on_captured)

                cap_btn = self._btn(cap_f, "Capture Key", _start_key_capture,
                                    bg=C["btn"], fg=C["text"], fs=9)
                cap_btn.pack(side=tk.LEFT)
                widgets["key"] = widgets  # sentinel — real value in key_raw

            # ── Mouse Move ──────────────────────────────────
            elif t == MM:
                tk.Label(dyn, text="Position:", **self._lkw()).pack(anchor="w")
                pos_f = tk.Frame(dyn, bg=C["panel"])
                pos_f.pack(anchor="w", pady=(2, 8))

                ix = str(action.data.get("x", 0)) if editing else "0"
                iy = str(action.data.get("y", 0)) if editing else "0"
                vx = tk.StringVar(value=ix)
                vy = tk.StringVar(value=iy)

                tk.Label(pos_f, text="X:", **self._lkw()).pack(side=tk.LEFT)
                ex = self._entry(pos_f, vx, w=7); ex.pack(side=tk.LEFT, padx=(2,8))
                tk.Label(pos_f, text="Y:", **self._lkw()).pack(side=tk.LEFT)
                ey = self._entry(pos_f, vy, w=7); ey.pack(side=tk.LEFT, padx=(2,8))
                widgets["x"] = ex; widgets["y"] = ey

                cap_pos_lbl = tk.Label(dyn, text="", bg=C["panel"],
                                       fg=C["yellow"], font=("Segoe UI", 8))
                cap_pos_lbl.pack(anchor="w")

                def _capture_position():
                    if not PYNPUT:
                        cap_pos_lbl.config(text="pynput not installed")
                        return
                    cap_pos_lbl.config(text="Move mouse to position, then press any key…")
                    _capturing[0] = True

                    # Use a one-shot keyboard listener to snap position on keypress
                    import threading as _th
                    def _watch():
                        import time as _t
                        _t.sleep(0.1)
                        from pynput.mouse import Controller as _MC
                        from pynput import keyboard as _KB
                        snap = [None]
                        def on_press(key):
                            snap[0] = _MC().position
                            return False  # stop listener
                        with _KB.Listener(on_press=on_press) as lst:
                            lst.join()
                        if snap[0]:
                            def _apply():
                                vx.set(str(snap[0][0]))
                                vy.set(str(snap[0][1]))
                                cap_pos_lbl.config(text=f"✔  ({snap[0][0]}, {snap[0][1]})")
                                _capturing[0] = False
                            dlg.after(0, _apply)
                    _th.Thread(target=_watch, daemon=True).start()

                self._btn(dyn, "📍  Capture from Mouse", _capture_position,
                          bg=C["btn"], fg=C["text"], fs=9).pack(anchor="w", pady=(0, 4))

            # ── Mouse Button ─────────────────────────────────
            elif t in (MB_D, MB_U):
                tk.Label(dyn, text="Mouse Button:", **self._lkw()).pack(anchor="w")
                init_btn = action.data.get("button", "Button.left") if editing else "Button.left"
                v_btn_raw = [init_btn]
                v_btn_disp = tk.StringVar(value=key_label(init_btn))

                cap_f2 = tk.Frame(dyn, bg=C["panel"])
                cap_f2.pack(anchor="w", pady=(2, 8))

                if CTK:
                    btn_disp = ctk.CTkEntry(cap_f2, textvariable=v_btn_disp,
                                            fg_color=C["widget"], text_color=C["text"],
                                            border_color=C["border"], border_width=2,
                                            corner_radius=10, font=("Segoe UI", 9),
                                            width=120, state="disabled")
                else:
                    btn_disp = tk.Entry(cap_f2, textvariable=v_btn_disp,
                                        bg=C["widget"], fg=C["text"],
                                        state="readonly", width=14,
                                        readonlybackground=C["widget"],
                                        relief="flat", font=("Segoe UI", 9))
                btn_disp.pack(side=tk.LEFT, padx=(0, 6))

                btn_status = tk.Label(cap_f2, text="", bg=C["panel"],
                                      fg=C["yellow"], font=("Segoe UI", 8))
                btn_status.pack(side=tk.LEFT)

                def _start_btn_capture():
                    if not PYNPUT:
                        btn_status.config(text="pynput not installed")
                        return
                    _capturing[0] = True
                    btn_status.config(text="Click a mouse button…")
                    if CTK:
                        btn_disp.configure(border_color=C["accent"])
                    else:
                        btn_disp.config(highlightbackground=C["accent"])

                    def on_captured(raw):
                        # Only accept mouse buttons (Button.*)
                        if not raw.startswith("Button."):
                            # Got a keyboard key — re-arm
                            self.hkmgr.start_bind(on_captured)
                            return
                        def _apply():
                            _capturing[0] = False
                            v_btn_raw[0] = raw
                            v_btn_disp.set(key_label(raw))
                            btn_status.config(text=f"✔ {key_label(raw)}")
                            if CTK:
                                btn_disp.configure(border_color=C["border"])
                            else:
                                btn_disp.config(highlightbackground=C["border"])
                        dlg.after(0, _apply)

                    self.hkmgr.start_bind(on_captured)

                self._btn(cap_f2, "Capture Button", _start_btn_capture,
                          bg=C["btn"], fg=C["text"], fs=9).pack(side=tk.LEFT)
                widgets["button"] = v_btn_raw

            # ── Wait ─────────────────────────────────────────
            elif t == WT:
                tk.Label(dyn, text="Duration (ms):", **self._lkw()).pack(anchor="w")
                v_ms = tk.StringVar(value=str(action.data.get("ms", 500)) if editing else "500")
                e = self._entry(dyn, v_ms, w=10)
                e.pack(anchor="w", pady=(2, 8))
                widgets["ms"] = e

        v_type_disp.trace_add("write", build_form)
        build_form()

        # Delay row
        df = tk.Frame(dlg, bg=C["panel"], padx=14)
        df.pack(fill=tk.X)
        tk.Label(df, text="Delay before (ms):", **self._lkw()).pack(side=tk.LEFT)
        v_delay = tk.StringVar(value=str(action.delay) if editing else "0")
        self._entry(df, v_delay, w=8).pack(side=tk.LEFT, padx=4)

        # Buttons
        bf = tk.Frame(dlg, bg=C["panel"])
        bf.pack(pady=10)

        def _do_insert(new_a, pos):
            if pos is not None:
                m.actions.insert(pos, new_a)
            else:
                m.actions.append(new_a)

        def commit():
            _stop_capture()
            t = DISP_TO_INT.get(v_type_disp.get(), "kb_key")
            try:
                delay = max(0, int(v_delay.get()))
            except ValueError:
                delay = 0
            try:
                data = {}
                if t == "kb_key":
                    raw_key = widgets.get("key_raw", [""])[0]
                    if not raw_key:
                        messagebox.showwarning("No Key", "Please capture a key first.",
                                               parent=dlg)
                        return
                    data["key"] = raw_key
                    status = v_key_status.get()
                    if status == "Press / Hold":
                        kind_a, kind_b = KD, None
                    elif status == "Release":
                        kind_a, kind_b = KU, None
                    else:
                        kind_a, kind_b = KPR, None

                    if editing:
                        action.kind  = kind_a
                        action.data  = data
                        action.delay = delay
                        if kind_b is not None:
                            real_idx = idx if idx is not None else (
                                self.sel[0] if self.sel else len(m.actions) - 1)
                            m.actions.insert(real_idx + 1, Action(kind_b, dict(data), 0))
                    else:
                        pos = insert_after
                        _do_insert(Action(kind_a, data, delay), pos)
                        if kind_b is not None:
                            pos2 = (pos + 1) if pos is not None else None
                            _do_insert(Action(kind_b, dict(data), 0), pos2)

                elif t == MM:
                    data["x"] = int(widgets["x"].get())
                    data["y"] = int(widgets["y"].get())
                    if editing:
                        action.kind = MM; action.data = data; action.delay = delay
                    else:
                        _do_insert(Action(MM, data, delay), insert_after)

                elif t in (MB_D, MB_U):
                    data["button"] = widgets["button"][0]
                    if editing:
                        action.kind = t; action.data = data; action.delay = delay
                    else:
                        _do_insert(Action(t, data, delay), insert_after)

                elif t == WT:
                    data["ms"] = max(0, int(widgets["ms"].get()))
                    if editing:
                        action.kind = WT; action.data = data; action.delay = delay
                    else:
                        _do_insert(Action(WT, data, delay), insert_after)

            except ValueError as e:
                messagebox.showerror("Input Error", str(e))
                return

            self._refresh_list()
            dlg.destroy()

        self._btn(bf, "Save" if editing else "Add", commit,
                  bg=C["accent"], fg=accent_fg(), w=10).pack(side=tk.LEFT, padx=4)
        self._btn(bf, "Cancel", lambda: (_stop_capture(), dlg.destroy()),
                  bg=C["btn"], w=10).pack(side=tk.LEFT, padx=4)

    # ── Action list operations ───────────────────────────────
    def _duplicate(self):
        m = self._cur_macro()
        if not m or not self.sel: return
        for i in sorted(self.sel, reverse=True):
            if i < len(m.actions):
                m.actions.insert(i+1, Action.from_dict(m.actions[i].to_dict()))
        self._refresh_list()

    def _delete(self):
        m = self._cur_macro()
        if not m or not self.sel: return
        for i in sorted(self.sel, reverse=True):
            if i < len(m.actions): m.actions.pop(i)
        self.sel = []
        self._refresh_list()

    def _move_up(self):
        m = self._cur_macro()
        if not m or not self.sel: return
        i = self.sel[0]
        if i > 0:
            m.actions[i], m.actions[i-1] = m.actions[i-1], m.actions[i]
            self._refresh_list()
            self.lb.selection_set(i-1); self.sel = [i-1]

    def _move_down(self):
        m = self._cur_macro()
        if not m or not self.sel: return
        i = self.sel[0]
        if i < len(m.actions)-1:
            m.actions[i], m.actions[i+1] = m.actions[i+1], m.actions[i]
            self._refresh_list()
            self.lb.selection_set(i+1); self.sel = [i+1]

    def _wait_dlg(self):
        m = self._cur_macro()
        if not m: return
        ms = simpledialog.askinteger("Add Wait","Duration (ms):",
                                     initialvalue=500, minvalue=0, maxvalue=600000)
        if ms is None: return
        a = Action(WT, {"ms": ms}, 0)
        if self.sel: m.actions.insert(max(self.sel)+1, a)
        else: m.actions.append(a)
        self._refresh_list()

    def _export(self):
        m = self._cur_macro()
        if not m: return
        path = filedialog.asksaveasfilename(defaultextension=".json",
            filetypes=[("JSON","*.json"),("All","*.*")],
            initialfile=f"{m.name}_actions.json")
        if not path: return
        try:
            with open(path,"w") as f:
                json.dump([a.to_dict() for a in m.actions], f, indent=2)
            self._set_status(f"Exported {len(m.actions)} actions.", C["green"])
        except Exception as e:
            messagebox.showerror("Export Error", str(e))

    def _import(self):
        m = self._cur_macro()
        if not m: return
        path = filedialog.askopenfilename(filetypes=[("JSON","*.json"),("All","*.*")])
        if not path: return
        try:
            with open(path) as f: data = json.load(f)
            actions = [Action.from_dict(a) for a in data]
            m.actions.extend(actions)
            self._refresh_list()
            self._set_status(f"Imported {len(actions)} actions.", C["green"])
        except Exception as e:
            messagebox.showerror("Import Error", str(e))

    def _ctx_menu(self, event):
        menu = tk.Menu(self.root, tearoff=0, bg=C["widget"], fg=C["text"],
                       activebackground=C["sel"], activeforeground=C["white"],
                       relief="flat", bd=1, font=("Segoe UI", 9))
        for item in [
            ("✏  Edit",        self._edit_dlg),
            ("⧉  Duplicate",   self._duplicate),
            None,
            ("⬆  Move Up",     self._move_up),
            ("⬇  Move Down",   self._move_down),
            None,
            ("🗑  Delete",       self._delete),
            ("✂  Clear All",   self._clear_all),
        ]:
            if item is None: menu.add_separator()
            else: menu.add_command(label=item[0], command=item[1])
        try: menu.tk_popup(event.x_root, event.y_root)
        finally: menu.grab_release()

    def _clear_all(self):
        m = self._cur_macro()
        if not m: return
        if messagebox.askyesno("Clear All","Delete all actions in this macro?"):
            m.actions.clear(); self.sel = []; self._refresh_list()

    # ── Transparency ─────────────────────────────────────────
    def _apply_alpha(self):
        self.root.attributes("-alpha", self._alpha)
        if self._editor_win and self._editor_win.winfo_exists():
            self._editor_win.attributes("-alpha", self._alpha)

    def _save_config(self):
        try:
            with open(CONFIGF, "w") as f:
                json.dump({
                    "alpha":         self._alpha,
                    "theme":         self._theme_name,
                    "close_to_tray": self._close_to_tray,
                    "custom_theme":  dict(C_CUSTOM),
                }, f, indent=2)
        except Exception:
            pass

    def _load_config(self):
        if not os.path.exists(CONFIGF): return
        try:
            with open(CONFIGF) as f:
                cfg = json.load(f)
            self._alpha         = float(cfg.get("alpha", 0.92))
            self._theme_name    = cfg.get("theme", "Default (Dark)")
            self._close_to_tray = bool(cfg.get("close_to_tray", True))
            # Restore saved custom palette
            saved_custom = cfg.get("custom_theme", {})
            if saved_custom:
                C_CUSTOM.update({k: v for k, v in saved_custom.items()
                                 if k in C_DEFAULT})
            # Make THEMES["Custom"] point to C_CUSTOM
            THEMES["Custom"] = C_CUSTOM
        except Exception:
            pass

    # ── Settings dialog ──────────────────────────────────────
    def _settings_dlg(self):
        d = tk.Toplevel(self._editor_win if (self._editor_win and self._editor_win.winfo_exists()) else self.root)
        d.title("Settings"); d.geometry("360x460")
        d.configure(bg=C["panel"]); d.grab_set(); d.resizable(False,False)
        self._set_icon(d)

        tk.Label(d, text="Settings", bg=C["panel"], fg=C["white"],
                 font=("Segoe UI",12,"bold")).pack(pady=12)
        for lbl in [f"Version: {VER}",
                    f"Macros file: {SAVEF}",
                    "pynput: " + ("✔ Installed" if PYNPUT else "✗ Not installed"),
                    "customtkinter: " + ("✔ Installed" if CTK else "✗ Not installed")]:
            tk.Label(d, text=lbl, bg=C["panel"], fg=C["dim"],
                     font=("Segoe UI",9), wraplength=320).pack(pady=2)
        if not PYNPUT:
            tk.Label(d, text="pip install pynput", bg=C["panel"], fg=C["yellow"],
                     font=("Consolas",9)).pack(pady=2)
        if not CTK:
            tk.Label(d, text="pip install customtkinter  (for rounded UI)",
                     bg=C["panel"], fg=C["yellow"], font=("Consolas",9)).pack(pady=2)

        # ── Transparency slider ──
        tk.Frame(d, bg=C["border"], height=1).pack(fill=tk.X, pady=(10,0), padx=14)
        alpha_f = tk.Frame(d, bg=C["panel"])
        alpha_f.pack(fill=tk.X, padx=18, pady=10)
        pct = int(self._alpha * 100)
        alpha_lbl = tk.Label(alpha_f, text=f"Window Transparency:  {pct}%",
                             bg=C["panel"], fg=C["text"], font=("Segoe UI", 9))
        alpha_lbl.pack(anchor="w", pady=(0,4))
        alpha_var = tk.IntVar(value=pct)
        def _on_alpha(val):
            v = int(float(val))
            alpha_lbl.config(text=f"Window Transparency:  {v}%")
            self._alpha = v / 100.0
            self._apply_alpha(); self._save_config()
        if CTK:
            ctk.CTkSlider(alpha_f, from_=40, to=100, variable=alpha_var,
                          command=_on_alpha, button_color=C["accent"],
                          button_hover_color=C["btnhov"], progress_color=C["accent"],
                          fg_color=C["widget"], width=300, height=18).pack(anchor="w")
        else:
            tk.Scale(alpha_f, from_=40, to=100, orient=tk.HORIZONTAL,
                     variable=alpha_var, command=_on_alpha,
                     bg=C["panel"], fg=C["text"], troughcolor=C["widget"],
                     highlightthickness=0, length=300, showvalue=False).pack(anchor="w")

        # ── Theme dropdown ──
        tk.Frame(d, bg=C["border"], height=1).pack(fill=tk.X, pady=(4,0), padx=14)
        theme_f = tk.Frame(d, bg=C["panel"])
        theme_f.pack(fill=tk.X, padx=18, pady=(10,6))
        tk.Label(theme_f, text="Theme:", bg=C["panel"], fg=C["text"],
                 font=("Segoe UI", 9)).pack(anchor="w", pady=(0,4))
        theme_row = tk.Frame(theme_f, bg=C["panel"])
        theme_row.pack(anchor="w", fill=tk.X)
        theme_var = tk.StringVar(value=self._theme_name)
        theme_note = tk.Label(theme_f, text="", bg=C["panel"], fg=C["dim"],
                              font=("Segoe UI", 8), wraplength=300)
        def _on_theme(*_):
            chosen = theme_var.get()
            if chosen == self._theme_name: return
            self._theme_name = chosen
            palette = THEMES.get(chosen) or C_DEFAULT
            C.update(palette)
            self._save_config()
            try: d.destroy()
            except: pass
            self.root.after(10, self._rebuild_main_ui)
        if CTK:
            TogglingOptionMenu(theme_row, variable=theme_var,
                               values=list(THEMES.keys()), command=lambda v: _on_theme(),
                               fg_color=C["widget"], button_color=C["dim"],
                               button_hover_color=C["btnhov"],
                               dropdown_fg_color=C["widget"],
                               dropdown_hover_color=C["btnhov"],
                               dropdown_text_color=C["text"],
                               text_color=C["text"], corner_radius=10,
                               font=("Segoe UI",9), dropdown_font=("Segoe UI",9),
                               width=210).pack(side=tk.LEFT, anchor="w")
        else:
            cb = ttk.Combobox(theme_row, textvariable=theme_var,
                              values=list(THEMES.keys()), state="readonly", width=22)
            cb.bind("<<ComboboxSelected>>", _on_theme)
            cb.pack(side=tk.LEFT, anchor="w")

        self._btn(theme_row, "✏ Customize", lambda: self._custom_theme_dlg(d),
                  bg=C["btn"], fg=C["text"], fs=9).pack(side=tk.LEFT, padx=(8,0))
        theme_note.pack(anchor="w", pady=(4,0))

        # ── Close-to-tray toggle ──
        tk.Frame(d, bg=C["border"], height=1).pack(fill=tk.X, pady=(4,0), padx=14)
        tray_f = tk.Frame(d, bg=C["panel"])
        tray_f.pack(fill=tk.X, padx=18, pady=(10,4))
        tray_var = tk.BooleanVar(value=self._close_to_tray)
        tray_note = tk.Label(tray_f, text="", bg=C["panel"], fg=C["dim"],
                             font=("Segoe UI", 8))
        def _on_tray():
            self._close_to_tray = tray_var.get()
            self._save_config()
            tray_note.config(text="Close-to-tray " +
                             ("enabled." if self._close_to_tray else "disabled."))
        if CTK:
            ctk.CTkCheckBox(tray_f, text="Minimise to system tray on close",
                            variable=tray_var, command=_on_tray,
                            fg_color=C["accent"], hover_color=C["btnhov"],
                            text_color=C["text"], font=("Segoe UI",9),
                            checkmark_color=C["bar"]).pack(anchor="w")
        else:
            tk.Checkbutton(tray_f, text="Minimise to system tray on close",
                           variable=tray_var, command=_on_tray,
                           bg=C["panel"], fg=C["text"],
                           activebackground=C["panel"], activeforeground=C["white"],
                           selectcolor=C["widget"],
                           font=("Segoe UI",9), relief="flat").pack(anchor="w")
        if not PYSTRAY:
            tk.Label(tray_f, text="(requires pystray + Pillow)", bg=C["panel"],
                     fg=C["yellow"], font=("Segoe UI",8)).pack(anchor="w")
        tray_note.pack(anchor="w", pady=(2,0))

        self._btn(d, "Close", d.destroy, bg=C["btn"], fg=C["white"], w=10).pack(pady=10)

    def _custom_theme_dlg(self, parent_dlg=None):
        """Open a sub-window to edit all colours in the Custom theme."""
        from tkinter import colorchooser as _colorchooser

        # Human-readable labels for each palette key
        KEY_LABELS = {
            "bg":      "Background",
            "panel":   "Panel / Surface",
            "sidebar": "Sidebar",
            "widget":  "Input / Widget bg",
            "btn":     "Button",
            "btnhov":  "Button Hover",
            "accent":  "Accent (logo / highlights)",
            "teal":    "Secondary accent (play/toggle)",
            "text":    "Main text",
            "dim":     "Dimmed / secondary text",
            "white":   "Bright text",
            "border":  "Borders / separators",
            "sel":     "Selection highlight",
            "green":   "Success / green",
            "red":     "Error / stop / red",
            "yellow":  "Warning / amber",
            "bar":     "Top & bottom bars",
        }
        # Only show the visually meaningful keys (not the derived tag/mac colours)
        EDIT_KEYS = list(KEY_LABELS.keys())

        parent = parent_dlg if (parent_dlg and parent_dlg.winfo_exists()) else self.root
        w = tk.Toplevel(parent)
        w.title("Custom Theme Editor")
        w.configure(bg=C["panel"])
        w.resizable(False, True)
        w.grab_set()
        self._set_icon(w)

        tk.Label(w, text="Custom Theme Editor", bg=C["panel"], fg=C["white"],
                 font=("Segoe UI", 11, "bold")).pack(pady=(12,4), padx=16, anchor="w")
        tk.Label(w, text="Changes apply immediately when you click 'Apply & Use'.",
                 bg=C["panel"], fg=C["dim"],
                 font=("Segoe UI", 8)).pack(padx=16, anchor="w")
        tk.Frame(w, bg=C["border"], height=1).pack(fill=tk.X, pady=(8,0), padx=12)

        # ── Scrollable colour list ──
        outer = tk.Frame(w, bg=C["panel"])
        outer.pack(fill=tk.BOTH, expand=True, padx=12, pady=8)
        canvas = tk.Canvas(outer, bg=C["panel"], highlightthickness=0, width=420, height=380)
        vsb = FlatScrollbar(outer, bg=C["panel"])
        vsb.config(command=canvas.yview)
        canvas.configure(yscrollcommand=vsb.set)
        vsb.pack(side=tk.RIGHT, fill=tk.Y)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        inner = tk.Frame(canvas, bg=C["panel"])
        win_id = canvas.create_window((0,0), window=inner, anchor="nw")
        def _resize(e):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfig(win_id, width=e.width)
        canvas.bind("<Configure>", _resize)
        inner.bind("<Configure>", lambda e: canvas.configure(
            scrollregion=canvas.bbox("all")))
        canvas.bind("<MouseWheel>",
            lambda e: canvas.yview_scroll(int(-1*(e.delta/120)), "units"))

        # Working copy of custom palette
        working = dict(C_CUSTOM)
        swatch_labels = {}
        hex_vars = {}

        def _pick(key):
            cur_hex = hex_vars[key].get().strip()
            try:
                w.winfo_rgb(cur_hex)  # validate
            except Exception:
                cur_hex = "#ffffff"
            result = _colorchooser.askcolor(
                color=cur_hex, title=f"Pick colour — {KEY_LABELS.get(key, key)}",
                parent=w)
            if result and result[1]:
                chosen = result[1]
                hex_vars[key].set(chosen)
                working[key] = chosen
                swatch_labels[key].config(bg=chosen)

        def _on_hex_change(key, var):
            val = var.get().strip()
            if len(val) == 7 and val.startswith("#"):
                try:
                    w.winfo_rgb(val)
                    working[key] = val
                    swatch_labels[key].config(bg=val)
                except Exception:
                    pass

        for key in EDIT_KEYS:
            row = tk.Frame(inner, bg=C["panel"])
            row.pack(fill=tk.X, pady=2, padx=4)

            # Colour swatch
            swatch = tk.Label(row, bg=C_CUSTOM.get(key, "#000000"),
                              width=3, relief="flat", bd=1)
            swatch.pack(side=tk.LEFT, padx=(0,6), ipady=8)
            swatch_labels[key] = swatch

            # Label
            tk.Label(row, text=KEY_LABELS.get(key, key),
                     bg=C["panel"], fg=C["text"],
                     font=("Segoe UI", 9), width=26, anchor="w").pack(side=tk.LEFT)

            # Hex entry
            var = tk.StringVar(value=C_CUSTOM.get(key, "#000000"))
            var.trace_add("write", lambda *_, k=key, v=var: _on_hex_change(k, v))
            hex_vars[key] = var
            if CTK:
                ent = ctk.CTkEntry(row, textvariable=var,
                                   fg_color=C["widget"], text_color=C["text"],
                                   border_color=C["border"], border_width=1,
                                   corner_radius=6, font=("Consolas", 9), width=80)
            else:
                ent = tk.Entry(row, textvariable=var, bg=C["widget"], fg=C["text"],
                               relief="flat", width=9, font=("Consolas", 9),
                               insertbackground=C["accent"])
            ent.pack(side=tk.LEFT, padx=(0,4))

            # Pick button
            pick_btn = self._btn(row, "⬛", lambda k=key: _pick(k),
                                 bg=C["btn"], fg=C["text"], fs=11, w=2)
            pick_btn.pack(side=tk.LEFT)

        # ── Preset base buttons ──
        tk.Frame(w, bg=C["border"], height=1).pack(fill=tk.X, padx=12, pady=(4,0))
        base_f = tk.Frame(w, bg=C["panel"])
        base_f.pack(fill=tk.X, padx=16, pady=(8,4))
        tk.Label(base_f, text="Start from:", bg=C["panel"], fg=C["dim"],
                 font=("Segoe UI", 8)).pack(side=tk.LEFT, padx=(0,6))

        def _load_base(source_palette):
            for k in EDIT_KEYS:
                if k in source_palette:
                    hex_vars[k].set(source_palette[k])
                    working[k] = source_palette[k]
                    swatch_labels[k].config(bg=source_palette[k])

        for name, palette in [("Default", C_DEFAULT), ("AMOLED", C_AMOLED),
                               ("Terminal", C_TERMINAL)]:
            self._btn(base_f, name, lambda p=palette: _load_base(p),
                      bg=C["btn"], fg=C["text"], fs=8).pack(side=tk.LEFT, padx=2)

        # ── Apply / Cancel ──
        tk.Frame(w, bg=C["border"], height=1).pack(fill=tk.X, padx=12, pady=(4,0))
        bf = tk.Frame(w, bg=C["panel"])
        bf.pack(pady=10)

        def _apply():
            # Commit working copy to C_CUSTOM and apply
            C_CUSTOM.update(working)
            # Auto-select Custom theme
            self._theme_name = "Custom"
            C.update(C_CUSTOM)
            self._save_config()
            w.destroy()
            if parent_dlg and parent_dlg.winfo_exists():
                try: parent_dlg.destroy()
                except: pass
            self.root.after(10, self._rebuild_main_ui)

        self._btn(bf, "Apply & Use", _apply,
                  bg=C["accent"], fg=accent_fg(), w=12).pack(side=tk.LEFT, padx=6)
        self._btn(bf, "Cancel", w.destroy,
                  bg=C["btn"], fg=C["white"], w=8).pack(side=tk.LEFT, padx=6)

    def _rebuild_main_ui(self):
        """Destroy and recreate root window content using current C palette."""
        self.root.configure(bg=C["bg"])
        for w in self.root.winfo_children():
            try: w.destroy()
            except: pass
        self.status = None
        self._ui()
        self._rebuild_tabs()
        self._refresh_hotkeys()
        if getattr(self, "_system_disabled", False):
            try:
                if CTK: self.sys_btn.configure(text="▶  Enable System", fg_color=C["green"])
                else:   self.sys_btn.config(text="▶  Enable System", bg=C["green"])
            except: pass

    # ── Save / Load ──────────────────────────────────────────
    def _save(self):
        self._ui_to_macro()
        try:
            with open(SAVEF,"w") as f:
                json.dump([m.to_dict() for m in self.macros], f, indent=2)
            self._set_status("Saved ✔", C["green"])
            self.root.after(2500, lambda: self._set_status("Ready"))
        except Exception as e:
            messagebox.showerror("Save Error", str(e))

    def _load(self):
        if not os.path.exists(SAVEF): return
        try:
            with open(SAVEF) as f: data = json.load(f)
            self.macros = [Macro.from_dict(d) for d in data]
            if self.macros:
                self._rebuild_tabs()
                self._select(0)
        except Exception as e:
            print(f"Load warning: {e}")

    # ── Status / queue ───────────────────────────────────────
    def _set_status(self, msg, fg=None):
        if hasattr(self, "status") and self.status.winfo_exists():
            self.status.config(text=msg, fg=fg or C["dim"])

    def _poll(self):
        while not self._q.empty():
            try: self._q.get_nowait()()
            except: pass
        self.root.after(40, self._poll)

    # ── System Tray ──────────────────────────────────────────
    def _make_tray_image(self):
        """Load icon.ico for the system tray; fall back to a generated image."""
        if os.path.exists(self._ico):
            try:
                return Image.open(self._ico).convert("RGBA")
            except Exception:
                pass
        # Fallback: draw a simple icon
        size = 64
        img = Image.new("RGBA", (size, size), (0, 0, 0, 0))
        d   = ImageDraw.Draw(img)
        d.ellipse([2, 2, size-2, size-2], fill="#1c1c1c")
        d.ellipse([4, 4, size-4, size-4], outline="#e91e8c", width=4)
        d.polygon([(22, 18), (22, 46), (46, 32)], fill="#ffffff")
        return img

    def _setup_tray(self):
        if not PYSTRAY:
            return
        img  = self._make_tray_image()
        menu = pystray.Menu(
            pystray.MenuItem("Show macrobin", self._restore_window, default=True),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem("Quit", self._quit_from_tray),
        )
        self._tray_icon = pystray.Icon("macrobin", img, "macrobin", menu)

    def _on_close(self):
        """Called when the user clicks the X button."""
        if PYSTRAY and self._close_to_tray:
            self._minimize_to_tray()
        else:
            self._quit()

    def _minimize_to_tray(self):
        self.root.withdraw()   # hide the window
        if self._tray_icon and not self._tray_icon.visible:
            threading.Thread(target=self._tray_icon.run, daemon=True).start()

    def _restore_window(self, icon=None, item=None):
        """Restore window from tray (called from tray thread — use after())."""
        self.root.after(0, self._do_restore)

    def _do_restore(self):
        self.root.deiconify()
        self.root.lift()
        self.root.focus_force()
        if self._tray_icon:
            try: self._tray_icon.stop()
            except: pass

    def _quit_from_tray(self, icon=None, item=None):
        """Quit triggered from tray menu."""
        self.root.after(0, self._quit)

    # ── Close ────────────────────────────────────────────────
    def _quit(self):
        self._stop_all()
        self._ui_to_macro()
        self._save()
        self.hkmgr.stop()
        if self._tray_icon:
            try: self._tray_icon.stop()
            except: pass
        self.root.destroy()


if __name__ == "__main__":
    App().run()
